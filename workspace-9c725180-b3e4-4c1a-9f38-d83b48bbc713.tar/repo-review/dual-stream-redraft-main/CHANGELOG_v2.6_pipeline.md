# CHANGELOG v2.6 pipeline

| requirement | implementation files | tests | status | limitation |
|---|---|---|---|---|
| tiered audit scheduling | `dualstream/audit_scheduler.py`, `dualstream/generator.py` | `tests/test_v26_pipeline.py` | reference implementation | heuristic risk model |
| fallback routing | `dualstream/fallback.py`, `dualstream/generator.py` | `tests/test_v26_pipeline.py` | reference implementation | deterministic canned behavior |
| randomized audit path | `dualstream/randomized_audit.py`, `dualstream/frame.py` | `tests/test_v26_pipeline.py` | reference implementation | not a proof of non-evasion |
| coherence expansion | `dualstream/audit.py` | `tests/test_v26_pipeline.py` | reference implementation | rule-based signals |

## Note on Implementation Maturity

All items above are reference implementations sufficient for specification conformance testing and pipeline integration demonstration. They are not production-hardened deployments. Key maturity notes:

- **FallbackRouter** (28 lines): Pure Python decision logic with no KV-cache interaction. The KV-cache isolation step from §5.4 of the paper is DSA-P-only.
- **randomized_audit.py** (34 lines): Uses `random.Random` (Mersenne Twister), not a CSPRNG. Suitable for probe diversification in DSA-R; DSA-P would require a hardware RNG.
- **Level-1 POC** (heuristic string matching in `generator.py`): Rule-based answer-text analysis, not model-internal divergence measurement.

Subsequent v2.9/v2.10 features (compact evidence, evidence profiles, retention floors, keyed replay, work certificates) are documented in `changelog_v2.9.md`, `docs/v2.10_conformance_matrix.md`, and the expanded `critique_issue_matrix.md`.
