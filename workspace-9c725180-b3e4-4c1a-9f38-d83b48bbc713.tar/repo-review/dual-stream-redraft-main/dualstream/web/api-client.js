async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(path, {
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
      ...options,
    });
  } catch (error) {
    throw new Error(`Network error while calling ${path}: ${error.message}`);
  }

  let data = null;
  const text = await response.text();
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      if (!response.ok) {
        throw new Error(`Request failed (${response.status}) and returned invalid JSON.`);
      }
      return text;
    }
  }

  if (!response.ok) {
    const detail = data?.detail || `HTTP ${response.status}`;
    throw new Error(typeof detail === 'string' ? detail : JSON.stringify(detail));
  }
  return data;
}

export const api = {
  // --- Core ---
  health: () => request('/health'),
  uiStatus: () => request('/ui/status'),
  listJobs: () => request('/jobs'),
  getJob: (jobId) => request(`/jobs/${encodeURIComponent(jobId)}`),
  cancelJob: (jobId) => request(`/jobs/${encodeURIComponent(jobId)}/cancel`, { method: 'POST' }),
  getArtifacts: (jobId) => request(`/artifacts/${encodeURIComponent(jobId)}`),
  listScripts: () => request('/scripts'),
  submit: (route, payload) => request(route, { method: 'POST', body: JSON.stringify(payload) }),

  // --- v2.10 Envelopes (§5.3) ---
  envelopeCreate: (payload) => request('/v210/envelope/create', { method: 'POST', body: JSON.stringify(payload) }),
  envelopeIngest: (payload) => request('/v210/envelope/ingest', { method: 'POST', body: JSON.stringify(payload) }),
  envelopeSeal: (payload) => request('/v210/envelope/seal', { method: 'POST', body: JSON.stringify(payload) }),
  envelopeListSessions: () => request('/v210/envelope/sessions'),

  // --- v2.10 Triggers (§6.2) ---
  triggerEvaluate: (payload) => request('/v210/trigger/evaluate', { method: 'POST', body: JSON.stringify(payload) }),
  triggerSignals: () => request('/v210/trigger/signals'),

  // --- v2.10 Retention (§7) ---
  retentionPipeline: (payload) => request('/v210/retention/pipeline', { method: 'POST', body: JSON.stringify(payload) }),
  retentionChallenge: (payload) => request('/v210/retention/challenge', { method: 'POST', body: JSON.stringify(payload) }),

  // --- v2.10 Evidence ---
  evidenceProfiles: () => request('/v210/evidence/profiles'),
  evidenceBudget: (payload) => request('/v210/evidence/budget', { method: 'POST', body: JSON.stringify(payload) }),

  // --- v2.10 Verifier ---
  verifierVerify: (payload) => request('/v210/verifier/verify', { method: 'POST', body: JSON.stringify(payload) }),

  // --- v2.10 Architecture ---
  architecture: () => request('/v210/architecture'),
};
