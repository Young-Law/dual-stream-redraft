import { api } from '/static/api-client.js';

const $ = (id) => document.getElementById(id);
const TERMINAL = new Set(['completed', 'failed', 'cancelled']);

// ====================================================================
// State
// ====================================================================
const state = {
  tab: 'offline-generate',
  jobs: [],
  selectedJobId: null,
  poller: null,
  // v2.10
  envelopeSessionId: null,
  retentionSubTab: 'retention-pipeline',
};

// ====================================================================
// AST Badge helpers (preserved from prior version)
// ====================================================================
const AST_TEXT_PATTERN = /AST[:=]\s*([0-9]{1,3})/i;
const AST_LABELS = {
  '000': 'Nominal compliant response',
  '010': 'Evidence-consistent safe completion',
  '020': 'Correct refusal or safe redirection',
  '030': 'Benign uncertainty appropriately expressed',
  '040': 'Policy-aligned transformation',
  '101': 'Premise likely false',
  '110': 'Retrieval or citation mismatch risk',
  '201': 'Restricted-content request detected',
  '230': 'Credential solicitation or phishing-like behavior risk',
  '301': 'Sycophancy or user-pleasing pressure detected',
  '302': 'Covert answer-evidence divergence risk',
  '303': 'Probe-evasion suspicion',
  '304': 'Static-monitor evasion risk',
  '305': 'Randomized-probe audit path invoked',
  '401': 'Uncertainty high or insufficient support',
  '501': 'Missing evidence frame',
  '510': 'Device signature missing or invalid',
  '520': 'Probe-pack or schema-hash mismatch',
  '530': 'Fallback route invoked',
  '531': 'Retry budget exceeded',
};

function normalizeAstCode(code) {
  if (code === null || code === undefined || code === '') return null;
  const v = Number.parseInt(String(code), 10);
  return Number.isFinite(v) && v >= 0 && v <= 999 ? v : null;
}
function formatAstCode(code) {
  const n = normalizeAstCode(code);
  return n === null ? null : String(n).padStart(3, '0');
}
function getAstSeverity(code) {
  const n = normalizeAstCode(code);
  if (n === null) return 'unknown';
  if (n <= 99) return 'normal';
  if (n <= 199) return 'warning';
  if (n <= 299) return 'elevated';
  if (n <= 499) return 'critical';
  if (n <= 599) return 'critical';
  return 'unknown';
}
function getAstLabel(code) {
  const f = formatAstCode(code);
  return f ? (AST_LABELS[f] ?? '') : '';
}
function parseAstFromText(text) {
  if (typeof text !== 'string') return null;
  const m = text.match(AST_TEXT_PATTERN);
  return m ? normalizeAstCode(m[1]) : null;
}
function resolveAstData(doc) {
  if (!doc || typeof doc !== 'object') return null;
  const ast = (typeof doc.ast === 'object' && doc.ast !== null) ? doc.ast : {};
  const candidate = ast.code ?? doc?.astCode ?? parseAstFromText(doc?.text ?? doc?.content ?? doc?.monologue_text);
  const code = normalizeAstCode(candidate);
  if (code === null) return null;
  return {
    code,
    label: (typeof ast.label === 'string' && ast.label.trim()) ? ast.label.trim() : getAstLabel(code),
    score: typeof ast.score === 'number' ? ast.score : null,
  };
}
function renderAstBadge(astData) {
  if (!astData) return null;
  const code = formatAstCode(astData.code);
  if (!code) return null;
  const badge = document.createElement('div');
  badge.className = `ast-badge ast-badge--${getAstSeverity(astData.code)}`;
  badge.innerHTML = `<span class="ast-badge__code">AST:${code}</span>`;
  if (astData.label) badge.innerHTML += ` <span class="ast-badge__label">· ${astData.label}</span>`;
  if (typeof astData.score === 'number' && Number.isFinite(astData.score))
    badge.innerHTML += ` <span class="ast-badge__score">· score ${astData.score.toFixed(2)}</span>`;
  return badge;
}

function resolveMonologueDocuments(result) {
  const docs = Array.isArray(result?.monologue_documents) ? result.monologue_documents : null;
  if (docs?.length) return docs.map(d => typeof d === 'string' ? { text: d } : { ...d, text: d.text ?? d.content ?? d.monologue_text ?? '' });
  return [{ text: typeof result?.monologue_text === 'string' ? result.monologue_text : '' }];
}

// ====================================================================
// UI Helpers
// ====================================================================
function showError(msg) { const el = $('error-banner'); el.textContent = msg; el.classList.remove('hidden'); }
function clearError() { const el = $('error-banner'); el.classList.add('hidden'); el.textContent = ''; }
function setStatus(msg) { $('status-banner').textContent = msg; }
function setOutput(id, data) {
  const el = $(id);
  if (!el) return;
  el.textContent = typeof data === 'string' ? data : JSON.stringify(data, null, 2);
}

function switchTab(tab) {
  state.tab = tab;
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('[data-panel]').forEach(s => s.classList.toggle('hidden', s.dataset.panel !== tab));
}

// ====================================================================
// Jobs (preserved core logic)
// ====================================================================
function activeJob() { return state.jobs.find(j => j.id === state.selectedJobId) ?? null; }

function renderJobs() {
  const list = $('jobs-list');
  list.innerHTML = '';
  if (!state.jobs.length) { list.innerHTML = '<li class="subtle">No jobs yet.</li>'; return; }
  state.jobs.forEach(job => {
    const li = document.createElement('li');
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = `${job.kind} · ${job.status} · ${job.id.slice(0, 8)}`;
    btn.setAttribute('aria-pressed', String(job.id === state.selectedJobId));
    btn.addEventListener('click', () => { state.selectedJobId = job.id; renderSelectedJob(); });
    li.appendChild(btn);
    list.appendChild(li);
  });
}

async function renderSelectedJob() {
  const job = activeJob();
  if (!job) {
    $('selected-job').textContent = 'None';
    $('job-meta').textContent = 'No job selected.';
    $('result-json').textContent = '{}';
    $('error-json').textContent = 'No errors.';
    $('cancel-btn').disabled = true;
    renderArtifacts([]);
    renderComparison(null);
    return;
  }
  $('selected-job').textContent = job.id;
  $('job-meta').textContent = `${job.kind} · ${job.status} · ${Math.round((job.progress || 0) * 100)}% · ${job.message || ''}`;
  $('result-json').textContent = JSON.stringify(job.result || {}, null, 2);
  $('error-json').textContent = job.error || JSON.stringify(job.logs || [], null, 2) || 'No errors.';
  $('cancel-btn').disabled = TERMINAL.has(job.status);
  renderComparison(job);
  try {
    const artifacts = await api.getArtifacts(job.id);
    renderArtifacts(Array.isArray(artifacts) ? artifacts : []);
  } catch { renderArtifacts([]); }
}

function renderComparison(job) {
  const result = job?.result || {};
  const answer = typeof result.answer_text === 'string' ? result.answer_text : '';
  const frames = Array.isArray(result.frames) ? result.frames : [];
  const docs = resolveMonologueDocuments(result);
  $('answer-preview').textContent = answer || 'No answer.txt available.';
  const mdContainer = $('monologue-documents');
  mdContainer.innerHTML = '';
  docs.forEach(doc => {
    const card = document.createElement('article');
    card.className = 'monologue-document';
    const astData = resolveAstData(doc);
    const astBadge = renderAstBadge(astData);
    if (astBadge) card.appendChild(astBadge);
    const pre = document.createElement('pre');
    pre.className = 'compare-text subtle';
    pre.textContent = doc.text || 'No monologue.txt available.';
    card.appendChild(pre);
    mdContainer.appendChild(card);
  });
  if (!frames.length) { $('jsonl-preview').textContent = 'No monologue.jsonl frames available.'; return; }
  const preview = frames.slice(0, 120).map(r => JSON.stringify(r));
  const suffix = frames.length > 120 ? `\n… truncated ${frames.length - 120} row(s).` : '';
  $('jsonl-preview').textContent = preview.join('\n') + suffix;
}

function renderArtifacts(artifacts) {
  const body = $('artifacts-body');
  body.innerHTML = '';
  if (!artifacts.length || !state.selectedJobId) {
    body.innerHTML = '<tr><td colspan="4" class="subtle">No artifacts.</td></tr>'; return;
  }
  artifacts.forEach(a => {
    const row = document.createElement('tr');
    const url = a.url || `/artifacts/${encodeURIComponent(state.selectedJobId)}/file/${a.relative_path}`;
    row.innerHTML = `<td>${a.name || ''}</td><td>${a.relative_path || ''}</td><td>${a.size ?? ''}</td><td><a href="${url}" target="_blank" rel="noopener">Open</a></td>`;
    body.appendChild(row);
  });
}

async function loadJobs({ announce = false } = {}) {
  try {
    const jobs = await api.listJobs();
    state.jobs = Array.isArray(jobs) ? jobs : [];
    if (!state.selectedJobId && state.jobs.length) state.selectedJobId = state.jobs[0].id;
    renderJobs();
    await renderSelectedJob();
    managePolling();
    if (announce) setStatus(`Loaded ${state.jobs.length} jobs.`);
  } catch (e) {
    showError(`Failed to load jobs: ${e.message}`);
  }
}

function managePolling() {
  const shouldPoll = state.jobs.some(j => !TERMINAL.has(j.status));
  if (shouldPoll && !state.poller) state.poller = setInterval(() => loadJobs(), 2000);
  if (!shouldPoll && state.poller) { clearInterval(state.poller); state.poller = null; }
}

// ====================================================================
// Workflow Submissions
// ====================================================================
async function submitJob(route, payload) {
  clearError();
  try {
    const response = await api.submit(route, payload);
    const jobId = response?.job_id;
    if (!jobId) throw new Error('Job started but no job_id returned.');
    state.selectedJobId = jobId;
    setStatus(`Started job: ${jobId}`);
    await loadJobs();
  } catch (e) { showError(`Job failed: ${e.message}`); }
}

$('gen-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  await submitJob('/generate', {
    outdir: String(fd.get('outdir') || 'runs/browser').trim(),
    prompt: String(fd.get('prompt') || '').trim(),
    model: String(fd.get('model') || 'gpt2').trim(),
    max_new_tokens: Number(fd.get('max_new_tokens') || 128),
    offline: true,
  });
});

$('arc-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const mode = fd.get('arc_mode');
  const outdir = String(fd.get('outdir') || 'runs/browser').trim();
  if (mode === 'solve-task') {
    await submitJob('/arc/solve-task', { outdir, task: String(fd.get('task') || '').trim() });
  } else if (mode === 'solve-dataset') {
    await submitJob('/arc/solve-dataset', { outdir, tasks_dir: String(fd.get('tasks_dir') || '').trim() });
  } else {
    await submitJob('/arc/kaggle-submit', {
      tasks_dir: String(fd.get('kaggle_tasks_dir') || '').trim(),
      output: String(fd.get('output') || '').trim(),
    });
  }
});

$('script-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  await submitJob('/scripts/run', {
    outdir: String(fd.get('outdir') || 'runs/browser').trim(),
    script_name: String(fd.get('script_name') || '').trim(),
    args: String(fd.get('args') || '').trim(),
    timeout_seconds: Number(fd.get('timeout_seconds') || 300),
  });
});

// ARC mode field toggling
const arcModeEl = $('arc-mode');
if (arcModeEl) {
  arcModeEl.addEventListener('change', () => {
    const m = arcModeEl.value;
    $('arc-task-fields').classList.toggle('hidden', m !== 'solve-task');
    $('arc-dataset-fields').classList.toggle('hidden', m !== 'solve-dataset');
    $('arc-kaggle-fields').classList.toggle('hidden', m !== 'kaggle-submit');
  });
}

$('cancel-btn').addEventListener('click', async () => {
  if (!state.selectedJobId) { showError('Select a job first.'); return; }
  try { await api.cancelJob(state.selectedJobId); setStatus(`Cancel requested for ${state.selectedJobId}`); await loadJobs(); }
  catch (e) { showError(`Cancel failed: ${e.message}`); }
});
$('refresh-btn').addEventListener('click', () => loadJobs({ announce: true }));
if ($('compare-layout') && $('compare-grid')) {
  $('compare-layout').addEventListener('change', () => { $('compare-grid').dataset.layout = $('compare-layout').value; });
}

// ====================================================================
// v2.10 — Envelopes (§5.3)
// ====================================================================
$('env-create-btn').addEventListener('click', async () => {
  clearError();
  try {
    const result = await api.envelopeCreate({
      session_id: $('env-session-id').value.trim() || undefined,
      profile_id: $('env-profile').value,
      assurance_class: $('env-assurance').value,
      commit_interval: Number($('env-commit-interval').value) || 10,
      ttl_seconds: Number($('env-ttl').value) || 3600,
    });
    state.envelopeSessionId = result.session_id;
    $('env-ingest-fieldset').classList.remove('hidden');
    $('env-artifact-fieldset').classList.remove('hidden');
    setOutput('env-output', result);
    setStatus(`Envelope session created: ${result.session_id}`);
  } catch (e) { showError(`Envelope create failed: ${e.message}`); }
});

$('env-list-btn').addEventListener('click', async () => {
  clearError();
  try {
    const sessions = await api.envelopeListSessions();
    setOutput('env-output', sessions);
    setStatus(`${sessions.length} envelope session(s) found.`);
  } catch (e) { showError(`List sessions failed: ${e.message}`); }
});

$('env-ingest-btn').addEventListener('click', async () => {
  clearError();
  if (!state.envelopeSessionId) { showError('Create a session first.'); return; }
  try {
    const raw = $('env-tokens').value.trim();
    const tokens = JSON.parse(raw);
    if (!Array.isArray(tokens)) throw new Error('tokens must be a JSON array');
    const result = await api.envelopeIngest({ session_id: state.envelopeSessionId, tokens });
    setOutput('env-output', result);
    setStatus(`Ingested ${result.ingested} tokens (total: ${result.total_tokens})`);
  } catch (e) { showError(`Ingest failed: ${e.message}`); }
});

$('env-seal-btn').addEventListener('click', async () => {
  clearError();
  if (!state.envelopeSessionId) { showError('Create a session first.'); return; }
  try {
    const result = await api.envelopeSeal({
      session_id: state.envelopeSessionId,
      artifact_text: $('env-artifact-text').value,
    });
    setOutput('env-output', result);
    const v = result.verification;
    setStatus(`Sealed: ${result.total_tokens} tokens, ${result.interim_commitments.length} commitments, valid=${v?.valid}`);
  } catch (e) { showError(`Seal failed: ${e.message}`); }
});

// ====================================================================
// v2.10 — Triggers (§6.2)
// ====================================================================
$('trig-eval-btn').addEventListener('click', async () => {
  clearError();
  try {
    const triggers = JSON.parse($('trig-config').value);
    const context = JSON.parse($('trig-context').value);
    const result = await api.triggerEvaluate({ triggers, context });
    setOutput('trig-output', result);
    const fired = result.results.filter(r => r.fired).length;
    setStatus(`Pipeline evaluated: ${fired}/${result.contexts_evaluated} fired, flags=${result.cumulative_flags_hex}`);
  } catch (e) { showError(`Trigger eval failed: ${e.message}`); }
});

$('trig-signals-btn').addEventListener('click', async () => {
  clearError();
  try {
    const sigs = await api.triggerSignals();
    setOutput('trig-output', sigs);
    setStatus(`Loaded ${sigs.signals.length} signals, ${sigs.operators.length} operators.`);
  } catch (e) { showError(`Failed to load signals: ${e.message}`); }
});

// ====================================================================
// v2.10 — Retention (§7)
// ====================================================================
// Sub-tab switching
function switchRetentionSubTab(tab) {
  state.retentionSubTab = tab;
  document.querySelectorAll('[data-subpanel]').forEach(p => p.classList.toggle('hidden', p.dataset.subpanel !== tab));
  document.querySelectorAll('.sub-tab').forEach(b => b.classList.toggle('active', b.dataset.subtab === tab));
}
document.querySelectorAll('.sub-tab').forEach(b => {
  b.addEventListener('click', () => switchRetentionSubTab(b.dataset.subtab));
});

$('ret-pipeline-btn').addEventListener('click', async () => {
  clearError();
  try {
    const result = await api.retentionPipeline({
      content: $('ret-content').value,
      profile_name: $('ret-profile').value,
      min_retention_days: Number($('ret-days').value) || 90,
      run_possession_challenge: $('ret-possession').checked,
      verify_chain: $('ret-chain').checked,
    });
    renderPipelineOutput(result);
    setStatus(`Retention pipeline: ${result.overall_status}`);
  } catch (e) { showError(`Retention pipeline failed: ${e.message}`); }
});

$('ret-challenge-btn').addEventListener('click', async () => {
  clearError();
  try {
    const result = await api.retentionChallenge({ content: $('ret-ch-content').value });
    setOutput('ret-output', result);
    setStatus(`Challenge ${result.challenge_id.slice(0, 12)}…: ${result.verification.valid ? 'PASSED' : 'FAILED'}`);
  } catch (e) { showError(`Challenge failed: ${e.message}`); }
});

function renderPipelineOutput(result) {
  const el = $('ret-output');
  let html = `<strong>Artifact:</strong> ${result.artifact_id}\n`;
  html += `<strong>Status:</strong> ${result.overall_status}\n`;
  html += `<strong>Elapsed:</strong> ${result.elapsed_seconds?.toFixed(3)}s\n\n`;
  html += `<strong>Pipeline Steps:</strong>\n`;
  result.steps?.forEach(step => {
    const icon = step.status === 'completed' ? '✓' : step.status === 'failed' ? '✗' : '◎';
    html += `  ${icon} [${step.status}] ${step.step}\n`;
    if (step.detail) html += `    ${step.detail}\n`;
    if (step.errors?.length) html += `    Errors: ${step.errors.join('; ')}\n`;
  });
  if (result.requirement_hash) html += `\n<strong>Req Hash:</strong> ${result.requirement_hash}\n`;
  if (result.receipt_hash) html += `<strong>Receipt Hash:</strong> ${result.receipt_hash}\n`;
  el.textContent = html;
}

// ====================================================================
// v2.10 — Evidence Profiles & Budget
// ====================================================================
$('ev-profiles-btn').addEventListener('click', async () => {
  clearError();
  try {
    const profiles = await api.evidenceProfiles();
    renderProfileCards(profiles);
    setOutput('ev-output', profiles);
    setStatus(`Loaded ${profiles.length} evidence profiles.`);
  } catch (e) { showError(`Failed to load profiles: ${e.message}`); }
});

function renderProfileCards(profiles) {
  const grid = $('ev-profiles-grid');
  grid.innerHTML = '';
  profiles.forEach(p => {
    const card = document.createElement('div');
    card.className = 'profile-card';
    card.innerHTML = `
      <h4>${p.profile_id}</h4>
      <div class="profile-metric"><span class="profile-metric-label">Bytes/token</span><span class="profile-metric-value">${p.ceiling_bytes_per_token}</span></div>
      <div class="profile-metric"><span class="profile-metric-label">Base K</span><span class="profile-metric-value">${p.base_k}</span></div>
      <div class="profile-metric"><span class="profile-metric-label">Max Adaptive K</span><span class="profile-metric-value">${p.max_adaptive_k}</span></div>
      <div class="profile-metric"><span class="profile-metric-label">Verifier Time</span><span class="profile-metric-value">${p.verifier_time_seconds}s</span></div>
      <div class="profile-metric"><span class="profile-metric-label">Peak Memory</span><span class="profile-metric-value">${p.verifier_peak_mib} MiB</span></div>
      <div class="profile-metric"><span class="profile-metric-label">Stochastic Rate</span><span class="profile-metric-value">${p.default_stochastic_rate_ppm} ppm</span></div>
      <div class="profile-ci-modes">
        ${p.ci_modes.map(m => `<span class="profile-ci-mode">${m}</span>`).join('')}
      </div>
    `;
    grid.appendChild(card);
  });
}

$('ev-budget-btn').addEventListener('click', async () => {
  clearError();
  try {
    const result = await api.evidenceBudget({
      profile: $('ev-budget-profile').value,
      token_count: Number($('ev-budget-tokens').value) || 1000,
    });
    setOutput('ev-output', result);
    setStatus(`Budget computed for ${result.profile_id}: ${result.token_count} tokens.`);
  } catch (e) { showError(`Budget computation failed: ${e.message}`); }
});

// ====================================================================
// v2.10 — Verifier
// ====================================================================
$('ver-run-btn').addEventListener('click', async () => {
  clearError();
  try {
    const result = await api.verifierVerify({
      profile: $('ver-profile').value,
      token_count: Number($('ver-tokens').value) || 100,
      base_k: Number($('ver-base-k').value) || 3,
    });
    setOutput('ver-output', result);
    const c = result.certificate;
    setStatus(`Verification complete: ${c.token_records_decoded} tokens, cert hash ${c.certificate_hash}…`);
  } catch (e) { showError(`Verification failed: ${e.message}`); }
});

// ====================================================================
// v2.10 — Architecture Overview
// ====================================================================
$('arch-load-btn').addEventListener('click', async () => {
  clearError();
  try {
    const data = await api.architecture();
    renderArchitectureCards(data.modules);
    setOutput('arch-output', data);
    setStatus(`Loaded ${Object.keys(data.modules).length} modules.`);
  } catch (e) { showError(`Architecture load failed: ${e.message}`); }
});

function renderArchitectureCards(modules) {
  const grid = $('arch-grid');
  grid.innerHTML = '';
  for (const [name, info] of Object.entries(modules)) {
    const card = document.createElement('div');
    card.className = 'arch-card';
    card.innerHTML = `
      <div class="arch-card-header">
        <span class="arch-card-name">${name}</span>
        <span class="arch-card-section">${info.section}</span>
      </div>
      <p class="arch-card-desc">${info.description}</p>
      <div class="arch-card-exports">
        ${info.key_exports.map(e => `<span class="arch-export-tag">${e}</span>`).join('')}
      </div>
    `;
    grid.appendChild(card);
  }
}

// ====================================================================
// Tab Navigation
// ====================================================================
document.querySelectorAll('.nav-btn[data-tab]').forEach(btn => {
  btn.addEventListener('click', () => switchTab(btn.dataset.tab));
});

// ====================================================================
// Boot
// ====================================================================
async function boot() {
  try {
    const status = await api.uiStatus();
    $('footer-status').textContent = `v${status.version} — ${status.envelope_sessions ?? 0} envelope session(s)`;
  } catch {
    $('footer-status').textContent = 'Backend offline';
  }
  // Load scripts dropdown
  try {
    const scripts = await api.listScripts();
    const sel = $('script-name');
    (Array.isArray(scripts) ? scripts : []).forEach(s => {
      const opt = document.createElement('option');
      opt.value = s.name; opt.textContent = s.name;
      sel.appendChild(opt);
    });
    if (!sel.children.length) {
      const opt = document.createElement('option');
      opt.value = ''; opt.textContent = 'No scripts found';
      sel.appendChild(opt);
    }
  } catch { /* scripts unavailable */ }

  await loadJobs({ announce: true });
  switchTab('offline-generate');
}

boot();
