# Portable Verifier

The portable verifier (`verify_evidence_artifact` in `dualstream/verifier.py`) is the single entry point for validating compact evidence artifacts. It performs a multi-stage pipeline and produces a structured `VerificationReport`.

## Pipeline Stages

```
┌─────────────────────────────┐
│  1. Artifact Discovery      │  find_compact_artifact()
│  2. Binary Decode           │  decode_compact_sequence()
│  3. Keyed Replay Verify     │  verify_keyed_replay()  [if audit_keys]
│  4. Metadata Binding        │  _enforce_metadata_binding()
│  5. Profile Match           │  header.profile_id == requested
│  6. Token Reconstruction    │  reconstruct_token_evidence()
│  7. Structural Checks       │  contiguity, shape, floor, score range
│  8. Retention Floor         │  assert_retention_floor()
│  9. Budget Evaluation       │  _evaluate_profile_budget()
│ 10. Resource Enforcement    │  tracemalloc, RSS, elapsed time
│ 11. Work Certificate        │  VerifierWorkCertificate + optional HMAC
└─────────────────────────────┘
```

### 1. Artifact Discovery

`find_compact_artifact(path)` resolves a directory or file path to the compact evidence binary. It checks for:
- `meta.json` → `compact_evidence_path` hint
- `compact_evidence.dsae`
- `compact_evidence.bin`

### 2. Binary Decode

`decode_compact_sequence(data)` dispatches by wire version (`0x0301`, `0x0302`, `0x0303`). Each version has its own decoder that validates magic, header fields, chunk integrity (CRC32, and SHA-256 for V3.3), token contiguity, and span bounds.

### 3. Keyed Replay Verification

If `audit_keys` is provided and the artifact is V3.3, `verify_keyed_replay()` is called. This:
1. Validates all authenticated metadata fields (types, ranges, hex digests).
2. Recomputes the commit identity from decoded tokens and base-K evidence.
3. Recomputes the pre-stochastic eligibility digest.
4. Verifies the HMAC-SHA256 audit selection commitment.
5. Replays every token's keyed stochastic selection and confirms trigger flags match.

### 4. Metadata Binding

`_enforce_metadata_binding()` cross-checks `meta.json` (if present) against the decoded artifact:
- `compact_evidence_path` must match the actual file name.
- `compact_evidence_sha256` must match the artifact digest.
- `compact_evidence_token_count`, `frame_token_count`, and `answer_token_count` (if present) must match the decoded header token count.

### 5. Profile Match

The profile embedded in the artifact header must match the profile requested by the caller. Mismatch raises a schema error.

### 6. Token Reconstruction

`reconstruct_token_evidence()` produces a per-token dict list with `token_index`, `chosen_id`, `topk_ids`, `topk_scores`, `effective_topk`, `chosen_rank`, `trigger_flags`, `record_flags`, and overlaid `signals` from spans.

### 7. Structural Checks

For each reconstructed token record:
- `token_index` must be contiguous from 0.
- `effective_topk` must equal `len(topk_ids)` and `len(topk_scores)`.
- `effective_topk` must be >= profile `base_k` (floor-starvation check).
- `chosen_rank` must not be 255 and must not exceed `max_adaptive_k` (rank overflow tracking).
- All scores must be within `[-SCORE_TOLERANCE, 1 + SCORE_TOLERANCE]` (≈ `[-0.002, 1.002]`).

### 8. Retention Floor

`assert_retention_floor()` verifies that the artifact's byte count is >= the computed minimum reconstructable bytes. Raises `AST_RETENTION_FLOOR_VIOLATION` (521) on failure.

### 9. Budget Evaluation

`_evaluate_profile_budget()` checks whether `raw_bytes_per_token` exceeds the profile ceiling. Budget evaluation is deferred (status `not_evaluated_short_fixture`) when the token count is below `minimum_budget_token_count` and `strict_profile_budget` is false.

Additionally, if the profile defines an `adaptive_record_fraction_limit`, the verifier rejects artifacts where the adaptive fraction exceeds it.

### 10. Resource Enforcement

Three resource budgets are enforced (when `enforce_budget=True`):

| Resource | Source | Profile Field | AST Code |
|----------|--------|--------------|----------|
| Tracemalloc peak | `tracemalloc.get_traced_memory()` | `verifier_traced_peak_mib` / `verifier_peak_mib` | 523 (deterministic verifier-work violation) |
| Wall-clock time | `time.perf_counter()` | `verifier_time_seconds` | 524 (infrastructure instability) |
| Peak RSS | `resource.getrusage(RUSAGE_SELF).ru_maxrss` | `verifier_peak_rss_mib` / `verifier_peak_mib` | 524 (infrastructure instability, `--enforce-rss-budget` only) |

### 11. Work Certificate

A `VerifierWorkCertificate` is always produced. If `verifier_key` is provided, it is HMAC-SHA256 signed and attached.

## VerifierWorkCertificate

```python
@dataclass(frozen=True)
class VerifierWorkCertificate:
    bytes_read: int                       # Raw artifact bytes read
    bytes_hashed: int                     # Bytes passed through SHA-256
    token_records_decoded: int            # Number of token records
    candidate_entries_decoded: int        # Σ effective_topk across all tokens
    varint_bytes_decoded: int             # Approximate (raw_bytes // 4)
    chunks_verified: int                  # Number of chunks
    span_events_indexed: int              # Number of span events
    span_overlay_operations: int          # Same as span_events_indexed
    allocations: int                      # Approximate (token_count × 2)
    maximum_live_bytes: int               # tracemalloc peak
    full_artifact_materializations: int   # Always 0 in current implementation
    normalized_runtime_seconds: float     # Wall-clock elapsed time
    signature: str | None                 # HMAC-SHA256 hex if verifier_key provided
```

### Canonical Serialization

The certificate is serialized to a deterministic JSON byte string:

```python
json.dumps(data, sort_keys=True, separators=(',', ':')).encode('utf-8')
```

All fields except `signature` are included. The `signature` field is omitted from the signed payload.

### Signing and Verification

```python
signature = hmac.new(key, canonical_payload, hashlib.sha256).hexdigest()
```

Verification uses `hmac.compare_digest` for constant-time comparison.

## VerificationReport Fields

| Field | Type | Description |
|-------|------|-------------|
| `ok` | `bool` | True if no errors were recorded. |
| `profile_id` | `str` | Evidence profile used (e.g. `DSA-CI-Lite`). |
| `token_count` | `int` | Number of decoded token records. |
| `elapsed_seconds` | `float` | Wall-clock verification time. |
| `peak_tracemalloc_bytes` | `int` | Peak traced memory allocation. |
| `verifier_peak_rss_bytes` | `int` | Peak RSS of the verifier process. |
| `verifier_peak_rss_limit_bytes` | `int` | Profile RSS limit in bytes. |
| `raw_bytes_per_token` | `float` | Raw artifact bytes divided by token count. |
| `compressed_bytes_per_token` | `float | None` | Reserved; currently None. |
| `adaptive_record_count` | `int` | Tokens with `effective_topk > base_k`. |
| `adaptive_record_fraction` | `float` | `adaptive_record_count / token_count`. |
| `max_effective_topk` | `int` | Largest `effective_topk` across all tokens. |
| `rank_overflow_count` | `int` | Tokens with `chosen_rank` > `max_adaptive_k` or == 255. |
| `retained_reconstructable_bytes` | `int` | Total raw artifact bytes. |
| `minimum_reconstructable_bytes` | `int` | Computed retention floor. |
| `retention_floor_margin_bytes` | `int` | Retained minus minimum. |
| `verifier_reconstruction_seconds_mean` | `float` | Same as `elapsed_seconds` (single-pass). |
| `verifier_reconstruction_seconds_p50` | `float` | Same as `elapsed_seconds`. |
| `verifier_reconstruction_seconds_p95` | `float` | Same as `elapsed_seconds`. |
| `tokens_reconstructed_per_second` | `float` | `token_count / elapsed_seconds`. |
| `chunks_reconstructed` | `int` | Number of chunks. |
| `span_events_overlaid` | `int` | Number of span events. |
| `adaptive_records_reconstructed` | `int` | Same as `adaptive_record_count`. |
| `budget_status` | `str` | One of: `pass`, `fail`, `not_evaluated_short_fixture`, `not_evaluated_disabled`, `not_evaluated_due_to_structural_failure`. |
| `verification_outcome` | `str` | `pass`, `fail`, or `INCONCLUSIVE_INFRA`. |
| `failure_codes` | `list[int | str]` | Deduplicated AST codes from failures. |
| `errors` | `list[str]` | Human-readable error messages. |
| `strict_profile_budget` | `bool` | Whether strict mode was enabled. |
| `minimum_budget_token_count` | `int` | Profile's minimum token threshold. |
| `ceiling_bytes_per_token` | `int` | Profile's byte/token ceiling. |
| `work_certificate` | `VerifierWorkCertificate | None` | Signed work attestation. |
| `retention_state` | `str` | Always `LOCAL_PASS` in current implementation. |

## Profile CI Mode Enforcement

`assert_profile_ci_mode()` validates that the requested CI mode is in the profile's allowed set. Additionally, `DSA-Forensic` is explicitly rejected for `pr` and `normal` modes.

## Verification Outcome Logic

```python
ok = not errors
outcome = "pass" if ok else "fail"
if not ok and all(c == AST_INFRASTRUCTURE_INSTABILITY for c in failure_codes):
    outcome = "INCONCLUSIVE_INFRA"
```

An `INCONCLUSIVE_INFRA` outcome means the artifact itself may be valid but the verifier's resource environment was insufficient (time or memory exceeded).

## Error Classification (AST Codes)

| AST Code | Constant | Trigger |
|----------|----------|---------|
| 510 | `AST_INVALID_SIGNATURE` | Work certificate or tension-map HMAC mismatch. |
| 520 | `AST_SCHEMA_MISMATCH` | Decode error, metadata binding failure, structural check failure, or profile mismatch. |
| 521 | `AST_RETENTION_FLOOR_VIOLATION` | Retained bytes below minimum reconstructable floor. |
| 522 | `AST_VERIFIER_RESOURCE_BUDGET_EXCEEDED` | Reserved (not directly used in current verifier). |
| 523 | `AST_DETERMINISTIC_VERIFIER_WORK_VIOLATION` | Tracemalloc peak exceeds profile budget. |
| 524 | `AST_INFRASTRUCTURE_INSTABILITY` | Elapsed time exceeds budget, or RSS exceeds budget (when enforced). |

The verifier maps errors to codes heuristically: any exception message containing "floor" or "summary-only" maps to 521; all other exceptions map to 520. Resource-budget violations add 523 or 524 independently.
