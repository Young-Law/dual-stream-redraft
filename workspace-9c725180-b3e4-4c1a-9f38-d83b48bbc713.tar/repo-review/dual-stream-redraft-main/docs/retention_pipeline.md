# Retention Receipt Pipeline (§7)

The retention receipt pipeline orchestrates the full end-to-end retention assurance lifecycle, tying together requirement issuance, artifact storage, validation, receipt creation, possession challenges, and restore verification.

## Pipeline Stages

```
┌──────────────────────────────┐
│ 1. Issue RetentionRequirement │  ← governance authority signs
│ 2. Store artifact              │  ← StorageBackend.store()
│ 3. Validate storage            │  ← hash + size check
│ 4. Issue RetentionReceipt      │  ← validator signs, chained
│ 5. Possession challenge (opt)  │  ← random byte-range proof
│ 6. Chain verification (opt)    │  ← 6-step integrity check
└──────────────────────────────┘
```

## Usage

```python
from dualstream.retention_manager import RetentionPipeline
from dualstream.storage_validator import LocalFilesystemBackend

pipeline = RetentionPipeline(
    storage_backend=LocalFilesystemBackend("/tmp/artifacts"),
    issuer_key=b"issuer-secret-key-32b",
    validator_key=b"validator-secret-key",
    challenger_key=b"challenger-secret-key",
)

result = pipeline.run_full(
    artifact_id="run-001",
    artifact_bytes=evidence_data,
    profile_name="DSA-CI-Lite",
    issuer_id="governance-1",
    validator_id="storage-validator-1",
)

print(result.overall_status)  # PipelineStatus.COMPLETED
print(result.to_dict())
```

## Step Details

### 1. RetentionRequirement Issuance

- Creates a signed requirement with artifact ID, profile, retention period
- HMAC-SHA256 signed by the issuer's key
- Includes nonce for freshness
- Contains ``min_retention_days`` and ``max_artifact_bytes``

### 2. Artifact Storage

- Uses the ``StorageBackend`` ABC (``LocalFilesystemBackend`` provided)
- Stores the artifact bytes keyed by SHA-256 of the artifact ID

### 3. Storage Validation

- Verifies artifact exists in storage
- Compares stored byte count against expected
- Computes SHA-256 of stored bytes and compares against expected hash

### 4. RetentionReceipt Issuance

- Creates a receipt chained to the requirement via ``requirement_hash``
- Includes artifact content hash, storage backend name, stored byte count
- HMAC-SHA256 signed by the validator's key

### 5. Possession Challenge (optional)

- Issues a random byte-range challenge
- Holder proves possession by computing SHA-256 of the requested range
- Challenge is signed, response is signed
- Verifies: signature, challenge ID match, hash match, expiry

### 6. Chain Verification (optional)

Full 6-step verification:
1. Requirement signature validity
2. Receipt signature validity
3. Hash chain (receipt.requirement_hash == requirement.hash())
4. Artifact content hash match
5. Stored bytes match
6. Requirement expiry check

## Possession Audit

The ``run_possession_audit()`` method runs multiple random byte-range challenges:

```python
audit = pipeline.run_possession_audit(
    artifact_id="run-001",
    artifact_bytes=evidence_data,
    num_challenges=5,
)
# audit['all_passed'] == True
# audit['summary'] == "5/5 challenges passed"
```

## Restore Verification

After storage transforms (replication, compression, encryption), verify the artifact:

```python
result = pipeline.verify_restored_artifact(
    original_bytes=original,
    restored_bytes=restored,
    transform=AllowedTransform.TRANSFORM_REPLICATE,
    retention_floor_bytes=minimum_floor,
)
```

## INCONCLUSIVE_INFRA Retry

When the portable verifier produces an ``INCONCLUSIVE_INFRA`` outcome (artifact may be valid but the verifier's resource environment was insufficient), ``verify_with_retry()`` automatically retries with exponential backoff:

```python
from dualstream.verifier import verify_with_retry, RetryPolicy

report = verify_with_retry(
    path="runs/output",
    profile="DSA-CI-Lite",
    retry_policy=RetryPolicy(max_retries=3),
)
# report.retry_result contains per-attempt metadata
```

## PipelineResult Fields

| Field | Type | Description |
|-------|------|-------------|
| ``overall_status`` | ``PipelineStatus`` | COMPLETED, PARTIAL, or FAILED |
| ``steps`` | ``List[PipelineStepResult]`` | Per-step results with errors |
| ``requirement`` | ``RetentionRequirement`` | Issued requirement |
| ``receipt`` | ``RetentionReceipt`` | Issued receipt |
| ``storage_result`` | ``StorageValidationResult`` | Storage validation details |
| ``challenge_result`` | ``Dict`` | Possession challenge result |
| ``chain_result`` | ``Dict`` | Full chain verification result |