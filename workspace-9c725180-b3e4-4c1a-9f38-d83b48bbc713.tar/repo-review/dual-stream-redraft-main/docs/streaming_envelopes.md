# Streaming-Space Envelopes (§5.3)

Streaming-space envelopes provide evidence integrity guarantees for online/streaming generation contexts where the full artifact is not available until generation completes.

## Problem

In token-by-token generation, evidence must be captured incrementally. Without envelopes, there is no binding between the streaming evidence and the final artifact — a compromised host could substitute evidence mid-stream without detection.

## Solution

The ``EnvelopeSession`` class provides:

1. **Session binding**: A session ID, profile ID, and issuer ID are fixed at open time and cannot be changed.
2. **Cumulative hashing**: Each ingested token record is hashed into a running SHA-256 digest, seeded with the canonical header JSON.
3. **Interim commitments**: Checkpoint hashes at configurable intervals (auto-commit every N tokens, or manual commits).
4. **Canonical order enforcement**: Tokens must be ingested in contiguous, monotonically increasing index order.
5. **Sealing**: The final ``SealedEnvelope`` binds the cumulative hash, all interim commitments, and optionally the final artifact's content hash.
6. **Signature**: The sealed envelope is HMAC-SHA256 signed with the issuer's key.

## Lifecycle

```
EnvelopeSession.open()         → mutable session
  session.ingest(record)       → add token evidence
  session.interim_commitment() → checkpoint hash
  ...                         → repeat for all tokens
  session.seal(artifact_bytes) → SealedEnvelope (immutable)
```

## Verification

``verify_envelope()`` checks:
- Signature verification (HMAC-SHA256)
- Artifact content hash binding
- Interim commitment monotonicity
- Temporal consistency (seal time >= last commit time)

``verify_interim_commitment()`` performs full replay:
- Re-hashes the header + first N token records
- Compares against the stored commitment hash
- Catches mid-stream evidence tampering

## Integration with Compact Evidence

The sealed envelope's ``artifact_content_hash`` should match the V3.3 manifest's ``artifact_content_hash`` field, creating a chain:

```
EnvelopeSession.seal() → SealedEnvelope.artifact_content_hash
                          == V3.3 Manifest.artifact_content_hash
```

## EnvelopePolicy Configuration

| Field | Default | Description |
|-------|---------|-------------|
| ``max_token_count`` | 100,000 | Maximum tokens per session |
| ``max_interim_commits`` | 100 | Maximum checkpoint commits |
| ``commit_interval`` | 100 | Auto-commit every N tokens |
| ``ttl_seconds`` | 3600 | Session expiration |
| ``require_signature`` | True | Require issuer key at open |
| ``enforce_canonical_order`` | True | Enforce contiguous token indexes |

## AST Codes

| Code | Constant | Relevance |
|------|----------|-----------|
| 527 | ``AST_RETENTION_RECEIPT_MISSING_OR_INVALID`` | Envelope verification failure |
| 528 | ``AST_POSSESSION_OR_RESTORE_FAILURE`` | Sealed artifact hash mismatch |