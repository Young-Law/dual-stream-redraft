# Hybrid Adaptive Evidence

DSA v2.10 introduces a hybrid adaptive evidence strategy that widens the retained candidate set beyond the base K when specific trigger conditions are met. This document covers the widening mechanics, profile-level caps, fraction limits, and performance implications.

## Fixed-K vs. Hybrid Adaptive K

### Fixed-K (Policy 2100)

Every token retains exactly `base_k` candidates. No widening occurs regardless of the chosen token's rank. The adaptive policy string is `dsa-v2.10-fixed-base-k-phase1`.

```python
# effective_topk is always base_k
choose_effective_topk(chosen_id, candidates, base_k=3, max_adaptive_k=10, adaptive=False) → 3
```

### Hybrid Rank-Adaptive (Policy 2101)

Tokens may retain more than `base_k` candidates when a trigger condition fires. The adaptive policy string is `dsa-v2.10-hybrid-rank-adaptive-phase1`.

```python
# chosen_id=4 is at rank 4, which is outside base_k=3
choose_effective_topk(4, [1,2,3,4,5], base_k=3, max_adaptive_k=5, adaptive=True) → 4

# chosen_id=2 is at rank 2, which is inside base_k=3
choose_effective_topk(2, [1,2,3,4,5], base_k=3, max_adaptive_k=5, adaptive=True) → 3
```

## Rank-Triggered Adaptive Widening

The primary widening trigger is **rank**: when the model's chosen token falls outside the base K window, the evidence is widened to include it.

### `choose_effective_topk` Logic

```python
def choose_effective_topk(chosen_id, candidate_ids, base_k, max_adaptive_k, adaptive=True):
    base = min(base_k, len(candidate_ids))
    if not adaptive:
        return base
    rank = list(candidate_ids).index(chosen_id) + 1
    if rank <= base:
        return base                # chosen is inside base window, no widening
    return min(max_adaptive_k, max(rank, base))
```

Key behaviors:
- Widening is **rank-based**, not entropy-based. The trigger is the ordinal position of the chosen token in the candidate list.
- If `chosen_id` is not found in `candidate_ids`, rank is treated as `len(candidates) + 1`, which always exceeds `max_adaptive_k` unless the candidate list is very large.
- The result is capped to `max_adaptive_k`.
- The result is also capped to `len(candidate_ids)` (cannot retain more candidates than were produced).

### V3.3 Trigger System

V3.3 uses a bitmask trigger system. Multiple triggers can fire simultaneously on a single token.

| Flag | Hex | Bit | Trigger | Description |
|------|-----|-----|---------|-------------|
| `TRIGGER_RANK` | `0x01` | 0 | Rank | Chosen token rank > base_k and <= max_adaptive_k. |
| `TRIGGER_STOCHASTIC` | `0x02` | 1 | Stochastic | Keyed HMAC-SHA256 random selection fired. |
| `TRIGGER_HISTORY` | `0x04` | 2 | History | Tension-map rule matched for this sequence. |
| `TRIGGER_CANARY` | `0x08` | 3 | Canary | Canary evaluation token. Only allowed in canary-labeled runs. |
| `TRIGGER_ESCALATION` | `0x10` | 4 | Escalation | Reserved for multi-trigger escalation. |

### Trigger Application Order (V3.3)

In `_apply_v33_triggers()`, triggers are evaluated per token:

1. **Tension-map evaluation** (sequence-level): If any rule fires, `TRIGGER_HISTORY` is set for all tokens and `effective_topk` is widened to `max_adaptive_rank`.
2. **Rank check**: If `base_k < chosen_rank <= max_adaptive_rank`, `TRIGGER_RANK` is set and `effective_topk` is widened to the rank.
3. **Canary validation**: If `TRIGGER_CANARY` is set but `canary_eval` is false, encoding raises an error.
4. **Stochastic selection**: For tokens with no other trigger, keyed HMAC-SHA256 sampling may fire `TRIGGER_STOCHASTIC` and widen to `min(max_adaptive_rank, len(topk_ids))`.
5. **Cap**: `effective_topk` is capped to `min(effective_topk, len(topk_ids), max_adaptive_rank)`.

## max_adaptive_k Cap Per Profile

Each evidence profile defines an absolute ceiling on how wide any single token's evidence can be.

| Profile | Base K | Max Adaptive K | Widening Range |
|---------|--------|---------------|----------------|
| `DSA-CI-Lite` | 3 | 10 | Up to 7 additional candidates |
| `DSA-CI-Standard` | 5 | 10 | Up to 5 additional candidates |
| `DSA-Deep` | 5 | 20 | Up to 15 additional candidates |
| `DSA-Forensic` | 5 | 32 | Up to 27 additional candidates |

Enforcement:
- At encode time: `choose_effective_topk` caps the result to `max_adaptive_k`.
- At V3.3 decode time: each token's `effective_topk` is checked against the header's `max_adaptive_rank`. Overflow raises `V3.3 token evidence exceeds declared maximum adaptive K`.
- At verify time: tokens with `chosen_rank > max_adaptive_k` are counted as `rank_overflow_count` (non-fatal tracking, not a hard failure).

## Adaptive Record Fraction Limits

Profiles with `adaptive_record_fraction_limit` enforce a cap on what fraction of tokens may be adaptive (i.e., have `effective_topk > base_k`).

| Profile | Limit | Meaning |
|---------|-------|--------|
| `DSA-CI-Lite` | 5% | At most 5% of tokens may be widened. |
| `DSA-CI-Standard` | 20% | At most 20% of tokens may be widened. |
| `DSA-Deep` | None | No fraction limit. |
| `DSA-Forensic` | None | No fraction limit. |

Enforcement occurs in `verify_evidence_artifact()` after all tokens are decoded:

```python
if prof.adaptive_record_fraction_limit is not None \
   and token_count \
   and adaptive_count / token_count > prof.adaptive_record_fraction_limit:
    raise ValueError("adaptive record fraction exceeds profile limit")
```

This is a **hard failure** that produces `AST_SCHEMA_MISMATCH` (520) in the verification report.

The `VerificationReport` exposes:
- `adaptive_record_count` — absolute count of widened tokens.
- `adaptive_record_fraction` — fraction as a float.

## AST Codes for Adaptive Events

Adaptive widening does not produce AST signals on its own. However, several AST codes are relevant to the adaptive evidence pipeline:

| AST Code | Constant | Relevance |
|----------|----------|-----------|
| 301 | `AST_SYCOPHANCY_PRESSURE` | May appear in span signals on widened tokens. |
| 302 | `AST_ANSWER_EVIDENCE_DIVERGENCE_RISK` | Triggered when the answer diverges from top-K evidence. |
| 303 | `AST_PROBE_EVASION_SUSPICION` | May correlate with high-rank chosen tokens. |
| 305 | `AST_TOP3_CONCEALMENT_TEST_ANOMALY` | Directly related to rank-triggered widening. |
| 520 | `AST_SCHEMA_MISMATCH` | Raised when adaptive fraction exceeds profile limit. |
| 521 | `AST_RETENTION_FLOOR_VIOLATION` | Wider evidence increases the retention floor. |
| 525 | `AST_KEYED_SAMPLING_INTEGRITY_FAILURE` | Stochastic adaptive selection replay failure. |
| 526 | `AST_TENSION_MAP_INVALID_OR_STALE` | Tension-map-driven adaptive widening failure. |

## Performance Implications

### Wire Size

Each additional candidate per token costs 5 bytes (4-byte token ID + 1-byte quantized score) in the V3.2 wire format, and 5 bytes in V3.3 (same `_TOPK_V33` struct). The V3.3 token prefix is 4 bytes (delta-K + rank + trigger flags + record flags) versus 3 bytes in V3.2.

### Encoding Overhead

- Adaptive widening increases per-token record size, directly impacting `raw_bytes_per_token`.
- The profile ceiling constrains the maximum average: CI-Lite allows 24 B/tok, which at base K=3 (21 B/tok for evidence) leaves 3 B/tok for overhead — permitting only ~0.6 additional candidates per token on average.

### Verification Overhead

- `candidate_entries_decoded` in the work certificate is the sum of all `effective_topk` values, directly proportional to verification work.
- The verifier's `tokens_reconstructed_per_second` metric reflects this: more adaptive tokens means lower throughput.
- Resource budgets (time, memory) are profile-specific and account for typical adaptive widening rates.

### Stochastic Selection Cost

When `stochastic_rate_ppm > 0`, the verifier must replay `keyed_sample_selected()` for every token that was not otherwise triggered. Each call computes an HMAC-SHA256 over the full policy context. At 5,000 ppm (the CI-Lite default), approximately 0.5% of tokens receive stochastic widening, but all untriggered tokens require the HMAC computation for replay verification.

### Manifest Overhead

V3.3 adds a 336-byte manifest trailer. For short artifacts this is significant; the 10,000-token minimum budget threshold exists in part to amortize fixed overhead.
