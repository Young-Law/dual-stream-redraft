# Retention Assurance

Retention assurance ensures that compact evidence artifacts retain sufficient data to reconstruct the token-level candidate ranking evidence. This document covers the retention floor calculation, evidence budget profiles, budget status values, and the dataclasses that carry retention state through the pipeline.

## Retention Floor Calculation

The retention floor is the minimum number of bytes an artifact must contain to reconstruct all retained token evidence. It is computed differently depending on the wire format.

### V3.1 / V3.2 Floor (`compute_minimum_reconstructable_bytes`)

Sum of fixed overhead plus per-token evidence:

```
floor = HEADER_SIZE
      + profile_id_bytes
      + profile_metadata_bytes
      + chunk_count × CHUNK_SIZE
      + Σ(token_i_size)        # _TOKEN.size + effective_topk × _TOPK.size
      + fallback_count × 4     # chosen_id u32 for rank-255 tokens
      + span_count × SPAN_SIZE
```

### V3.3 Floor (`v33_minimum_reconstructable_bytes` / `compute_v33_local_minimum_reconstructable_bytes`)

Computed from decoded canonical structures:

```
floor = HEADER_V33_SIZE
      + 32                      # metadata digest
      + len(metadata_bytes)
      + chunk_count × CHUNK_V33_SIZE
      + Σ(token_prefix + effective_topk × TOPK_V33_SIZE
         + 4 if RECORD_HAS_FALLBACK_CHOSEN_ID)
      + Σ(span_bytes)
      + MANIFEST_V33_SIZE
```

The V3.3 manifest embeds this value as `minimum_reconstructable_bytes`. On decode, the verifier recomputes the floor and rejects artifacts where the stored value does not match (`V3.3 minimum reconstructable byte floor mismatch`).

### Per-Token Minimum (`minimum_reconstructable_bytes_per_token`)

Each `EvidenceProfile` exposes a per-token floor formula:

```python
def minimum_reconstructable_bytes_per_token(self, effective_topk=None):
    k = self.base_k if effective_topk is None else int(effective_topk)
    return 6 + max(0, k) * 5
```

This yields the raw wire bytes for one token record (3-byte token prefix + k × 5-byte top-K entries) under the V3.2 layout.

## Evidence Budget Profiles

Four profiles define distinct budgets for evidence density, adaptive widening, verifier resources, and CI compatibility.

| Profile | Ceiling (B/tok) | Base K | Max Adaptive K | CI Modes | Time Limit | Traced Peak (MiB) | Min Tokens | Adaptive Fraction Limit |
|---------|----------------|--------|---------------|----------|-------------|--------------------|------------|------------------------|
| `DSA-CI-Lite` | 24 | 3 | 10 | pr, normal, nightly | 15s | 512 | 10,000 | 5% |
| `DSA-CI-Standard` | 48 | 5 | 10 | nightly, release, release-blocking | 6s | 1,024 | 10,000 | 20% |
| `DSA-Deep` | 96 | 5 | 20 | nightly, probe, adversarial | 30s | 2,048 | 10,000 | none |
| `DSA-Forensic` | 256 | 5 | 32 | incident, forensic, replay | 120s | 4,096 | 10,000 | none |

The `ceiling_bytes_per_token` is the maximum raw bytes per token allowed. The `minimum_budget_token_count` (10,000 for all profiles) is the threshold below which budget evaluation is deferred to `not_evaluated_short_fixture`.

## Budget Status Values

| Status | Meaning |
|--------|--------|
| `pass` | Profile byte budget evaluated and satisfied. |
| `fail` | Raw bytes/token exceeds the profile ceiling. |
| `not_evaluated_short_fixture` | Token count is below the profile's `minimum_budget_token_count` and `strict_profile_budget` is false. Structural and retention-floor checks still ran. |
| `not_evaluated_disabled` | Budget evaluation was disabled by the caller (`enforce_budget=False`). |
| `not_evaluated_due_to_structural_failure` | Decode, metadata binding, or structural verification failed before budget could be computed. |

## RetentionRequirement

```python
@dataclass(frozen=True)
class RetentionRequirement:
    artifact_content_hash: str          # SHA-256 hex of the artifact
    chunk_merkle_root: str              # Merkle root of chunk payload hashes
    minimum_reconstructable_bytes: int  # Retention floor
    profile_hash: str                   # Hash of the evidence profile definition
    schema_hash: str                    # Hash of the wire schema
    required_retention_class: str       # e.g. "DSA-R"
    not_before: float                   # Earliest valid time (epoch)
    retain_until: float                 # Expiration time (epoch)
    allowed_transforms: str             # Permitted storage transformations
    validation_policy_id: str           # Policy that validated this requirement
    issuer_id: str                      # Authority that issued the requirement
    signature: dict[str, str]           # Issuer signature
```

### Lifecycle

1. **Issued** by an authorized authority after artifact validation.
2. **Bound** to a specific artifact via `artifact_content_hash` and `chunk_merkle_root`.
3. **Time-bounded** by `not_before` and `retain_until`.
4. **Present** in the V3.3 manifest as `retention_requirement_hash` (currently zero-filled in Phase 1).

## RetentionReceipt

```python
@dataclass(frozen=True)
class RetentionReceipt:
    retention_requirement_hash: str      # Hash of the RetentionRequirement
    storage_object_id: str               # Storage system identifier
    storage_object_version: str          # Object version in storage
    persisted_content_hash: str          # SHA-256 of persisted bytes
    verified_reconstructable_bytes: int  # Verified floor at storage time
    validation_time: float               # When validation occurred (epoch)
    retain_until: float                  # Expiration time (epoch)
    storage_class: str                   # Storage tier (e.g. "standard", "glacier")
    protection_flags: str                # WORM/lock flags
    validator_id: str                    # Validator that produced the receipt
    receipt_expiry: float                # Receipt validity window
    signature: dict[str, str]            # Validator signature
```

### Lifecycle

1. **Created** by a storage validator after verifying the artifact meets the `RetentionRequirement`.
2. **Chained** to a `RetentionRequirement` via `retention_requirement_hash`.
3. **Verified** by downstream consumers checking the chain: requirement hash → receipt hash → persisted content hash.

> **Status**: Both dataclasses are defined. The end-to-end issuance, storage, and verification pipeline is implemented in `retention_manager.py`, with requirement/receipt lifecycle in `retention_lifecycle.py`, storage validation in `storage_validator.py`, possession challenges in `challenge.py`, and restore verification in `migration.py`. V3.3 manifests include a `retention_requirement_hash` field verified on decode.

## `assert_retention_floor`

```python
def assert_retention_floor(summary: EvidenceBudgetSummary) -> None:
    if summary.retained_reconstructable_bytes < summary.minimum_reconstructable_bytes:
        raise ValueError("retained compact evidence is below the reconstructable floor")
    if summary.token_count <= 0:
        raise ValueError("summary-only artifact has no reconstructable token evidence")
```

Called by the verifier after decoding. Raises `AST_RETENTION_FLOOR_VIOLATION` (521) if the artifact is truncated or summary-only.

## `assert_evidence_budget`

```python
def assert_evidence_budget(summary: EvidenceBudgetSummary) -> None:
    if summary.raw_bytes_per_token > summary.ceiling_bytes_per_token:
        raise ValueError(f"raw bytes/token {summary.raw_bytes_per_token:.3f} exceeds ceiling {summary.ceiling_bytes_per_token}")
```

Raises if raw bytes per token exceeds the profile ceiling. The verifier wraps this as `profile_byte_budget_exceeded`.

## Retention Margin Calculation

The `retention_floor_margin` in `EvidenceBudgetSummary` is computed as:

```
margin = retained_reconstructable_bytes - minimum_reconstructable_bytes
```

For a well-formed artifact that has not been truncated, `retained_reconstructable_bytes` equals the raw artifact byte count. The margin therefore measures how much overhead (metadata, padding, structural framing) exists beyond the bare-minimum reconstructable content. A negative margin indicates a floor violation.

The `VerificationReport` exposes this as `retention_floor_margin_bytes`.
