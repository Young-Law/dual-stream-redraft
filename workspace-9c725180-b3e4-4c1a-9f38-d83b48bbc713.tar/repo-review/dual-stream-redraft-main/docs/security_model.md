# Security Model

## Trust Boundaries

The DSA reference implementation operates across two assurance classes with distinct trust boundaries:

| Class | Scope | Trust Assumption |
|-------|-------|-----------------|
| **DSA-R** (research) | Software-only evidence capture and verification | Host is trusted; no device attestation |
| **DSA-P** (production) | Device-bound attestation with independent retention receipts | Hardware-enforced integrity under compromised-host assumptions |

This codebase implements **DSA-R only**. The software-only path cannot protect against a compromised host that modifies evidence in transit through the model or tampers with the verifier binary. DSA-P claims require external device-bound evidence and independent authorized retention receipts that are **outside this code path**.

## Cryptographic Primitives

| Primitive | Usage | Location |
|-----------|-------|----------|
| **SHA-256** | Artifact content hashing, chunk Merkle roots, metadata digests, header hashes, commit identity, eligibility digests | `compact_evidence.py`, `integrity.py` |
| **CRC32** | Per-chunk payload integrity (detection, not authentication) | `compact_evidence.py` — `binascii.crc32` |
| **HMAC-SHA256** | Work certificate signing, keyed replay selection, audit selection commitments, tension-map signatures | `verifier.py`, `compact_evidence.py`, `tension_map.py` |

### CRC32 Limitation

CRC32 provides error detection only. It does not protect against intentional tampering. V3.3 compensates by also storing a SHA-256 hash per chunk payload, verified during decode (`_sha256(payload) != chunk_hash`). V3.1 and V3.2 rely on CRC32 alone for chunk integrity.

## Key Management

Three distinct key types are used in the DSA-R software path:

### `audit_key` (Evidence Key)

- **Purpose**: Authorizes keyed stochastic selection replay and binds the audit selection commitment to a specific policy context.
- **Format**: Raw `bytes`, identified by a 32-bit `audit_key_id`.
- **Used in**: `keyed_sample_selected()` and `audit_selection_commitment()` in `compact_evidence.py`; `verify_keyed_replay()`.
- **Supply**: Passed as `audit_keys: dict[int, bytes]` to the verifier, keyed by `audit_key_id`.

### `verifier_key` (Work Certificate Key)

- **Purpose**: Signs `VerifierWorkCertificate` outputs so verification work itself is attributable and tamper-evident.
- **Format**: Raw `bytes`.
- **Used in**: `sign_work_certificate()` and `verify_work_certificate_signature()` in `verifier.py`.
- **Supply**: Passed as `verifier_key: bytes | None` to `verify_evidence_artifact()`.

### `tension_keys` (Tension-Map Signing Keys)

- **Purpose**: Signs tension-map YAML documents to ensure rule authenticity and prevent unauthorized widening.
- **Format**: `dict[str, bytes]` mapping `signer_id` to key material.
- **Used in**: `TensionMap.parse_and_verify()` in `tension_map.py`.
- **Signature scheme**: HMAC-SHA256 over a deterministic payload string derived from `map_id` and rule fields.

## Threat Model

### What the Software Path Protects Against

1. **Post-hoc artifact tampering**: SHA-256 artifact content hash in the V3.3 manifest, chunk Merkle root, and per-chunk SHA-256 hashes detect any modification of stored evidence.
2. **Metadata substitution**: V3.3 stores a SHA-256 digest of the metadata JSON immediately after the header. Decoding rejects artifacts where the digest does not match.
3. **Keyed replay forgery**: HMAC-SHA256 commitment binding ensures the stochastic selection cannot be altered after encoding without detection. The verifier recomputes the commit identity, eligibility digest, and per-token stochastic decisions and compares all values.
4. **Tension-map tampering**: Signed tension maps prevent unauthorized rule injection or modification.
5. **Verifier work attribution**: HMAC-signed work certificates make verification results attributable and detect tampering with reported metrics.

### What the Software Path Cannot Protect Against

1. **Compromised host during generation**: An attacker controlling the host at evidence-capture time can inject false top-K rankings, suppress signals, or modify the model's output distribution before evidence is encoded.
2. **Verifier binary substitution**: If the verifier itself is replaced, all checks are bypassed.
3. **Side-channel leakage**: No constant-time guarantees on HMAC or hash comparisons (though `hmac.compare_digest` is used where applicable).
4. **Key compromise**: If any key material is exfiltrated, all guarantees under that key are void.

## Known Limitations

### No CSPRNG in Randomized Audit

`randomized_audit.py` derives a seed from SHA-256 of policy context but then feeds it to Python's `random.Random`, which is **not a CSPRNG**. This module is used for audit-path selection (probe head selection), not for cryptographic key material. An attacker who can predict the seed can predict the audit path.

```python
# From randomized_audit.py
seed = int(hashlib.sha256(seed_material.encode()).hexdigest()[:16], 16)
rng = random.Random(seed)  # Mersenne Twister — not cryptographically secure
```

### No Probe-Pack Signing

Probe packs are referenced by hash in V3.1/V3.2 metadata (`probe_pack_hash`) but no signature verification is performed. The current codebase uses a placeholder hash of `b"none"`. An attacker who can modify the probe pack file can inject malicious probes undetected.

### No Device Attestation

DSA-R makes no claims about the integrity of the model inference runtime. DSA-P (production assurance) requires device-bound attestation, which is explicitly out of scope for this codebase.

## Integrity Guarantees Per Wire Format

### V3.1 (`0x0301`)

- Magic bytes (`DSAEV29\0`) + version field.
- CRC32 per chunk payload.
- Full-artifact SHA-256 digest.
- No metadata digest binding.
- No keyed replay support.

### V3.2 (`0x0302`)

- All V3.1 guarantees.
- Two-byte metadata length (allows larger metadata).
- Compact chosen-rank records with fallback `chosen_id` only when rank is 255.
- Required metadata fields validated during decode (profile, assurance class, signal schema, adaptive policy, etc.).
- No keyed replay support.

### V3.3 (`0x0303`)

- All V3.2 guarantees.
- Explicit version field in a structured header with profile enum, adaptive policy ID, stochastic rate, audit key ID.
- SHA-256 metadata digest bound immediately after the fixed header.
- SHA-256 per-chunk payload hash (in addition to CRC32).
- Chunk Merkle root stored in the manifest.
- Canonical artifact content hash (two-pass: encode with zero hash, compute SHA-256, then re-encode with real hash).
- Keyed replay: commit identity, pre-stochastic eligibility digest, HMAC-SHA256 audit selection commitment.
- Signed tension-map integration (tension map ID and content hash in header).
- Minimum reconstructable byte floor stored in manifest and verified on decode.
