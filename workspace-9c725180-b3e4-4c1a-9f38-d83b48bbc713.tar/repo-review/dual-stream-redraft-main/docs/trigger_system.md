# Trigger System (§6.2)

DSA v2.10 uses a bitmask trigger system in the V3.3 binary format, with four trigger classes providing programmable evaluation logic before encoding.

## Bitmask Flags

| Flag | Hex | Bit | Trigger |
|------|-----|-----|---------|
| ``TRIGGER_RANK`` | ``0x01`` | 0 | Chosen token rank > base_k |
| ``TRIGGER_STOCHASTIC`` | ``0x02`` | 1 | Keyed HMAC random selection |
| ``TRIGGER_HISTORY`` | ``0x04`` | 2 | Tension-map or sequence rule |
| ``TRIGGER_CANARY`` | ``0x08`` | 3 | Canary evaluation token |
| ``TRIGGER_ESCALATION`` | ``0x10`` | 4 | Multi-trigger escalation |

Multiple flags can fire simultaneously on a single token (bitwise OR).

## Trigger Classes

### ThresholdTrigger

Fires when a numeric signal crosses a threshold.

```python
from dualstream.triggers import ThresholdTrigger, ThresholdOperator

entropy_trigger = ThresholdTrigger(
    name="entropy_exceeds_4",
    signal="entropy",
    operator=ThresholdOperator.GTE,
    threshold=4.0,
    trigger_flag=TRIGGER_HISTORY,
)
result = entropy_trigger.evaluate({"entropy": 4.5})
# result.fired == True
```

Supported signals: ``entropy``, ``refusal_mass``, ``risk_score``, ``affirmation_mass``, ``concept_score_max``, ``concept_score_sum``, ``window_suspicious_rate``, ``rolling_entropy_mean``, ``adaptive_fraction``.

Custom signals can be provided via the ``extractor`` callable.

### SequenceTrigger

Fires based on sequence-level patterns over multiple tokens. Supports five modes:

| Mode | Description | Key Parameters |
|------|-------------|----------------|
| ``CONSECUTIVE`` | N consecutive tokens meet a condition | ``count_threshold`` |
| ``ROLLING_WINDOW`` | Rate within last W tokens exceeds threshold | ``window_size``, ``rate_threshold`` |
| ``CUMULATIVE`` | Total count since last reset exceeds threshold | ``count_threshold`` |
| ``HISTORICAL_TENSION`` | Wraps TensionMap evaluation | ``tension_map`` |
| ``EVALUATION_CANARY`` | Fires for every token in canary mode | (context ``canary_eval``) |

```python
from dualstream.triggers import SequenceTrigger, SequenceMode

streak = SequenceTrigger(
    name="entropy_streak",
    mode=SequenceMode.CONSECUTIVE,
    signal="entropy",
    condition=lambda v: v > 3.0,
    count_threshold=5,
    trigger_flag=TRIGGER_HISTORY,
)
```

### CompositeTrigger

Combines multiple child triggers with boolean logic.

| Operator | Behavior |
|----------|----------|
| ``AND`` | All children must fire |
| ``OR`` | Any child must fire |
| ``NOT`` | Inverts a single child |
| ``NAND`` | Not all children fire |
| ``MAJORITY`` | More than half fire |

```python
from dualstream.triggers import CompositeTrigger, CompositeOperator

composite = CompositeTrigger(
    name="high_entropy_and_risk",
    operator=CompositeOperator.AND,
    children=[entropy_trigger, risk_trigger],
    trigger_flag=TRIGGER_ESCALATION,
)
```

### TriggerPipeline

Evaluates a sequence of triggers per token, OR-ing together all fired flags:

```python
from dualstream.triggers import TriggerPipeline

pipeline = TriggerPipeline(triggers=[
    entropy_trigger,
    streak_trigger,
    composite_trigger,
])
result = pipeline.evaluate(context)
# result.trigger_flag = combined bitmask
```

## Integration with Encoding

The trigger classes are designed to be evaluated *before* encoding. The resulting ``trigger_flag`` bitmask is set on each token record's ``trigger_flags`` field. The existing ``_apply_v33_triggers()`` function in ``compact_evidence.py`` handles RANK, STOCHASTIC, HISTORY, and CANARY at the binary level. The new trigger classes provide a higher-level programmable layer:

1. Evaluate ``TriggerPipeline`` per token → get ``trigger_flag``
2. Set the flag on the token record's ``trigger_flags`` before calling ``encode_compact_sequence()``
3. The encoder validates canary isolation and applies the existing bitmask logic

## Stateful Behavior

``SequenceTrigger`` maintains internal state (consecutive counters, rolling windows, cumulative counts). Call ``reset()`` to clear state between sequences.