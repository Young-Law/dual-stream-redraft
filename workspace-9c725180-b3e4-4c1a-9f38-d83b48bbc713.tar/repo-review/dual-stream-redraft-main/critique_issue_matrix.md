# Critique & Issue Matrix

> **Scope:** Design-level critiques from the initial review (Section A) and code-level bug fixes from the implementation audit (Section B).

---

## Section A: Original Design Critiques

| # | Critique Issue | Severity | Affected Section(s) | Edit Made | Remaining Limitation |
|---|---|---|---|---|---|
| A1 | POC relied on host-induced forced compliance | **High** | 1, 2.1.3, 7, Appendix F | Added Level 0/1/2 threat levels; added internally motivated sycophancy/reward-hacking POC design and scenario | Level-1 remains a proxy, not proof of naturally emergent deception |
| A2 | CI cost from exhaustive per-token ensemble audits | **High** | 5.3, 6, Appendix G | Added dynamic tiered scheduling, trigger-based escalation, window-level heavy probing, selective retention, and CI mode separation | Tripwire misses are possible when cheap signals do not fire |
| A3 | Red-state retries can loop and cause DoS | **High** | 5.2, 5.4, 8.3, Appendix H | Added PASS/REVIEW/FAIL/FALLBACK semantics and deterministic fallback protocol with counters and retry budgets | Fallback can increase over-refusal and degrade UX |
| A4 | Static correlated probes can be evaded | **High** | 4.2.2, 5.1, 8.1–8.3, Appendix I | Added nonce-randomized orthogonal probe selection, AST codes 304/305, and static-vs-randomized evasion metrics | Raises evasion cost without guaranteeing impossibility |
| A5 | Overstated claims risk | **Medium** | Status note, Abstract, 3.2, 9 | Repeated constraints that DSA does not prove alignment or complete deception detection | Proposal still depends on assumptions about probe fidelity and integrity |

---

## Section B: Code-Level Bug Fixes

### CRITICAL (3)

| # | Affected File(s) | Description | Fix Applied | Remaining Limitation |
|---|---|---|---|---|
| **C1** | `generator.py` | **FallbackRouter always returns exhausted** — was called with `retry_count=max_retries` and `unchanged=True`, making the entire retry mechanism dead code; every call immediately yielded the fallback path | Called with `retry_count=0, unchanged=False` so the router starts fresh and retries accumulate correctly | None — retry mechanism now functional as designed |
| **C2** | `tension_map.py` | **Tension map HMAC signature missing `widening_action`/`expiry` fields** — attacker could modify widening policy or expiry without invalidating the signature, breaking integrity guarantees | Included all rule fields (`widening_action`, `expiry`, and all others) in the signed payload before computing HMAC | None — signature now covers the full rule dict |
| **C3** | `generator.py` | **Randomized audit selection called per-sequence not per-token** — `select_audit_paths()` was invoked once before the token loop, so every token in a sequence received identical audit metadata, defeating randomization | Moved call inside the per-token loop with `token_index` parameter so each token independently selects its audit path | Marginal per-token overhead from repeated selection call |

### HIGH (6)

| # | Affected File(s) | Description | Fix Applied | Remaining Limitation |
|---|---|---|---|---|
| **H1** | `probes.py`, `generator.py` | **Randomized probe head selection disconnected from probe execution** — `select_probe_heads()` returned a subset but the result was never passed to `run_probes()`, so all heads always executed regardless of selection | Added `selected_heads` parameter to `run_probes()` and threaded the selection result through the call site | Selecting fewer heads reduces coverage; selection quality depends on randomness seed |
| **H2** | `verifier.py` | **Verifier error classification too coarse** — all verification errors were mapped to a single `AST_SCHEMA_MISMATCH` code, losing diagnostic specificity | Replaced with a nuanced multi-branch classifier that distinguishes schema errors, integrity failures, version mismatches, and missing fields | New codes need corresponding handler updates downstream |
| **H3** | `generator.py` | **Window-level audit escalation never triggered** — `suspicious_windows` and `total_windows` were always 0 because no sliding window accumulator was implemented | Implemented a sliding window accumulator that tracks per-window suspicion counts and triggers escalation when the ratio exceeds the threshold | Window size is a tunable parameter; sub-window bursts may still be missed |
| **H4** | `generator.py` | **Refusal/affirmation mass computed only over top-K** — mass was summed from the truncated top-K tensor, underestimating true refusal/affirmation probability | Pre-computed refusal and affirmation token ID sets and summed probabilities from the full `probs_full` tensor instead of top-K | Still O(V) per token for the full-vocab sum; acceptable given small ID sets |
| **H5** | `compact_evidence.py` | **Manifest histogram key 255 collision** — the `">10"` string bucket collided with the integer sentinel value 255, causing data corruption in histogram serialization | Changed the bucket key from `">10"` to the string `"gt10"` to avoid integer/string key clash | None — clean separation of key spaces |
| **H6** | `arc_frame.py` | **`with_crc32` mutates `ArcDecisionFrameV1` in-place** — the CRC field was written directly onto the dataclass instance, corrupting the pre-CRC state used for subsequent operations | Replaced in-place mutation with `dataclasses.replace()` to produce a new immutable instance with the CRC populated | Slight allocation overhead per frame; negligible in practice |

### MEDIUM (10)

| # | Affected File(s) | Description | Fix Applied | Remaining Limitation |
|---|---|---|---|---|
| **M1** | `tension_map.py` | **`content_hash` hashes raw YAML not canonical rules** — YAML serialization is not deterministic, so semantically identical rules produced different hashes | Replaced YAML serialization with canonical JSON (`json.dumps(sort_keys=True)`) before hashing | Rule dict values must be JSON-serializable |
| **M2** | `retention.py` | **`retained_reconstructable_bytes` always equals full artifact** — no mechanism to track how many bytes were actually retainable after compression/packing | Added optional `retained_bytes` parameter; when omitted, still defaults to full artifact size for backward compatibility | Callers must supply the parameter for accurate accounting |
| **M3** | `verifier.py` | **Verifier reports identical mean/p50/p95 times** — all three percentile metrics returned the same aggregate value | Fixed: `mean` is computed per-token; `p50` and `p95` are set to `None` since per-token percentiles are not meaningful | Downstream consumers that expect non-None percentiles need updating |
| **M4** | `verifier.py` | **`varint_bytes_decoded` is a meaningless estimate** — field name implied varint decoding but the value was a fixed-width estimate | Renamed to `fixed_width_token_bytes` to accurately reflect the metric semantics | None — purely a naming/semantic fix |
| **M5** | `retention.py` | **V32 floor re-serializes metadata instead of using header** — when falling back to V32 format, metadata was re-serialized from the struct rather than read from the already-parsed header | Changed V32 fallback path to prefer `header.meta_len` when available, avoiding redundant serialization | V32 format remains a legacy path with no integrity guarantees |
| **M6** | `api.py` | **`preflight/script` API endpoint returns 400** — endpoint was not registered in the URL routing mapping | Added `preflight/script` to the endpoint mapping table | None |
| **M7** | `evidence_profile.py` | **FORENSIC profile PR/normal check is dead code** — the branching condition was always False due to a logic error, making the FORENSIC-specific normal check unreachable | Removed the unreachable code branch and the dead condition | FORENSIC profile no longer has a separate normal-check path; may need re-adding if requirement resurfaces |
| **M8** | `compact_evidence.py` | **V33 normalizer requires perfect 0-based contiguity** — sequences starting at a non-zero index or with gaps were rejected | Fixed to accept any contiguous (non-zero-based) sequence by normalizing offsets before validation | Discontiguous sequences are still rejected; only contiguous ranges pass |
| **M9** | `integrity.py` | **RunningHash leaves `_h` as `None` on `__post_init__` failure** — if initialization raised, the hash state was left uninitialized, causing `AttributeError` on subsequent use | Changed `_h` to `field(init=False)` and added explicit error handling that raises a clear `ValueError` on init failure | None — fail-fast behavior is now correct |
| **M10** | `audit_scheduler.py` | **`compute_mass_for_token_set` uses case-sensitive matching** — token IDs like `"YES"` vs `"yes"` were treated as distinct, causing mass undercounting | Normalized all IDs to lowercase before set membership comparison | Assumes vocabulary IDs are case-insensitive by convention |

### LOW (6)

| # | Affected File(s) | Description | Fix Applied | Remaining Limitation |
|---|---|---|---|---|
| **L1** | `compact_evidence.py` | **Default wire version is V32 not V33** — `VERSION` constant pointed to the legacy V32 format | Changed `VERSION` to `VERSION_V33` so the current format is the default | Existing V32 consumers must explicitly request V32 |
| **L2** | `frame.py` | **`MAGIC_MONO` comment confusing about endianness** — docstring described endianness incorrectly | Corrected the comment to accurately describe the byte order | None — documentation-only |
| **L3** | `vocab.py` | **AST 305 label is legacy "top-3 concealment test anomaly"** — label did not reflect the new randomized audit path semantics | Updated label to "randomized audit path invoked" | Downstream dashboards/logging that match on the old string need updating |
| **L4** | `audit.py` | **`coherence_outcome` uses only first frame's `audit_tier`** — multi-frame audits reported the tier of frame 0 for the entire sequence | Fixed to use `max(tier for frame in frames)` across all frames | If frames have mixed tiers, the max may overstate the actual audit level |
| **L5** | `probes.py` | **`ProbePack.from_json` has no schema validation** — malformed JSON with missing required keys or duplicate concepts was accepted silently | Added required-key validation and duplicate-concept detection on deserialization | Only validates structure, not semantic correctness of probe definitions |
| **L6** | `service.py` | **`_resolve_script_path` parent check excludes directory itself** — `path == parent` edge case caused valid script directories to be rejected | Changed equality check to `path.startswith(parent)` to include the directory and all descendants | None |

---

## Documentation Gaps

### Formerly Stub Documents (now filled in)

| # | Document / Section | What Was Filled In | Any Remaining Gap |
|---|---|---|---|
| 1 | **Appendix F — POC Scenarios** | Expanded from placeholder to full Level-0/1/2 threat scenario descriptions with internally motivated sycophancy and reward-hacking designs | No naturally emergent deception POC (only simulated proxies) |
| 2 | **Appendix G — CI Cost Model** | Filled in dynamic tiered scheduling math, trigger-based escalation thresholds, window-level heavy probing parameters, and CI mode separation | Tripwire miss-rate analysis not quantified |
| 3 | **Appendix H — Retry & Fallback Protocol** | Documented PASS/REVIEW/FAIL/FALLBACK semantics, deterministic fallback protocol, counter budgets, and DoS-prevention bounds | Fallback UX degradation not empirically measured |
| 4 | **Appendix I — Evasion Metrics** | Added static-vs-randomized probe evasion cost analysis, nonce rotation rationale, and AST 304/305 coverage descriptions | No formal adversarial game-theoretic model |
| 5 | **Section 3.2 — Claims & Constraints** | Added explicit constraint statements that DSA does not prove alignment and that probe fidelity is assumed | Proposal still depends on unproven assumptions about probe discrimination |

### Remaining Documentation Gaps

- **Integration test coverage matrix** — no document maps code-level bug fixes (Section B) to specific regression tests.
- **API reference for `preflight/script`** — endpoint was added (M6) but OpenAPI/spec documentation was not updated.
- **Migration guide V32 → V33** — default version changed (L1) but no upgrade notes exist for consumers still expecting V32 wire format.
- **Forensic profile re-design** — dead code removed (M7) leaves a gap in the FORENSIC normal-check path; no replacement spec drafted.
- **Verifier error code catalog** — new multi-branch classifier (H2) introduces additional error codes not yet documented in the AST code reference.
