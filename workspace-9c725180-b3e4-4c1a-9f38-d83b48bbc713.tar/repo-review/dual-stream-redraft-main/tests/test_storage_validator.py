import hashlib
import pytest

from dualstream.storage_validator import (
    LocalFilesystemBackend,
    StorageValidationResult,
    validate_persisted_artifact,
)


@pytest.fixture
def backend(tmp_path):
    return LocalFilesystemBackend(tmp_path / "store")


def test_store_and_retrieve(backend):
    """Store then retrieve should return the same bytes."""
    data = b"hello storage world"
    n = backend.store("art-1", data)
    assert n == len(data)
    assert backend.retrieve("art-1") == data


def test_exists_and_delete(backend):
    """exists() and delete() should work correctly."""
    backend.store("art-2", b"data")
    assert backend.exists("art-2")
    assert backend.delete("art-2")
    assert not backend.exists("art-2")
    assert not backend.delete("art-2")  # already gone


def test_validate_persisted_artifact_valid(backend):
    """Validation should pass for correctly stored artifact."""
    data = b"validate me" * 100
    expected_hash = hashlib.sha256(data).digest()
    backend.store("art-3", data)
    result = validate_persisted_artifact(backend, "art-3", len(data), expected_hash)
    assert result.valid
    assert result.hash_matches
    assert result.size_matches


def test_validate_rejects_missing_artifact(backend):
    """Validation should fail when artifact doesn't exist."""
    result = validate_persisted_artifact(backend, "nonexistent", 10, b"\x00" * 32)
    assert not result.valid
    assert "not found" in result.error


def test_validate_rejects_hash_mismatch(backend):
    """Validation should fail when content hash differs."""
    data = b"real content here"
    backend.store("art-4", data)
    wrong_hash = hashlib.sha256(b"wrong content").digest()
    result = validate_persisted_artifact(backend, "art-4", len(data), wrong_hash)
    assert not result.valid
    assert not result.hash_matches
    assert "hash mismatch" in result.error.lower()


def test_size_returns_correct_value(backend):
    """size() should return the byte length of stored data."""
    data = b"x" * 42
    backend.store("art-5", data)
    assert backend.size("art-5") == 42
    assert backend.size("nonexistent") is None
