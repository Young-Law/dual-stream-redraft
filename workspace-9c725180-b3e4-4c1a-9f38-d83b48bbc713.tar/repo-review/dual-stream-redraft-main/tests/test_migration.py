import pytest

from dualstream.migration import (
    AllowedTransform,
    MigrationVerificationResult,
    verify_after_transform,
)


def test_transform_none_identical_bytes_pass():
    """TRANSFORM_NONE with identical bytes should pass."""
    data = b"untouched artifact content" * 50
    result = verify_after_transform(data, data, AllowedTransform.TRANSFORM_NONE)
    assert result.valid
    assert result.content_intact


def test_transform_none_changed_bytes_fails():
    """TRANSFORM_NONE with different bytes should fail."""
    original = b"original" * 100
    transformed = b"modified" * 100
    result = verify_after_transform(original, transformed, AllowedTransform.TRANSFORM_NONE)
    assert not result.valid
    assert not result.content_intact
    assert any("TRANSFORM_NONE" in e for e in result.errors)


def test_transform_replicate_same_bytes_pass():
    """Replication of identical bytes should pass."""
    data = b"replica" * 200
    result = verify_after_transform(data, data, AllowedTransform.TRANSFORM_REPLICATE)
    assert result.valid
    assert result.content_intact


def test_transform_replicate_different_bytes_fails():
    """Replication with different content should fail."""
    result = verify_after_transform(
        b"origin" * 50, b"differ" * 50, AllowedTransform.TRANSFORM_REPLICATE,
    )
    assert not result.valid
    assert any("differs" in e for e in result.errors)


def test_transform_compress_smaller_passes():
    """Compressed artifact smaller than original should pass."""
    import zlib
    original = b"aaaa" * 1000
    compressed = zlib.compress(original)
    result = verify_after_transform(original, compressed, AllowedTransform.TRANSFORM_COMPRESS)
    assert result.valid
    assert result.content_intact


def test_transform_compress_same_size_fails():
    """Compressed artifact not smaller than original should fail."""
    original = b"short"
    result = verify_after_transform(original, original, AllowedTransform.TRANSFORM_COMPRESS)
    assert not result.valid
    assert any("not smaller" in e for e in result.errors)


def test_transform_encrypt_different_hash_pass():
    """Encrypted artifact with different hash should pass."""
    original = b"plaintext data here" * 20
    # XOR with a key to simulate encryption producing different bytes
    encrypted = bytes(b ^ 0xFF for b in original)
    result = verify_after_transform(original, encrypted, AllowedTransform.TRANSFORM_ENCRYPT)
    assert result.valid


def test_transform_encrypt_same_hash_fails():
    """Encrypted artifact identical to original should fail."""
    data = b"not encrypted at all" * 10
    result = verify_after_transform(data, data, AllowedTransform.TRANSFORM_ENCRYPT)
    assert not result.valid
    assert any("not actually encrypted" in e for e in result.errors)


def test_disallowed_transform_fails():
    """A transform not in the allowed list should fail."""
    data = b"test" * 50
    result = verify_after_transform(
        data, data, AllowedTransform.TRANSFORM_ENCRYPT,
        allowed_transforms=[AllowedTransform.TRANSFORM_COMPRESS],
    )
    assert not result.valid
    assert any("not in allowed" in e for e in result.errors)


def test_retention_floor_violation():
    """TRANSFORM_NONE below retention floor should fail."""
    data = b"big artifact" * 1000
    small = b"tiny"
    result = verify_after_transform(
        data, small, AllowedTransform.TRANSFORM_NONE, retention_floor_bytes=100,
    )
    assert not result.valid
    assert not result.retention_floor_met
    assert any("retention floor" in e for e in result.errors)


def test_transform_reencode_empty_fails():
    """Re-encoding to empty bytes should fail."""
    result = verify_after_transform(b"data", b"", AllowedTransform.TRANSFORM_REENCODE)
    assert not result.valid
    assert any("empty" in e for e in result.errors)


def test_transform_partition_empty_fails():
    """Partitioning to empty bytes should fail."""
    result = verify_after_transform(b"data", b"", AllowedTransform.TRANSFORM_PARTITION)
    assert not result.valid
    assert any("empty" in e for e in result.errors)


def test_result_errors_default_to_empty_list():
    """MigrationVerificationResult.errors should default to []."""
    r = MigrationVerificationResult(
        valid=True, transform="none",
        original_hash=b"\x00"*32, transformed_hash=b"\x00"*32,
        content_intact=True, retention_floor_met=True, verified_at=0.0,
    )
    assert r.errors == []
