import hashlib
import time

import pytest

from dualstream.challenge import (
    ChallengeResponse,
    PossessionChallenge,
    issue_possession_challenge,
    respond_to_challenge,
    verify_possession_challenge,
)

CHALLENGER_KEY = b"challenger-key-secret"
RESPONDER_KEY = b"responder-key-secret"


def _make_artifact(size: int = 1024) -> bytes:
    return b"a" * size


def test_issue_challenge_full_range():
    """Issuing a challenge over the full artifact should work."""
    artifact = _make_artifact(512)
    artifact_id = hashlib.sha256(artifact).hexdigest()
    ch = issue_possession_challenge(artifact_id, artifact, CHALLENGER_KEY)
    assert ch.challenge_id != ""
    assert ch.artifact_id == artifact_id
    assert ch.start_offset == 0
    assert ch.end_offset == 512
    assert ch.signature != b""
    assert ch.expires_at > ch.issued_at


def test_respond_and_verify_success():
    """A valid challenge-response round-trip should verify successfully."""
    artifact = _make_artifact(256)
    artifact_id = hashlib.sha256(artifact).hexdigest()
    challenge = issue_possession_challenge(artifact_id, artifact, CHALLENGER_KEY)
    response = respond_to_challenge(challenge, artifact, "holder-1", RESPONDER_KEY)
    result = verify_possession_challenge(challenge, response, CHALLENGER_KEY)
    assert result["valid"]
    assert result["errors"] == []


def test_verify_fails_with_wrong_artifact():
    """Responding with a different artifact should fail verification."""
    artifact_a = b"artifact-a" * 64
    artifact_b = b"artifact-b" * 64
    aid = hashlib.sha256(artifact_a).hexdigest()
    challenge = issue_possession_challenge(aid, artifact_a, CHALLENGER_KEY)
    response = respond_to_challenge(challenge, artifact_b, "holder-1", RESPONDER_KEY)
    result = verify_possession_challenge(challenge, response, CHALLENGER_KEY)
    assert not result["valid"]
    assert any("hash" in e.lower() for e in result["errors"])


def test_verify_fails_on_expired_challenge():
    """An expired challenge should fail verification."""
    artifact = _make_artifact(64)
    artifact_id = hashlib.sha256(artifact).hexdigest()
    challenge = issue_possession_challenge(artifact_id, artifact, CHALLENGER_KEY, ttl_seconds=0)
    time.sleep(0.05)  # ensure it's expired
    response = respond_to_challenge(challenge, artifact, "holder-1", RESPONDER_KEY)
    result = verify_possession_challenge(challenge, response, CHALLENGER_KEY)
    assert not result["valid"]
    assert any("expired" in e.lower() for e in result["errors"])


def test_challenge_signature_tamper_detected():
    """Tampering with the challenge signature should cause verification failure."""
    artifact = _make_artifact(128)
    artifact_id = hashlib.sha256(artifact).hexdigest()
    challenge = issue_possession_challenge(artifact_id, artifact, CHALLENGER_KEY)
    challenge.signature = b"\x00" * 32  # tamper
    response = respond_to_challenge(challenge, artifact, "holder-1", RESPONDER_KEY)
    result = verify_possession_challenge(challenge, response, CHALLENGER_KEY)
    assert not result["valid"]
    assert any("signature" in e.lower() for e in result["errors"])


def test_partial_range_challenge():
    """A challenge over a partial byte range should verify correctly."""
    artifact = b"hello world this is a test artifact" * 10
    artifact_id = hashlib.sha256(artifact).hexdigest()
    challenge = issue_possession_challenge(
        artifact_id, artifact, CHALLENGER_KEY, start_offset=5, end_offset=20,
    )
    assert challenge.start_offset == 5
    assert challenge.end_offset == 20
    response = respond_to_challenge(challenge, artifact, "holder-1", RESPONDER_KEY)
    result = verify_possession_challenge(challenge, response, CHALLENGER_KEY)
    assert result["valid"]


def test_challenge_id_mismatch_detected():
    """A response with the wrong challenge_id should fail."""
    artifact = _make_artifact(64)
    artifact_id = hashlib.sha256(artifact).hexdigest()
    challenge = issue_possession_challenge(artifact_id, artifact, CHALLENGER_KEY)
    response = respond_to_challenge(challenge, artifact, "holder-1", RESPONDER_KEY)
    response.challenge_id = "wrong-id"
    result = verify_possession_challenge(challenge, response, CHALLENGER_KEY)
    assert not result["valid"]
    assert any("mismatch" in e.lower() for e in result["errors"])


def test_canonical_json_deterministic():
    """to_canonical_json should return the same string on repeated calls."""
    ch = PossessionChallenge(
        challenge_id="c1", artifact_id="a1",
        start_offset=0, end_offset=100,
        expected_hash=b"\x00" * 32, nonce="n1",
    )
    assert ch.to_canonical_json() == ch.to_canonical_json()


def test_response_canonical_json_deterministic():
    """ChallengeResponse.to_canonical_json should be deterministic."""
    r = ChallengeResponse(
        challenge_id="c1", responder_id="r1",
        provided_hash=b"\x00" * 32, nonce="n1",
    )
    assert r.to_canonical_json() == r.to_canonical_json()
