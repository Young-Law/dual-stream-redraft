"""Tests for DSA v2.10 Phase 2 features: envelopes, triggers, retention pipeline, retry."""

import hashlib
import time

import pytest

from dualstream.envelope import (
    EnvelopePolicy,
    EnvelopeSession,
    SealedEnvelope,
    verify_envelope,
    verify_interim_commitment,
)
from dualstream.triggers import (
    CompositeOperator,
    CompositeTrigger,
    SequenceMode,
    SequenceTrigger,
    ThresholdOperator,
    ThresholdTrigger,
    TriggerPipeline,
    TRIGGER_CANARY,
    TRIGGER_ESCALATION,
    TRIGGER_HISTORY,
    TRIGGER_RANK,
    TRIGGER_STOCHASTIC,
)
from dualstream.retention_manager import (
    AllowedTransform,
    PipelineStatus,
    PipelineStep,
    RetentionPipeline,
)
from dualstream.storage_validator import LocalFilesystemBackend


# ============================================================================
# Envelope Tests
# ============================================================================


class TestEnvelopeSession:
    def test_open_and_seal(self):
        session = EnvelopeSession.open(
            session_id="test-sess-1",
            profile_id="DSA-CI-Lite",
            issuer_id="issuer-1",
            retention_policy_id="local-floor-v1",
            issuer_key=b"test-key",
        )
        assert session.state.value == "open"
        assert session.token_count == 0

    def test_ingest_and_seal(self):
        session = EnvelopeSession.open(
            session_id="test-sess-2",
            issuer_id="i",
            issuer_key=b"k",
        )
        for i in range(10):
            session.ingest({"token_index": i, "chosen_id": i * 100, "score": 0.9})
        sealed = session.seal(b"final-artifact-bytes")
        assert sealed.total_tokens == 10
        assert sealed.artifact_content_hash == hashlib.sha256(b"final-artifact-bytes").hexdigest()
        assert sealed.signature != b""
        assert session.state.value == "sealed"

    def test_seal_requires_key(self):
        with pytest.raises(ValueError, match="issuer_key"):
            EnvelopeSession.open(
                session_id="s", issuer_id="i",
            )

    def test_non_contiguous_rejected(self):
        session = EnvelopeSession.open(
            session_id="s", issuer_id="i", issuer_key=b"k",
        )
        session.ingest({"token_index": 0, "data": "a"})
        with pytest.raises(ValueError, match="non-contiguous"):
            session.ingest({"token_index": 2, "data": "b"})

    def test_cannot_ingest_after_seal(self):
        session = EnvelopeSession.open(session_id="s", issuer_id="i", issuer_key=b"k")
        session.ingest({"token_index": 0})
        session.seal()
        with pytest.raises(ValueError, match="sealed"):
            session.ingest({"token_index": 1})

    def test_interim_commitment(self):
        session = EnvelopeSession.open(
            session_id="s", issuer_id="i", issuer_key=b"k",
            policy=EnvelopePolicy(commit_interval=1000),  # no auto-commit
        )
        session.ingest({"token_index": 0, "v": 1.0})
        ic = session.interim_commitment()
        assert ic.token_count == 1
        assert len(ic.cumulative_hash) == 64

    def test_verify_envelope_valid(self):
        session = EnvelopeSession.open(session_id="s", issuer_id="i", issuer_key=b"k")
        for i in range(5):
            session.ingest({"token_index": i, "val": i})
        artifact = b"test-artifact"
        sealed = session.seal(artifact)
        result = verify_envelope(sealed, issuer_key=b"k", artifact_bytes=artifact)
        assert result["valid"]
        assert not result["errors"]

    def test_verify_envelope_wrong_key(self):
        session = EnvelopeSession.open(session_id="s", issuer_id="i", issuer_key=b"k")
        session.ingest({"token_index": 0})
        sealed = session.seal()
        result = verify_envelope(sealed, issuer_key=b"wrong-key")
        assert not result["valid"]
        assert any("signature" in e for e in result["errors"])

    def test_verify_envelope_artifact_mismatch(self):
        session = EnvelopeSession.open(session_id="s", issuer_id="i", issuer_key=b"k")
        session.ingest({"token_index": 0})
        sealed = session.seal(b"real-artifact")
        result = verify_envelope(sealed, issuer_key=b"k", artifact_bytes=b"tampered-artifact")
        assert not result["valid"]
        assert any("hash mismatch" in e for e in result["errors"])

    def test_verify_interim_commitment_replay(self):
        session = EnvelopeSession.open(
            session_id="s", issuer_id="i", issuer_key=b"k",
            policy=EnvelopePolicy(commit_interval=1000),
        )
        records = []
        for i in range(20):
            rec = {"token_index": i, "value": float(i * 0.1)}
            records.append(rec)
            session.ingest(rec)
        # Commit at token 20
        session.interim_commitment()
        sealed = session.seal()
        # Replay and verify
        result = verify_interim_commitment(sealed, 0, records)
        assert result["valid"], result["errors"]

    def test_verify_interim_commitment_tamper(self):
        session = EnvelopeSession.open(
            session_id="s", issuer_id="i", issuer_key=b"k",
            policy=EnvelopePolicy(commit_interval=1000),
        )
        for i in range(5):
            session.ingest({"token_index": i, "v": 1.0})
        session.interim_commitment()
        sealed = session.seal()
        # Tamper with records
        tampered = [{"token_index": 0, "v": 9.0}]  # wrong value
        result = verify_interim_commitment(sealed, 0, tampered)
        assert not result["valid"]


# ============================================================================
# Trigger Tests
# ============================================================================


class TestThresholdTrigger:
    def test_fires_when_above_threshold(self):
        t = ThresholdTrigger(
            name="entropy_high", signal="entropy",
            operator=ThresholdOperator.GTE, threshold=4.0,
            trigger_flag=TRIGGER_HISTORY,
        )
        r = t.evaluate({"entropy": 4.5})
        assert r.fired
        assert r.trigger_flag == TRIGGER_HISTORY

    def test_no_fire_when_below(self):
        t = ThresholdTrigger(name="e", signal="entropy", operator=ThresholdOperator.GTE, threshold=4.0)
        r = t.evaluate({"entropy": 3.5})
        assert not r.fired
        assert r.trigger_flag == 0

    def test_disabled(self):
        t = ThresholdTrigger(name="e", signal="entropy", operator=ThresholdOperator.GTE, threshold=0.0, enabled=False)
        r = t.evaluate({"entropy": 99.0})
        assert not r.fired

    def test_custom_extractor(self):
        t = ThresholdTrigger(
            name="custom", signal="custom",
            operator=ThresholdOperator.GT, threshold=0.5,
            extractor=lambda ctx: ctx.get("my_signal", 0.0),
            trigger_flag=TRIGGER_RANK,
        )
        r = t.evaluate({"my_signal": 0.75})
        assert r.fired

    def test_all_operators(self):
        ctx = {"val": 5.0}
        assert ThresholdTrigger("", "val", ThresholdOperator.GT, 4.0).evaluate(ctx).fired
        assert ThresholdTrigger("", "val", ThresholdOperator.GTE, 5.0).evaluate(ctx).fired
        assert not ThresholdTrigger("", "val", ThresholdOperator.LT, 5.0).evaluate(ctx).fired
        assert ThresholdTrigger("", "val", ThresholdOperator.LTE, 5.0).evaluate(ctx).fired
        assert ThresholdTrigger("", "val", ThresholdOperator.EQ, 5.0).evaluate(ctx).fired
        assert not ThresholdTrigger("", "val", ThresholdOperator.NEQ, 5.0).evaluate(ctx).fired


class TestSequenceTrigger:
    def test_consecutive_fires(self):
        t = SequenceTrigger(
            name="streak", mode=SequenceMode.CONSECUTIVE,
            signal="entropy", condition=lambda v: v > 3.0,
            count_threshold=3, trigger_flag=TRIGGER_HISTORY,
        )
        for val in [3.5, 3.5, 3.5]:
            r = t.evaluate({"entropy": val})
        assert r.fired

    def test_consecutive_resets(self):
        t = SequenceTrigger(
            name="streak", mode=SequenceMode.CONSECUTIVE,
            signal="entropy", condition=lambda v: v > 3.0,
            count_threshold=3,
        )
        t.evaluate({"entropy": 3.5})
        t.evaluate({"entropy": 3.5})
        t.evaluate({"entropy": 1.0})  # breaks streak
        r = t.evaluate({"entropy": 3.5})
        assert not r.fired  # only 1 consecutive

    def test_rolling_window_fires(self):
        t = SequenceTrigger(
            name="suspicious_rate", mode=SequenceMode.ROLLING_WINDOW,
            signal="risk_score", condition=lambda v: v > 0.5,
            window_size=10, rate_threshold=0.6, trigger_flag=TRIGGER_ESCALATION,
        )
        # Push 10 values, 8 of which are suspicious
        for i in range(8):
            t.evaluate({"risk_score": 0.9})
        for i in range(2):
            t.evaluate({"risk_score": 0.1})
        # Now push one more to trigger evaluation (window is full at 10+)
        r = t.evaluate({"risk_score": 0.9})
        assert r.fired

    def test_cumulative_fires(self):
        t = SequenceTrigger(
            name="cum", mode=SequenceMode.CUMULATIVE,
            signal="val", condition=lambda v: v > 0.5,
            count_threshold=5,
        )
        for i in range(5):
            t.evaluate({"val": 1.0})
        r = t.evaluate({"val": 1.0})  # 6th, threshold is 5
        assert r.fired

    def test_canary_mode(self):
        t = SequenceTrigger(
            name="canary", mode=SequenceMode.EVALUATION_CANARY,
            trigger_flag=TRIGGER_CANARY,
        )
        r = t.evaluate({"canary_eval": True})
        assert r.fired
        assert r.trigger_flag == TRIGGER_CANARY

        r2 = t.evaluate({"canary_eval": False})
        assert not r2.fired

    def test_reset(self):
        t = SequenceTrigger(
            name="streak", mode=SequenceMode.CONSECUTIVE,
            signal="v", condition=lambda v: True,
            count_threshold=3,
        )
        t.evaluate({"v": 1.0})
        t.evaluate({"v": 1.0})
        t.reset()
        r = t.evaluate({"v": 1.0})
        assert not r.fired  # only 1 after reset


class TestCompositeTrigger:
    def test_and_fires(self):
        a = ThresholdTrigger("a", "x", ThresholdOperator.GT, 3.0, trigger_flag=TRIGGER_RANK)
        b = ThresholdTrigger("b", "y", ThresholdOperator.GT, 3.0, trigger_flag=TRIGGER_HISTORY)
        c = CompositeTrigger("ab", CompositeOperator.AND, [a, b], trigger_flag=TRIGGER_ESCALATION)
        r = c.evaluate({"x": 4.0, "y": 4.0})
        assert r.fired
        assert r.trigger_flag & TRIGGER_ESCALATION

    def test_and_not_fires(self):
        a = ThresholdTrigger("a", "x", ThresholdOperator.GT, 3.0)
        b = ThresholdTrigger("b", "y", ThresholdOperator.GT, 3.0)
        c = CompositeTrigger("ab", CompositeOperator.AND, [a, b])
        r = c.evaluate({"x": 4.0, "y": 1.0})
        assert not r.fired

    def test_or_fires(self):
        a = ThresholdTrigger("a", "x", ThresholdOperator.GT, 3.0)
        b = ThresholdTrigger("b", "y", ThresholdOperator.GT, 3.0)
        c = CompositeTrigger("ab", CompositeOperator.OR, [a, b])
        r = c.evaluate({"x": 4.0, "y": 1.0})
        assert r.fired

    def test_majority(self):
        triggers = [
            ThresholdTrigger(f"t{i}", f"val{i}", ThresholdOperator.GT, 0.5,
                           extractor=lambda ctx, idx=i: ctx.get(f"val{idx}", 0.0))
            for i in range(3)
        ]
        c = CompositeTrigger("maj", CompositeOperator.MAJORITY, triggers)
        # 2 out of 3 fire
        r = c.evaluate({"val0": 1.0, "val1": 1.0, "val2": 0.0})
        assert r.fired

    def test_empty_children(self):
        c = CompositeTrigger("empty", CompositeOperator.OR, [])
        r = c.evaluate({})
        assert not r.fired


class TestTriggerPipeline:
    def test_pipeline_or(self):
        p = TriggerPipeline([
            ThresholdTrigger("e", "entropy", ThresholdOperator.GTE, 4.0, trigger_flag=TRIGGER_HISTORY),
            ThresholdTrigger("r", "risk", ThresholdOperator.GTE, 0.7, trigger_flag=TRIGGER_ESCALATION),
        ])
        r = p.evaluate({"entropy": 2.0, "risk": 0.8})
        assert r.fired
        assert r.trigger_flag & TRIGGER_ESCALATION
        assert not (r.trigger_flag & TRIGGER_HISTORY)

    def test_pipeline_none_fire(self):
        p = TriggerPipeline([
            ThresholdTrigger("e", "entropy", ThresholdOperator.GTE, 99.0),
        ])
        r = p.evaluate({"entropy": 1.0})
        assert not r.fired

    def test_pipeline_reset(self):
        t = SequenceTrigger("s", mode=SequenceMode.CONSECUTIVE, signal="v", condition=lambda v: True, count_threshold=3)
        p = TriggerPipeline([t])
        for i in range(3):
            p.evaluate({"v": 1.0})
        p.reset()
        r = p.evaluate({"v": 1.0})
        assert not r.fired


# ============================================================================
# Retention Pipeline Tests
# ============================================================================


class TestRetentionPipeline:
    def _make_pipeline(self, tmp_path):
        return RetentionPipeline(
            storage_backend=LocalFilesystemBackend(tmp_path / "artifacts"),
            issuer_key=b"test-issuer-key-32bytes!!",
            validator_key=b"test-validator-key-32by",
            challenger_key=b"test-challenger-key-32b",
        )

    def test_full_pipeline(self, tmp_path):
        pipeline = self._make_pipeline(tmp_path)
        artifact = b"test-evidence-artifact-bytes-" * 100
        result = pipeline.run_full(
            artifact_id="run-full-test",
            artifact_bytes=artifact,
            profile_name="DSA-CI-Lite",
            issuer_id="gov-1",
            validator_id="val-1",
        )
        assert result.overall_status == PipelineStatus.COMPLETED
        assert len(result.steps) >= 5  # at least 5 steps completed
        step_names = [s.step for s in result.steps]
        assert PipelineStep.REQUIREMENT_ISSUED in step_names
        assert PipelineStep.ARTIFACT_STORED in step_names
        assert PipelineStep.STORAGE_VALIDATED in step_names
        assert PipelineStep.RECEIPT_ISSUED in step_names
        assert PipelineStep.CHAIN_VERIFIED in step_names
        assert result.requirement is not None
        assert result.receipt is not None

    def test_pipeline_to_dict(self, tmp_path):
        pipeline = self._make_pipeline(tmp_path)
        result = pipeline.run_full(
            artifact_id="run-dict-test",
            artifact_bytes=b"data" * 50,
            issuer_id="i", validator_id="v",
        )
        d = result.to_dict()
        assert d["artifact_id"] == "run-dict-test"
        assert d["overall_status"] == "completed"
        assert len(d["steps"]) > 0

    def test_possession_audit(self, tmp_path):
        pipeline = self._make_pipeline(tmp_path)
        artifact = b"possession-audit-test-data" * 200
        audit = pipeline.run_possession_audit(
            artifact_id="audit-test",
            artifact_bytes=artifact,
            num_challenges=3,
        )
        assert audit["all_passed"]
        assert audit["summary"] == "3/3 challenges passed"
        assert len(audit["results"]) == 3

    def test_restore_verification_replicate(self):
        from dualstream.migration import verify_after_transform, AllowedTransform
        original = b"test-artifact-restore-data" * 50
        result = verify_after_transform(
            original, original,
            transform=AllowedTransform.TRANSFORM_REPLICATE,
        )
        assert result.valid
        assert result.content_intact

    def test_restore_verification_compress(self):
        import zlib
        from dualstream.migration import verify_after_transform, AllowedTransform
        original = b"test-artifact-compress-data-" * 100
        compressed = zlib.compress(original)
        result = verify_after_transform(
            original, compressed,
            transform=AllowedTransform.TRANSFORM_COMPRESS,
        )
        assert result.valid
        assert len(compressed) < len(original)

    def test_chain_verification_fails_on_tamper(self, tmp_path):
        pipeline = self._make_pipeline(tmp_path)
        artifact = b"original-artifact-data" * 100
        result = pipeline.run_full(
            artifact_id="run-tamper-test",
            artifact_bytes=artifact,
            issuer_id="i", validator_id="v",
        )
        assert result.overall_status == PipelineStatus.COMPLETED
        # Tamper with the stored artifact
        pipeline.storage.store("run-tamper-test", b"tampered-data" * 100)
        # Re-verify the chain should fail on content hash
        from dualstream.retention_lifecycle import verify_receipt_chain
        chain = verify_receipt_chain(
            requirement=result.requirement,
            receipt=result.receipt,
            artifact_bytes=b"tampered-data" * 100,
            issuer_key=b"test-issuer-key-32bytes!!",
            validator_key=b"test-validator-key-32by",
        )
        assert not chain["valid"]


# ============================================================================
# Verifier Retry Tests
# ============================================================================


class TestRetryPolicy:
    def test_retry_policy_defaults(self):
        from dualstream.verifier import RetryPolicy, DEFAULT_RETRY_POLICY
        p = DEFAULT_RETRY_POLICY
        assert p.max_retries == 3
        assert p.backoff_base_seconds == 1.0
        assert p.retry_on_infra_only is True

    def test_retry_policy_custom(self):
        from dualstream.verifier import RetryPolicy
        p = RetryPolicy(max_retries=5, backoff_base_seconds=0.5, backoff_multiplier=3.0)
        assert p.max_retries == 5
        assert p.backoff_multiplier == 3.0
