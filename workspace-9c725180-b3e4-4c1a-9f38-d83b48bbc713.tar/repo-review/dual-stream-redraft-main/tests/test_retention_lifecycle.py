import hashlib
import time

import pytest

from dualstream.retention_lifecycle import (
    RetentionReceipt,
    RetentionRequirement,
    issue_retention_receipt,
    issue_retention_requirement,
    verify_receipt_chain,
    verify_retention_receipt,
    verify_retention_requirement,
)


FIXTURE_KEY = b"test-issuer-key-123"
VALIDATOR_KEY = b"test-validator-key-456"


def test_issue_and_verify_requirement():
    """A freshly issued requirement should pass signature verification."""
    req = issue_retention_requirement(
        artifact_id="abc123",
        profile_name="DSA-CI-Lite",
        issuer_id="gov-1",
        issuer_key=FIXTURE_KEY,
    )
    assert req.nonce != ""
    assert req.signature != b""
    assert verify_retention_requirement(req, FIXTURE_KEY)


def test_requirement_signature_rejects_wrong_key():
    """Verification with a different key must fail."""
    req = issue_retention_requirement(
        artifact_id="abc123",
        profile_name="DSA-CI-Lite",
        issuer_id="gov-1",
        issuer_key=FIXTURE_KEY,
    )
    assert not verify_retention_requirement(req, b"wrong-key")


def test_issue_and_verify_receipt_chain():
    """Full chain: requirement → receipt → artifact should be valid."""
    artifact = b"some artifact content here" * 10
    req = issue_retention_requirement(
        artifact_id=hashlib.sha256(artifact).hexdigest(),
        profile_name="DSA-CI-Standard",
        issuer_id="gov-1",
        issuer_key=FIXTURE_KEY,
    )
    receipt = issue_retention_receipt(
        requirement=req,
        artifact_bytes=artifact,
        storage_backend="local-fs",
        validator_id="val-1",
        validator_key=VALIDATOR_KEY,
    )
    result = verify_receipt_chain(req, receipt, artifact, FIXTURE_KEY, VALIDATOR_KEY)
    assert result["valid"]
    assert result["errors"] == []


def test_receipt_chain_fails_on_content_tamper():
    """Tampering with artifact bytes after receipt issuance should break the chain."""
    artifact = b"original content" * 5
    req = issue_retention_requirement(
        artifact_id=hashlib.sha256(artifact).hexdigest(),
        profile_name="DSA-CI-Deep",
        issuer_id="gov-1",
        issuer_key=FIXTURE_KEY,
    )
    receipt = issue_retention_receipt(
        requirement=req,
        artifact_bytes=artifact,
        storage_backend="local-fs",
        validator_id="val-1",
        validator_key=VALIDATOR_KEY,
    )
    tampered = artifact[:-1] + b"X"
    result = verify_receipt_chain(req, receipt, tampered, FIXTURE_KEY, VALIDATOR_KEY)
    assert not result["valid"]
    assert any("hash mismatch" in e.lower() for e in result["errors"])


def test_requirement_canonical_json_deterministic():
    """Calling to_canonical_json twice should produce identical output."""
    req = RetentionRequirement(
        artifact_id="id1",
        profile_name="DSA-CI-Lite",
        issuer_id="gov-1",
        min_retention_days=90,
        max_artifact_bytes=1000,
        nonce="fixed-nonce",
    )
    assert req.to_canonical_json() == req.to_canonical_json()


def test_expired_requirement_fails_chain():
    """A requirement with a past expires_at should cause chain failure."""
    import secrets
    artifact = b"test data for expiry"
    req = RetentionRequirement(
        artifact_id=hashlib.sha256(artifact).hexdigest(),
        profile_name="DSA-CI-Lite",
        issuer_id="gov-1",
        min_retention_days=90,
        max_artifact_bytes=1000,
        expires_at=time.time() - 10,  # expired 10s ago
        nonce=secrets.token_hex(16),
    )
    canonical = req.to_canonical_json()
    req.signature = hashlib.sha256(canonical.encode()).digest()  # self-signed for simplicity
    receipt = issue_retention_receipt(
        requirement=req,
        artifact_bytes=artifact,
        storage_backend="local-fs",
        validator_id="val-1",
        validator_key=VALIDATOR_KEY,
    )
    # Use the same key for both since we self-signed
    result = verify_receipt_chain(req, receipt, artifact, FIXTURE_KEY, VALIDATOR_KEY)
    # signature may not match our HMAC key, but expiry should be flagged
    assert any("expired" in e.lower() for e in result["errors"]) or not result["valid"]
