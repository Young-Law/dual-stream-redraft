import { NextResponse } from 'next/server'

const gaps = [
  { id: 1, description: 'No retention receipt validation tests', category: 'Retention' },
  { id: 2, description: 'No possession proof tests', category: 'Retention' },
  { id: 3, description: 'No restore test fixtures', category: 'Retention' },
  { id: 4, description: 'No canary trigger isolation tests', category: 'Triggers' },
  { id: 5, description: 'No environment-chaos INCONCLUSIVE_INFRA vs FAIL tests', category: 'Infrastructure' },
  { id: 6, description: 'No streaming-space envelope boundary tests', category: 'Envelopes' },
  { id: 7, description: 'No V3.3 multi-chunk artifact tests', category: 'Wire Format' },
  { id: 8, description: 'No keyed selection rate statistical accuracy tests', category: 'Selection' },
  { id: 9, description: 'No INCONCLUSIVE_INFRA retry behavior tests', category: 'Infrastructure' },
  { id: 10, description: 'No adaptive_k boundary condition tests', category: 'Adaptive' },
]

export async function GET() {
  return NextResponse.json(gaps)
}
