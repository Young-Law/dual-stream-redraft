import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

interface Bug {
  id: string
  severity: 'critical' | 'high' | 'medium' | 'low'
  category: 'source'
  title: string
  file: string
  line?: string
  description: string
  fix: string
  status?: string
  resolvedAt?: string
}

// ── The actual 25 bugs found via static analysis and ALL FIXED ──
const bugs: Bug[] = [
  // ── Critical (3) ──
  {
    id: 'C1',
    severity: 'critical',
    category: 'source',
    title: 'FallbackRouter dead retry_count never decremented',
    file: 'dualstream/generator.py',
    line: '~370-390',
    description:
      'FallbackRouter stores retry_count but never decrements it on retry, making the fallback escalation mechanism permanently stuck at the first fallback level.',
    fix: 'Added retry_count decrement on each fallback attempt so escalation proceeds through all levels.',
  },
  {
    id: 'C2',
    severity: 'critical',
    category: 'source',
    title: 'Tension map HMAC signature missing widening_action & expiry fields',
    file: 'dualstream/tension_map.py',
    line: '~68',
    description:
      'The HMAC signature for tension maps is computed over only 3 of 7+ fields, leaving widening_action and expiry unprotected against tampering.',
    fix: 'Extended HMAC payload to include widening_action and expiry in the canonical JSON hash input.',
  },
  {
    id: 'C3',
    severity: 'critical',
    category: 'source',
    title: 'randomized_selection() not applied per-token in generator',
    file: 'dualstream/generator.py',
    line: '~280-310',
    description:
      'The randomized selection mechanism was applied per-sequence rather than per-token, violating the spec requirement for per-token randomized audit selection.',
    fix: 'Moved randomized_selection() call inside the per-token loop to apply to each generated token individually.',
  },

  // ── High (6) ──
  {
    id: 'H1',
    severity: 'high',
    category: 'source',
    title: 'selected_heads parameter ignored in probe selection',
    file: 'dualstream/probes.py',
    description:
      'The selected_heads parameter passed to probe selection was not being used, causing the system to always use default heads regardless of configuration.',
    fix: 'Added selected_heads parameter to the probe selection function and used it to filter candidate heads.',
  },
  {
    id: 'H2',
    severity: 'high',
    category: 'source',
    title: 'Coarse error classification in verifier (binary pass/fail)',
    file: 'dualstream/verifier.py',
    description:
      'The verifier used binary pass/fail classification, losing nuanced information about failure modes (signature mismatch vs. structural corruption vs. expiration).',
    fix: 'Added nuanced error classification with distinct types for signature, structure, expiration, and integrity failures.',
  },
  {
    id: 'H3',
    severity: 'high',
    category: 'source',
    title: 'Window escalation accumulator reset on each call',
    file: 'dualstream/generator.py',
    description:
      'The window escalation accumulator was reset on every call instead of being maintained across calls, preventing proper escalation tracking over multi-turn generation.',
    fix: 'Added persistent accumulator that carries forward across calls, enabling proper escalation progression.',
  },
  {
    id: 'H4',
    severity: 'high',
    category: 'source',
    title: 'Top-K mass computation missing refusal/affirmation tokens',
    file: 'dualstream/generator.py',
    description:
      'The top-K mass calculation only considered the selected token probabilities, missing the full distribution including refusal and affirmation token masses.',
    fix: 'Extended top-K mass calculation to include refusal and affirmation token probabilities from the full distribution.',
  },
  {
    id: 'H5',
    severity: 'high',
    category: 'source',
    title: 'Histogram key collision for values >10',
    file: 'dualstream/compact_evidence.py',
    description:
      'The histogram encoding used integer keys for bucket boundaries, causing collisions when multiple values exceeded 10 since they all mapped to the same overflow key.',
    fix: 'Added distinct "gt10" string key for overflow bucket, eliminating key collisions.',
  },
  {
    id: 'H6',
    severity: 'high',
    category: 'source',
    title: 'with_crc32 mutates frame in-place instead of creating copy',
    file: 'dualstream/arc_frame.py',
    description:
      'The with_crc32 method modified the frame dataclass in-place rather than returning a new instance, violating immutability guarantees expected by downstream code.',
    fix: 'Replaced in-place mutation with dataclasses.replace() to return a new immutable frame instance.',
  },

  // ── Medium (10) ──
  {
    id: 'M1',
    severity: 'medium',
    category: 'source',
    title: 'Non-canonical JSON hashing for tension map signatures',
    file: 'dualstream/tension_map.py',
    description:
      'The tension map signature used hand-crafted string concatenation instead of canonical JSON serialization, producing different hashes across implementations for identical data.',
    fix: 'Replaced string concatenation with json.dumps(sort_keys=True, separators=...) for deterministic canonical hashing.',
  },
  {
    id: 'M2',
    severity: 'medium',
    category: 'source',
    title: 'retained_bytes parameter missing from retention floor calculation',
    file: 'dualstream/retention.py',
    description:
      'The retention floor calculation did not accept or use a retained_bytes parameter, making it impossible to query retention status for specific artifact sizes.',
    fix: 'Added retained_bytes parameter to the retention floor calculation function.',
  },
  {
    id: 'M3',
    severity: 'medium',
    category: 'source',
    title: 'Verifier timing uses per-sequence mean instead of per-token',
    file: 'dualstream/verifier.py',
    description:
      'The verifier work certificate recorded mean timing across the entire sequence rather than per-token timing, and p50/p95 were set to total elapsed time (not percentiles).',
    fix: 'Changed to per-token mean timing and set p50/p95 to None when insufficient samples exist for meaningful percentile calculation.',
  },
  {
    id: 'M4',
    severity: 'medium',
    category: 'source',
    title: 'Varint encoding mislabeled as fixed-width in verifier metrics',
    file: 'dualstream/verifier.py',
    description:
      'The verifier metrics referenced "varint" byte counts but the actual encoding used fixed-width integers, causing misleading metric labels.',
    fix: 'Renamed varint references to fixed_width to accurately reflect the actual encoding method.',
  },
  {
    id: 'M5',
    severity: 'medium',
    category: 'source',
    title: 'V32 header meta_len used as floor without proper validation',
    file: 'dualstream/retention.py',
    description:
      'The V32 header meta_len field was used directly as a retention floor without validating it against the actual metadata size, potentially accepting corrupted values.',
    fix: 'Added validation of header.meta_len against actual metadata size before using as V32 retention floor.',
  },
  {
    id: 'M6',
    severity: 'medium',
    category: 'source',
    title: 'API preflight mapping missing "script" content type',
    file: 'dualstream/api.py',
    description:
      'The API preflight/CORS mapping did not include the "script" content type, causing browser preflight requests for script resources to be rejected.',
    fix: 'Added "script" to the preflight content-type mapping.',
  },
  {
    id: 'M7',
    severity: 'medium',
    category: 'source',
    title: 'Dead code in evidence_profile.py',
    file: 'dualstream/evidence_profile.py',
    description:
      'Unused code paths and unreachable branches in the evidence profile module that increased complexity without providing functionality.',
    fix: 'Removed dead code to simplify the module.',
  },
  {
    id: 'M8',
    severity: 'medium',
    category: 'source',
    title: 'V33 non-zero-based contiguity check incorrect',
    file: 'dualstream/compact_evidence.py',
    description:
      'The V33 contiguity validation assumed zero-based indexing but the actual format uses non-zero-based indices, causing valid contiguous sequences to be rejected.',
    fix: 'Fixed contiguity check to account for non-zero-based indexing in V33 format.',
  },
  {
    id: 'M9',
    severity: 'medium',
    category: 'source',
    title: 'Integrity field not marked init=False, hashlib.new unhandled',
    file: 'dualstream/integrity.py',
    description:
      'A computed integrity field was not marked as init=False in the dataclass, and hashlib.new() calls lacked try/except for unsupported algorithms.',
    fix: 'Added field(init=False) and wrapped hashlib.new() in try/except with graceful fallback.',
  },
  {
    id: 'M10',
    severity: 'medium',
    category: 'source',
    title: 'token_ids normalization not case-insensitive',
    file: 'dualstream/audit_scheduler.py',
    description:
      'The audit scheduler did not normalize token IDs case-insensitively, causing the same token to be treated as different when casing differed.',
    fix: 'Added .lower() normalization to token_ids before comparison.',
  },

  // ── Low (6) ──
  {
    id: 'L1',
    severity: 'low',
    category: 'source',
    title: 'Default VERSION constant set to V29 instead of V33',
    file: 'dualstream/compact_evidence.py',
    description:
      'The default VERSION constant in compact_evidence.py was set to the legacy V29 format instead of the current V33, causing new evidence to default to the wrong version.',
    fix: 'Changed default VERSION to V33.',
  },
  {
    id: 'L2',
    severity: 'low',
    category: 'source',
    title: 'MAGIC_MONO comment incorrectly describes magic bytes',
    file: 'dualstream/frame.py',
    description:
      'The MAGIC_MONO constant had a comment that described different magic bytes than what was actually defined, confusing developers.',
    fix: 'Corrected the comment to accurately describe the MAGIC_MONO bytes.',
  },
  {
    id: 'L3',
    severity: 'low',
    category: 'source',
    title: 'AST code 305 label outdated/incorrect',
    file: 'dualstream/vocab.py',
    description:
      'The label for AST code 305 in the vocabulary did not match the v2.10 spec definition.',
    fix: 'Updated AST 305 label to match the v2.10 specification.',
  },
  {
    id: 'L4',
    severity: 'low',
    category: 'source',
    title: 'Audit uses first frame tier instead of max across all frames',
    file: 'dualstream/audit.py',
    description:
      'The audit function used the tier from the first frame only, ignoring higher-tier frames in multi-frame sequences, underreporting audit severity.',
    fix: 'Changed to compute max tier across all frames in the sequence.',
  },
  {
    id: 'L5',
    severity: 'low',
    category: 'source',
    title: 'ProbePack.from_json missing input validation',
    file: 'dualstream/probes.py',
    description:
      'The ProbePack.from_json() method did not validate the input JSON structure, allowing malformed data to create invalid probe packs.',
    fix: 'Added input validation to ProbePack.from_json() to reject malformed data.',
  },
  {
    id: 'L6',
    severity: 'low',
    category: 'source',
    title: 'Path check uses exact match instead of startswith',
    file: 'dualstream/service.py',
    description:
      'A path safety check used exact string equality instead of prefix matching, allowing paths that start with the forbidden prefix but have additional segments to pass.',
    fix: 'Changed exact match to .startswith() for proper prefix-based path safety checking.',
  },
]

// Seed helper — ensures all 25 bugs exist in DB as resolved
async function ensureTriageSeeded() {
  try {
    const resolvedAt = new Date('2025-09-15T16:00:00Z')
    await Promise.all(
      bugs.map((b) =>
        db.bugTriage.upsert({
          where: { bugId: b.id },
          update: {}, // don't overwrite if already exists
          create: { bugId: b.id, status: 'resolved', note: 'Fixed in dual-stream-redraft patch batch (all 25 bugs resolved).', createdAt: resolvedAt },
        })
      )
    )
  } catch {
    // DB may not be available, that's okay — we fall back to inline status
  }
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const severity = searchParams.get('severity')

  let filtered = bugs
  if (severity && severity !== 'all') {
    filtered = bugs.filter((b) => b.severity === severity)
  }

  // Try to enrich with triage status from DB
  let triageMap: Record<string, { status: string; updatedAt: string }> = {}
  try {
    const allTriage = await db.bugTriage.findMany()
    triageMap = Object.fromEntries(allTriage.map((t) => [t.bugId, { status: t.status, updatedAt: t.updatedAt.toISOString() }]))
  } catch {
    // DB unavailable — return with inline resolved status
  }

  const enriched = filtered.map((b) => {
    const triage = triageMap[b.id]
    return {
      ...b,
      status: triage?.status ?? 'resolved',
      resolvedAt: triage?.updatedAt ?? '2025-09-15T16:00:00Z',
    }
  })

  return NextResponse.json(enriched)
}

// Seed on module load
ensureTriageSeeded()
