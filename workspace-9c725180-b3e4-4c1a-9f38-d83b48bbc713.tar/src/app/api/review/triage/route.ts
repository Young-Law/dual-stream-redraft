import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const bugId = searchParams.get('bugId')
  if (bugId) {
    const triage = await db.bugTriage.findUnique({ where: { bugId } })
    return NextResponse.json(triage ?? { bugId, status: 'none', note: null })
  }
  const all = await db.bugTriage.findMany({ orderBy: { updatedAt: 'desc' } })
  return NextResponse.json(all)
}

export async function POST(request: NextRequest) {
  try {
    const { bugId, status, note } = await request.json()
    if (!bugId || !status) {
      return NextResponse.json({ error: 'bugId and status required' }, { status: 400 })
    }
    const validStatuses = ['none', 'acknowledged', 'in-progress', 'resolved']
    if (!validStatuses.includes(status)) {
      return NextResponse.json({ error: 'Invalid status' }, { status: 400 })
    }
    const triage = await db.bugTriage.upsert({
      where: { bugId },
      update: { status, note: note ?? null },
      create: { bugId, status, note: note ?? null },
    })
    return NextResponse.json(triage)
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
