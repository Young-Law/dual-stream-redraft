import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const { bugIds, status } = await request.json()
    if (!Array.isArray(bugIds) || !status) {
      return NextResponse.json({ error: 'bugIds array and status required' }, { status: 400 })
    }
    const validStatuses = ['none', 'acknowledged', 'in-progress', 'resolved']
    if (!validStatuses.includes(status)) {
      return NextResponse.json({ error: 'Invalid status' }, { status: 400 })
    }
    const results = await Promise.all(
      bugIds.map((bugId: string) =>
        db.bugTriage.upsert({
          where: { bugId },
          update: { status },
          create: { bugId, status },
        })
      )
    )
    return NextResponse.json({ updated: results.length, status })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
