import { NextResponse } from 'next/server'

const violations = [
  {
    id: 1,
    section: 'paper §5.3',
    violation: 'Streaming-space envelopes fully implemented',
    detail: 'IMPLEMENTED: EnvelopeSession with cumulative SHA-256 hashing, interim commitments, sealed envelopes with HMAC signatures, canonical order enforcement, and full post-hoc verification with interim commitment replay.',
    status: 'resolved',
  },
  {
    id: 2,
    section: 'paper §6.2',
    violation: 'All trigger classes implemented',
    detail: 'IMPLEMENTED: ThresholdTrigger (6 operators, 9 signals, custom extractors), SequenceTrigger (5 modes: consecutive, rolling_window, cumulative, historical_tension, evaluation_canary), CompositeTrigger (5 operators: AND, OR, NOT, NAND, MAJORITY), TriggerPipeline.',
    status: 'resolved',
  },
  {
    id: 3,
    section: 'paper §7',
    violation: 'Retention assurance fully implemented',
    detail: 'IMPLEMENTED: Signed requirements, receipt issuance, chain verification, storage validation, possession challenges, migration policies, and RetentionPipeline orchestrating the full lifecycle.',
    status: 'resolved',
  },
  {
    id: 4,
    section: 'paper §6.4',
    violation: 'Tension map signature covers all fields',
    detail: 'FIXED: HMAC signature uses canonical JSON and covers all fields including widening_action and expiry.',
    status: 'resolved',
  },
  {
    id: 5,
    section: 'paper §5.4',
    violation: 'Verifier metrics use real per-token timing',
    detail: 'IMPLEMENTED: Per-token mean/p50/p95 reconstruction timing. Compressed bytes-per-token via zlib.',
    status: 'resolved',
  },
  {
    id: 6,
    section: 'paper §5.5',
    violation: 'INCONCLUSIVE_INFRA retry with metadata',
    detail: 'IMPLEMENTED: verify_with_retry() with RetryPolicy (max_retries, exponential backoff), RetryAttempt/RetryResult dataclasses, per-attempt metrics.',
    status: 'resolved',
  },
  {
    id: 7,
    violation: 'Evidence frame immutability restored',
    section: 'paper §4.1',
    detail: 'FIXED: with_crc32 uses dataclasses.replace() for immutability.',
    status: 'resolved',
  },
  {
    id: 8,
    violation: 'V3.3 header fields use actual profile values',
    section: 'paper §4.2',
    detail: 'IMPLEMENTED: All 6 header fields use named profile constants with decode-time range validation.',
    status: 'resolved',
  },
  {
    id: 9,
    violation: 'Manifest retention hash chaining implemented',
    section: 'paper §4.5',
    detail: 'IMPLEMENTED: RetentionRequirement SHA-256 hash embedded in manifest. Verifier cross-checks on decode.',
    status: 'resolved',
  },
]

export async function GET() {
  return NextResponse.json(violations)
}
