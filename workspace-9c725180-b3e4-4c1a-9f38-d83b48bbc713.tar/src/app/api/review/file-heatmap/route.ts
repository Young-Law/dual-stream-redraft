import { NextResponse } from 'next/server'

const data = [
  { file: 'compact_evidence.py', bugs: 5, critical: 1, high: 2, medium: 2, low: 0, category: 'core' },
  { file: 'verifier.py', bugs: 3, critical: 1, high: 0, medium: 1, low: 0, category: 'core' },
  { file: 'generator.py', bugs: 2, critical: 1, high: 0, medium: 0, low: 1, category: 'core' },
  { file: 'audit.py', bugs: 1, critical: 1, high: 0, medium: 0, low: 0, category: 'core' },
  { file: 'tension_map.py', bugs: 2, critical: 0, high: 1, medium: 0, low: 0, category: 'core' },
  { file: 'vocab.py', bugs: 1, critical: 0, high: 0, medium: 1, low: 0, category: 'core' },
  { file: 'api.py', bugs: 1, critical: 0, high: 1, medium: 0, low: 0, category: 'service' },
  { file: 'cli.py', bugs: 1, critical: 0, high: 0, medium: 0, low: 1, category: 'service' },
  { file: 'v210.py', bugs: 1, critical: 0, high: 0, medium: 0, low: 1, category: 'core' },
  { file: 'test_tension_map.py', bugs: 1, critical: 1, high: 0, medium: 0, low: 0, category: 'test' },
  { file: 'test_api_browser_ui.py', bugs: 1, critical: 0, high: 1, medium: 0, low: 0, category: 'test' },
  { file: 'test_v210_conformance.py', bugs: 1, critical: 0, high: 1, medium: 0, low: 0, category: 'test' },
  { file: 'test_v26_pipeline.py', bugs: 1, critical: 0, high: 1, medium: 0, low: 0, category: 'test' },
  { file: 'test_fallback.py', bugs: 1, critical: 0, high: 1, medium: 0, low: 0, category: 'test' },
]

export async function GET() {
  return NextResponse.json(data.sort((a, b) => b.bugs - a.bugs))
}
