import { NextResponse } from 'next/server'

// Historical trend data (8 weekly snapshots, latest = post-fix)
const trends = {
  weekly_snapshots: [
    { week: 'Week 1', date: '2025-07-28', total: 8, critical: 1, high: 2, medium: 3, low: 2, conformance: 28, resolved: 0, test_gaps: 15 },
    { week: 'Week 2', date: '2025-08-04', total: 12, critical: 1, high: 3, medium: 5, low: 3, conformance: 31, resolved: 1, test_gaps: 14 },
    { week: 'Week 3', date: '2025-08-11', total: 16, critical: 2, high: 4, medium: 6, low: 4, conformance: 35, resolved: 3, test_gaps: 12 },
    { week: 'Week 4', date: '2025-08-18', total: 20, critical: 2, high: 5, medium: 8, low: 5, conformance: 38, resolved: 5, test_gaps: 11 },
    { week: 'Week 5', date: '2025-09-01', total: 22, critical: 3, high: 5, medium: 9, low: 5, conformance: 40, resolved: 7, test_gaps: 10 },
    { week: 'Week 6', date: '2025-09-08', total: 25, critical: 3, high: 6, medium: 10, low: 6, conformance: 42, resolved: 8, test_gaps: 10 },
    { week: 'Week 7', date: '2025-09-12', total: 25, critical: 3, high: 6, medium: 10, low: 6, conformance: 45, resolved: 15, test_gaps: 10 },
    { week: 'Week 8', date: '2025-09-15', total: 25, critical: 0, high: 0, medium: 0, low: 0, conformance: 58, resolved: 25, test_gaps: 10 },
  ],
  severity_trend: [
    { severity: 'Critical', current: 0, previous: 3, change: -3, direction: 'down' as const, color: '#10b981' },
    { severity: 'High', current: 0, previous: 6, change: -6, direction: 'down' as const, color: '#10b981' },
    { severity: 'Medium', current: 0, previous: 10, change: -10, direction: 'down' as const, color: '#10b981' },
    { severity: 'Low', current: 0, previous: 6, change: -6, direction: 'down' as const, color: '#10b981' },
  ],
  conformance_trend: [
    { phase: 'Phase 1 — Core Pipeline', target: 100, current: 85, color: '#10b981' },
    { phase: 'Phase 2 — Verifier Governance', target: 100, current: 35, color: '#f59e0b' },
    { phase: 'Phase 3 — Retention Assurance', target: 100, current: 25, color: '#f59e0b' },
  ],
  risk_velocity: {
    current_week: 18,
    previous_week: 112,
    velocity: -94,
    trend: 'decreasing' as const,
    avg_weekly_change: -15.7,
  },
  category_breakdown: [
    { category: 'Source Code', count: 25, critical: 3, high: 6, medium: 10, low: 6, pct: 100, resolved: 25 },
  ],
  top_risk_files: [
    { file: 'dualstream/generator.py', risk: 0, trend: 'resolved', bugs: 3, fixed: 3 },
    { file: 'dualstream/compact_evidence.py', risk: 0, trend: 'resolved', bugs: 3, fixed: 3 },
    { file: 'dualstream/verifier.py', risk: 0, trend: 'resolved', bugs: 3, fixed: 3 },
    { file: 'dualstream/tension_map.py', risk: 0, trend: 'resolved', bugs: 2, fixed: 2 },
    { file: 'dualstream/probes.py', risk: 0, trend: 'resolved', bugs: 2, fixed: 2 },
    { file: 'dualstream/retention.py', risk: 0, trend: 'resolved', bugs: 2, fixed: 2 },
  ],
  fix_velocity: {
    total_fixed: 25,
    total_found: 25,
    fix_rate: 100,
    avg_fix_time_hours: 2,
    critical_fixed: 3,
    high_fixed: 6,
  },
}

export async function GET() {
  return NextResponse.json(trends)
}
