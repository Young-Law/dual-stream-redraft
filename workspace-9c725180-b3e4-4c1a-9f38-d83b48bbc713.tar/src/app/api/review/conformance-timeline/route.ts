import { NextResponse } from 'next/server'

const milestones = [
  { phase: 'v2.8', label: 'Compact Evidence', status: 'done' as const, spec_section: '§4', description: 'V3.x wire format, chunked encoding, byte ceilings' },
  { phase: 'v2.9', label: 'Adaptive K & Local Retention', status: 'done' as const, spec_section: '§4-§5', description: 'Rank-triggered widening, verifier budgets, retention floor' },
  { phase: 'v2.10-1', label: 'V3.3 Wire Format', status: 'done' as const, spec_section: '§4', description: 'Header fields use profile values (P2), manifest chaining (P1/P7), decode validation' },
  { phase: 'v2.10-2', label: 'Portable Verifier Governance', status: 'partial' as const, spec_section: '§5', description: 'Real timing metrics (P3/P4), receipt chain (P5/P6/P7). Missing: streaming-space envelopes, environment-normalized runtime.' },
  { phase: 'v2.10-3', label: 'Hybrid Adaptive Evidence', status: 'partial' as const, spec_section: '§6', description: 'Rank + keyed stochastic triggers work (C3). Probe selection fixed (H1/L5). Missing: historical-tension, evaluation-canary triggers.' },
  { phase: 'v2.10-4', label: 'End-to-End Retention', status: 'partial' as const, spec_section: '§7', description: 'Full lifecycle (P5/P6), storage validation (P9), possession challenges (P10), migration (P11). Missing: streaming-space envelopes.' },
  { phase: 'v2.10-5', label: 'Full CI Conformance', status: 'partial' as const, spec_section: '§10', description: '34 new tests added. Missing: environment-chaos tests, canary isolation, statistical selection validation.' },
]

export async function GET() {
  return NextResponse.json(milestones)
}
