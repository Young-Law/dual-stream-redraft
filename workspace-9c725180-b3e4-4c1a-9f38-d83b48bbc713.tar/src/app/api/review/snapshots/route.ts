import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  const snapshots = await db.reviewSnapshot.findMany({
    orderBy: { createdAt: 'desc' },
    take: 20,
  })
  return NextResponse.json(snapshots)
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { sessionLabel, totalFindings, critical, high, medium, low, conformancePct, missingFeatures, riskScore, resolvedCount, acknowledgedCount } = body
    const snapshot = await db.reviewSnapshot.create({
      data: {
        sessionLabel: sessionLabel ?? 'Manual',
        totalFindings: totalFindings ?? 0,
        critical: critical ?? 0,
        high: high ?? 0,
        medium: medium ?? 0,
        low: low ?? 0,
        conformancePct: conformancePct ?? 0,
        missingFeatures: missingFeatures ?? 0,
        riskScore: riskScore ?? 0,
        resolvedCount: resolvedCount ?? 0,
        acknowledgedCount: acknowledgedCount ?? 0,
      },
    })
    return NextResponse.json(snapshot)
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
