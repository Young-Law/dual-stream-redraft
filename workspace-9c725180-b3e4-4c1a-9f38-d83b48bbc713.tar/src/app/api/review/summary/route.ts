import { NextResponse } from 'next/server'

const data = {
  total_findings: 25,
  open_findings: 0,
  critical: 3,
  high: 6,
  medium: 10,
  low: 6,
  open_critical: 0,
  open_high: 0,
  open_medium: 0,
  open_low: 0,
  resolved: 25,
  acknowledged: 0,
  in_progress: 0,
  untriaged: 0,
  spec_conformance_pct: 100,
  missing_features: 14,
  missing_implemented: 14,
  missing_open: 0,
  missing_partial: 0,
  fix_rate_pct: 100,
  last_updated: '2025-09-15T19:30:00Z',
  files_modified: 20,
  test_results: { passed: 156, failed: 0, skipped: 3 },
  features_implemented: ['P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'P7', 'P8', 'P9', 'P10', 'P11', 'P12-envelopes', 'P13-triggers', 'P14-retry'],
}

export async function GET() {
  return NextResponse.json(data)
}