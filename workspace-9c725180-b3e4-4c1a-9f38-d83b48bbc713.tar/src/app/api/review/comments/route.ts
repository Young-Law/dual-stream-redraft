import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const bugId = searchParams.get('bugId')
  if (bugId) {
    const comments = await db.reviewComment.findMany({
      where: { bugId },
      orderBy: { createdAt: 'asc' },
    })
    return NextResponse.json(comments)
  }
  const all = await db.reviewComment.findMany({ orderBy: { createdAt: 'desc' }, take: 100 })
  return NextResponse.json(all)
}

export async function POST(request: NextRequest) {
  try {
    const { bugId, content } = await request.json()
    if (!bugId || !content) {
      return NextResponse.json({ error: 'bugId and content required' }, { status: 400 })
    }
    const comment = await db.reviewComment.create({
      data: { bugId, content },
    })
    return NextResponse.json(comment)
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
