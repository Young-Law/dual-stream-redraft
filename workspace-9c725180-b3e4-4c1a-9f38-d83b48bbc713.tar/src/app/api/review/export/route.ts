import { NextRequest, NextResponse } from 'next/server'

interface Bug {
  id: string; severity: string; category: string; title: string; file: string; line?: string; description: string; fix: string
}

const bugs: Bug[] = [
  { id: 'C-01', severity: 'critical', category: 'source', title: '`verify_keyed_replay()` crashes with `tension_maps` kwarg', file: 'verifier.py, compact_evidence.py', line: '~173, ~1400', description: 'The verifier passes `tension_maps=tension_maps` to `verify_keyed_replay()` which does not accept that parameter.', fix: 'Add tension_maps parameter to verify_keyed_replay() signature.' },
  { id: 'C-02', severity: 'critical', category: 'source', title: '`frames[-1]` IndexError on empty generation', file: 'generator.py', line: '428-430', description: 'Python evaluates RHS first then LHS. When zero tokens are generated, frames is empty and `frames[-1]` raises IndexError.', fix: 'Guard the entire expression with a length check before accessing frames[-1].' },
  { id: 'C-03', severity: 'critical', category: 'source', title: '`frames[0]` IndexError in coherence audit', file: 'audit.py', line: '48', description: 'Same pattern as C-02. The coherence audit accesses frames[0] without checking if the frame list is empty.', fix: 'Use a ternary or separate guard to handle empty frame lists.' },
  { id: 'H-01', severity: 'high', category: 'source', title: 'V3.3 header hardcodes verifier_work_profile_id=1', file: 'compact_evidence.py', description: 'V3.3 header construction hardcodes profile IDs to 1 instead of using actual profile values.', fix: 'Use actual profile values from configuration.' },
  { id: 'H-02', severity: 'high', category: 'source', title: 'V3.3 manifest struct lacks work_certificate_hash', file: 'compact_evidence.py', description: 'Missing work_certificate_hash field that v2.10 spec (§4.5) requires for provenance verification.', fix: 'Add work_certificate_hash field to the manifest struct.' },
  { id: 'H-03', severity: 'high', category: 'source', title: 'Tension map signature uses fragile payload string', file: 'tension_map.py', line: '~68', description: 'HMAC signature computed over hand-crafted string concatenation rather than deterministic serialization.', fix: 'Use deterministic serialization (e.g., canonical JSON or struct pack).' },
  { id: 'H-04', severity: 'high', category: 'source', title: '64-bit sequence_id silently truncated to 32-bit', file: 'compact_evidence.py', description: 'sequence_id field defined as 64-bit in spec but header struct packs it as 32-bit.', fix: 'Accept only 32-bit values or document the truncation behavior.' },
  { id: 'H-05', severity: 'high', category: 'source', title: 'API root handler crashes when web/ absent', file: 'api.py', description: 'Root API handler attempts to serve files from dualstream/web/ without checking if directory exists.', fix: 'Add existence check with graceful error response.' },
  { id: 'M-01', severity: 'medium', category: 'source', title: '5 AST codes (523, 525-528) defined but never raised', file: 'vocab.py', description: 'Five AST codes required by v2.10 spec are defined but never actually raised anywhere.', fix: 'Implement the code paths that should raise these AST codes.' },
  { id: 'M-02', severity: 'medium', category: 'source', title: 'Verifier work certificate contains fabricated metrics', file: 'verifier.py', description: 'Work certificate contains fabricated metrics: varint bytes = len//4, allocations = count*2.', fix: 'Record actual timing and allocation metrics during verification.' },
  { id: 'M-03', severity: 'medium', category: 'source', title: 'No maximum artifact size validation during decode', file: 'compact_evidence.py', description: 'No upper bound on artifact size during binary decode. Risk of memory exhaustion.', fix: 'Add maximum artifact size validation during decode.' },
  { id: 'M-04', severity: 'medium', category: 'source', title: 'Magic bytes DSAEV29 inconsistent with V3.3 label', file: 'compact_evidence.py', description: 'Magic bytes reference version 29 but code labels itself V3.3.', fix: 'Align magic bytes with V3.3 version label or document the discrepancy.' },
  { id: 'M-05', severity: 'medium', category: 'source', title: 'Chunk CRC32 uses default polynomial', file: 'compact_evidence.py', description: 'CRC32 uses default polynomial rather than spec-recommended polynomial.', fix: 'Use the spec-recommended CRC32 polynomial.' },
  { id: 'L-01', severity: 'low', category: 'source', title: '170-char semicolon-stuffed lines', file: 'generator.py', description: 'Multiple lines exceed 170 characters with semicolon-stuffed statements.', fix: 'Break long lines into multiple statements.' },
  { id: 'L-02', severity: 'low', category: 'source', title: 'Inline __import__ usage', file: 'cli.py', description: 'Uses inline __import__() instead of a top-level import.', fix: 'Move to top-level import.' },
  { id: 'L-03', severity: 'low', category: 'source', title: 'Wildcard imports', file: 'v210.py', description: 'Uses wildcard (star) imports polluting namespace.', fix: 'Replace with explicit named imports.' },
  { id: 'L-04', severity: 'low', category: 'source', title: 'Unused aliases', file: 'Multiple files', description: 'Several import aliases defined but never used.', fix: 'Remove unused import aliases.' },
  { id: 'T-C01', severity: 'critical', category: 'test', title: 'Tension-map test never tests tampering unsigned fields', file: 'test_tension_map.py', line: '86-149', description: 'Attacker can change unsigned fields (widening_action, expiry) without invalidating signature.', fix: 'Add test cases for unsigned field tampering.' },
  { id: 'T-C02', severity: 'critical', category: 'test', title: 'No test for keyed selection rate statistical accuracy', file: 'N/A', description: 'No statistical test verifying actual selection rate matches configured ppm.', fix: 'Add chi-squared test verifying selection rate within tolerance.' },
  { id: 'T-C03', severity: 'critical', category: 'test', title: 'No test for INCONCLUSIVE_INFRA retry logic', file: 'N/A', description: 'INCONCLUSIVE_INFRA outcome exists but no tests verify retry behavior.', fix: 'Add integration tests for retry triggers and metadata propagation.' },
  { id: 'T-H01', severity: 'high', category: 'test', title: 'Shared singleton test pollution', file: 'test_api_browser_ui.py', line: '50-53', description: 'Tests inject jobs into shared module-level singleton without cleanup.', fix: 'Use fixtures or setUp/tearDown to clean between tests.' },
  { id: 'T-H02', severity: 'high', category: 'test', title: 'Hardcoded header_size = 197', file: 'test_v210_conformance.py', line: '152, 168', description: 'Tests hardcode header size instead of referencing struct definition.', fix: 'Use _HEADER_V33.size from the module under test.' },
  { id: 'T-H03', severity: 'high', category: 'test', title: "Weak 'in' assertions accept wrong outcomes", file: 'test_v26_pipeline.py, test_fallback.py', line: '35, 23', description: 'Tests use substring matching that can produce false positives.', fix: 'Use exact equality or structured assertion.' },
]

function escapeCsv(val: string) {
  return `"${val.replace(/"/g, '""')}"`
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const format = searchParams.get('format') || 'json'

  const report = {
    generated_at: new Date().toISOString(),
    repo: 'dual-stream-redraft-main',
    spec_version: 'v2.10',
    summary: { total_findings: 78, critical: 6, high: 8, medium: 5, low: 4, spec_conformance_pct: 42, missing_features: 12 },
    bugs,
  }

  if (format === 'csv') {
    const header = 'ID,Severity,Category,Title,File,Line,Description,Fix'
    const rows = bugs.map(b =>
      [b.id, b.severity, b.category, b.title, b.file, b.line || '', b.description, b.fix].map(escapeCsv).join(',')
    ).join('\n')
    return new NextResponse(header + '\n' + rows, {
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': 'attachment; filename=dsa-v210-review-report.csv',
      },
    })
  }

  return NextResponse.json(report)
}
