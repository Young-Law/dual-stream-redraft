'use client'

import { useEffect, useState } from 'react'
import dynamic from 'next/dynamic'
import { useTheme } from 'next-themes'
import {
  LayoutGrid, FileText, AlertOctagon, AlertTriangle, FileWarning,
  XCircle, TestTube2, CheckCircle, Grid3x3, TrendingUp, History,
} from 'lucide-react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { TooltipProvider } from '@/components/ui/tooltip'
import { Input } from '@/components/ui/input'
import { Search } from 'lucide-react'

import { DashboardProvider, useDashboardData } from '@/components/dashboard/data-context'
import { LoadingState } from '@/components/dashboard/loading-state'
import { SummaryCards } from '@/components/dashboard/summary-cards'
import { DashboardHeader } from '@/components/dashboard/header'
import { HealthPanel } from '@/components/dashboard/health-panel'
import { ErrorBanner } from '@/components/dashboard/error-banner'

// Dynamic imports for tab components — reduces Turbopack memory pressure dramatically
const ExecutiveTab = dynamic(() => import('@/components/dashboard/executive-tab').then(m => ({ default: m.ExecutiveTab })), { loading: () => <TabSkeleton /> })
const OverviewTab = dynamic(() => import('@/components/dashboard/overview-tab').then(m => ({ default: m.OverviewTab })), { loading: () => <TabSkeleton /> })
const CriticalBugsTab = dynamic(() => import('@/components/dashboard/critical-bugs-tab').then(m => ({ default: m.CriticalBugsTab })), { loading: () => <TabSkeleton /> })
const AllBugsTab = dynamic(() => import('@/components/dashboard/all-bugs-tab').then(m => ({ default: m.AllBugsTab })), { loading: () => <TabSkeleton /> })
const SpecViolationsTab = dynamic(() => import('@/components/dashboard/spec-violations-tab').then(m => ({ default: m.SpecViolationsTab })), { loading: () => <TabSkeleton /> })
const MissingFeaturesTab = dynamic(() => import('@/components/dashboard/missing-features-tab').then(m => ({ default: m.MissingFeaturesTab })), { loading: () => <TabSkeleton /> })
const TestGapsTab = dynamic(() => import('@/components/dashboard/test-gaps-tab').then(m => ({ default: m.TestGapsTab })), { loading: () => <TabSkeleton /> })
const ArchitectureTab = dynamic(() => import('@/components/dashboard/architecture-tab').then(m => ({ default: m.ArchitectureTab })), { loading: () => <TabSkeleton /> })
const RiskMatrixTab = dynamic(() => import('@/components/dashboard/risk-matrix-tab').then(m => ({ default: m.RiskMatrixTab })), { loading: () => <TabSkeleton /> })
const TrendsTab = dynamic(() => import('@/components/dashboard/trends-tab').then(m => ({ default: m.TrendsTab })), { loading: () => <TabSkeleton /> })
const ActivityTab = dynamic(() => import('@/components/dashboard/activity-tab').then(m => ({ default: m.ActivityTab })), { loading: () => <TabSkeleton /> })

// Dynamic imports for deferred UI — modals, drawers, non-essential panels
const DashboardFooter = dynamic(() => import('@/components/dashboard/footer').then(m => ({ default: m.DashboardFooter })))
const BatchTriageBar = dynamic(() => import('@/components/dashboard/batch-triage-bar').then(m => ({ default: m.BatchTriageBar })))
const MobileNav = dynamic(() => import('@/components/dashboard/mobile-nav').then(m => ({ default: m.MobileNav })))
const QuickFilters = dynamic(() => import('@/components/dashboard/quick-filters').then(m => ({ default: m.QuickFilters })))
const BugDetailDrawer = dynamic(() => import('@/components/dashboard/bug-detail-drawer').then(m => ({ default: m.BugDetailDrawer })))
const FileDrilldownModal = dynamic(() => import('@/components/dashboard/file-drilldown-modal').then(m => ({ default: m.FileDrilldownModal })))
const KeyboardShortcutsModal = dynamic(() => import('@/components/dashboard/keyboard-shortcuts-modal').then(m => ({ default: m.KeyboardShortcutsModal })))
const SettingsModal = dynamic(() => import('@/components/dashboard/settings-modal').then(m => ({ default: m.SettingsModal })))
const SnapshotDialog = dynamic(() => import('@/components/dashboard/snapshot-dialog').then(m => ({ default: m.SnapshotDialog })))

// Lightweight skeleton shown while tab chunks load
function TabSkeleton() {
  return (
    <div className="space-y-4 animate-pulse">
      <div className="h-8 w-64 bg-gray-200/60 dark:bg-zinc-800/60 rounded-xl" />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="h-32 bg-gray-200/40 dark:bg-zinc-800/40 rounded-2xl" />
        ))}
      </div>
    </div>
  )
}

function DashboardContent() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const {
    loading, summary, activeTab, setActiveTab, showShortcuts, setShowShortcuts,
    isMobile, search, setSearch, bugs, specViolations, missingFeatures, testGaps,
    criticalBugs, error,
  } = useDashboardData()

  useEffect(() => { setMounted(true) }, [])

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return
      const tabKeys: Record<string, string> = {
        '1': 'overview', '2': 'executive', '3': 'critical-bugs', '4': 'all-bugs',
        '5': 'spec-violations', '6': 'missing-features', '7': 'test-gaps',
        '8': 'architecture', '9': 'risk-matrix', '0': 'trends',
      }
      if (e.key === '?' || (e.shiftKey && e.key === '/')) { e.preventDefault(); setShowShortcuts(p => !p) }
      if (e.key === 'd' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); setTheme(theme === 'dark' ? 'light' : 'dark') }
      if (e.key === '/' && !e.shiftKey) { e.preventDefault(); document.getElementById('global-search')?.focus() }
      if (tabKeys[e.key]) { e.preventDefault(); setActiveTab(tabKeys[e.key]) }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [theme, setTheme, setShowShortcuts, setActiveTab])

  if (!mounted || loading) return <LoadingState />
  if (!summary) return null

  const tabDefs = [
    { v: 'overview', icon: LayoutGrid, label: 'Overview', count: null },
    { v: 'executive', icon: FileText, label: 'Executive', count: null },
    { v: 'critical-bugs', icon: AlertOctagon, label: 'Critical', count: criticalBugs.length },
    { v: 'all-bugs', icon: AlertTriangle, label: 'All Bugs', count: bugs.length },
    { v: 'spec-violations', icon: FileWarning, label: 'Spec', count: specViolations.length },
    { v: 'missing-features', icon: XCircle, label: 'Missing', count: missingFeatures.length },
    { v: 'test-gaps', icon: TestTube2, label: 'Tests', count: testGaps.length },
    { v: 'architecture', icon: CheckCircle, label: 'Architecture', count: null },
    { v: 'risk-matrix', icon: Grid3x3, label: 'Risk Matrix', count: null },
    { v: 'trends', icon: TrendingUp, label: 'Trends', count: null },
    { v: 'activity', icon: History, label: 'Activity', count: null },
  ]

  return (
    <div className="min-h-screen flex flex-col bg-mesh transition-colors duration-500">
      {/* Floating background orbs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0" aria-hidden="true">
        <div className="orb orb-1" />
        <div className="orb orb-2" />
        <div className="orb orb-3" />
        <div className="orb orb-4" />
      </div>

      <DashboardHeader />

      <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 space-y-4 relative z-10 pb-24 md:pb-6">
        <ErrorBanner />
        <SummaryCards />

        {/* Health Panel & Search row */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {!isMobile && (
            <div className="relative flex-1 max-w-3xl">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 size-3.5 text-gray-400" />
              <Input
                id="global-search"
                placeholder="Search bugs, violations, features... (press /)"
                className="pl-10 h-11 text-sm rounded-2xl bg-white/50 dark:bg-zinc-900/50 border-gray-200/60 dark:border-zinc-700/40 glass-card hover:border-gray-300/80 dark:hover:border-zinc-600/60 focus-visible:ring-orange-500/30 transition-all duration-200"
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
          )}
          <div className="shrink-0">
            <HealthPanel />
          </div>
        </div>

        {/* Quick Filters (collapsible) */}
        <QuickFilters />

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full h-auto flex-wrap gap-1 bg-white/50 dark:bg-zinc-900/30 rounded-2xl p-1.5 border border-gray-200/50 dark:border-zinc-700/30">
            {tabDefs.map(t => (
              <TabsTrigger
                key={t.v}
                value={t.v}
                className="gap-1.5 text-xs rounded-xl data-[state=active]:bg-gray-900 dark:data-[state=active]:bg-zinc-100 data-[state=active]:text-white dark:data-[state=active]:text-zinc-900 data-[state=active]:shadow-md transition-all duration-200 active:scale-95 hover:bg-gray-100 dark:hover:bg-zinc-800/60"
              >
                <t.icon className="size-3.5" />
                <span className="hidden sm:inline">{t.label}</span>
                {t.count !== null && (
                  <Badge variant="secondary" className="text-[9px] h-4 min-w-4 px-1 font-bold ml-1 tabular-nums">
                    {t.count}
                  </Badge>
                )}
              </TabsTrigger>
            ))}
          </TabsList>

          <div className="mt-6">
            <TabsContent value="overview"><OverviewTab /></TabsContent>
            <TabsContent value="executive"><ExecutiveTab /></TabsContent>
            <TabsContent value="critical-bugs"><CriticalBugsTab /></TabsContent>
            <TabsContent value="all-bugs"><AllBugsTab /></TabsContent>
            <TabsContent value="spec-violations"><SpecViolationsTab /></TabsContent>
            <TabsContent value="missing-features"><MissingFeaturesTab /></TabsContent>
            <TabsContent value="test-gaps"><TestGapsTab /></TabsContent>
            <TabsContent value="architecture"><ArchitectureTab /></TabsContent>
            <TabsContent value="risk-matrix"><RiskMatrixTab /></TabsContent>
            <TabsContent value="trends"><TrendsTab /></TabsContent>
            <TabsContent value="activity"><ActivityTab /></TabsContent>
          </div>
        </Tabs>
      </main>

      <BatchTriageBar />
      <MobileNav />
      <DashboardFooter />

      {/* Modals & Drawers */}
      <BugDetailDrawer />
      <FileDrilldownModal />
      <KeyboardShortcutsModal open={showShortcuts} onOpenChange={setShowShortcuts} />
      <SettingsModal />
      <SnapshotDialog />
    </div>
  )
}

export default function Home() {
  return (
    <DashboardProvider>
      <TooltipProvider>
        <DashboardContent />
      </TooltipProvider>
    </DashboardProvider>
  )
}
