'use client'

import { useState, useEffect } from 'react'
import { FileCode2, ChevronDown, ChevronUp, Send, Loader2, User } from 'lucide-react'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { Textarea } from '@/components/ui/textarea'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useDashboardData } from './data-context'
import { SEV_BG, TRIAGE_CONFIG } from './types'
import type { Bug, TriageStatus, BugComment } from './types'
import { timeAgo } from './hooks'

interface BugDetailDrawerProps {
  bug?: Bug | null
  open?: boolean
  onOpenChange?: (open: boolean) => void
}

export function BugDetailDrawer(props?: BugDetailDrawerProps) {
  const {
    selectedBug: ctxBug, drawerOpen: ctxOpen, setDrawerOpen: ctxSetDrawerOpen,
    triageState, setBugTriage,
  } = useDashboardData()

  const bug = props?.bug ?? ctxBug
  const open = props?.open ?? ctxOpen
  const onOpenChange = props?.onOpenChange ?? ctxSetDrawerOpen

  const [expanded, setExpanded] = useState(true)
  const [comments, setComments] = useState<BugComment[]>([])
  const [newComment, setNewComment] = useState('')
  const [commentLoading, setCommentLoading] = useState(false)
  const [sendingComment, setSendingComment] = useState(false)

  useEffect(() => {
    if (bug && open) {
      setExpanded(true)
      setNewComment('')
      setCommentLoading(true)
      fetch(`/api/review/comments?bugId=${bug.id}`)
        .then(r => r.json())
        .then(data => setComments(Array.isArray(data) ? data : []))
        .catch(() => setComments([]))
        .finally(() => setCommentLoading(false))
    }
  }, [bug, open])

  const handleSendComment = async () => {
    if (!bug || !newComment.trim()) return
    setSendingComment(true)
    try {
      const resp = await fetch('/api/review/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bugId: bug.id, content: newComment.trim() }),
      })
      if (resp.ok) {
        const comment = await resp.json()
        setComments(prev => [...prev, comment])
        setNewComment('')
      }
    } finally {
      setSendingComment(false)
    }
  }

  if (!bug) return null

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="sm:max-w-lg overflow-y-auto">
        <SheetHeader className="space-y-3">
          <div className="flex items-center gap-2">
            <Badge className={`text-xs ${SEV_BG[bug.severity]} border`} variant="outline">{bug.severity}</Badge>
            <Badge variant="outline" className="text-xs font-mono">{bug.id}</Badge>
            <Badge variant="outline" className="text-xs capitalize">{bug.category}</Badge>
          </div>
          <SheetTitle className="text-base leading-snug">{bug.title}</SheetTitle>
          <SheetDescription className="font-mono text-xs">{bug.file}{bug.line ? `:${bug.line}` : ''}</SheetDescription>
        </SheetHeader>

        <div className="mt-6 space-y-5">
          <div className="space-y-2">
            <h3 className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest">Description</h3>
            <p className="text-sm text-gray-700 dark:text-zinc-300 leading-relaxed">{bug.description}</p>
          </div>

          <Separator />

          <div className="space-y-2">
            <button className="flex items-center gap-2 text-sm font-semibold text-gray-900 dark:text-zinc-100 w-full" onClick={() => setExpanded(!expanded)}>
              <h3 className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest">Recommended Fix</h3>
              {expanded ? <ChevronUp className="size-3.5" /> : <ChevronDown className="size-3.5" />}
            </button>
            {expanded && (
              <div className="text-sm text-emerald-700 dark:text-emerald-400 leading-relaxed bg-emerald-50/50 dark:bg-emerald-500/5 rounded-xl p-3 border border-emerald-200/50 dark:border-emerald-500/10">
                {bug.fix}
              </div>
            )}
          </div>

          <Separator />

          <div className="space-y-1.5">
            <h3 className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest">Related Files</h3>
            <div className="flex flex-wrap gap-2">
              {bug.file.split(', ').map(f => (
                <Badge key={f} variant="outline" className="text-xs font-mono bg-gray-50 dark:bg-zinc-800/60">
                  <FileCode2 className="size-3 mr-1" />{f}{bug.line ? `:${bug.line}` : ''}
                </Badge>
              ))}
            </div>
          </div>

          <Separator />

          <div className="space-y-2">
            <h3 className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest">Triage Status</h3>
            <div className="grid grid-cols-2 gap-2">
              {(Object.entries(TRIAGE_CONFIG) as [TriageStatus, typeof TRIAGE_CONFIG.none][]).map(([key, cfg]) => {
                const active = (triageState[bug.id] || 'none') === key
                return (
                  <Button
                    key={key}
                    variant={active ? 'default' : 'outline'}
                    size="sm"
                    className={`h-9 text-xs rounded-xl transition-all active:scale-95 justify-start gap-2 ${active ? cfg.bg + ' ' + cfg.color + ' ' + cfg.border + ' border' : ''}`}
                    onClick={() => setBugTriage(bug.id, key)}
                  >
                    <cfg.icon className="size-3.5" />{cfg.label}
                  </Button>
                )
              })}
            </div>
          </div>

          <Separator />

          <div className="space-y-3">
            <h3 className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest">
              Comments ({comments.length})
            </h3>
            {commentLoading ? (
              <div className="flex items-center gap-2 py-3">
                <Loader2 className="size-3.5 animate-spin text-gray-400" />
                <span className="text-xs text-gray-400">Loading comments...</span>
              </div>
            ) : comments.length === 0 ? (
              <p className="text-xs text-gray-400 dark:text-zinc-500 py-2">No comments yet. Be the first to comment.</p>
            ) : (
              <ScrollArea className="max-h-48">
                <div className="space-y-3 pr-2">
                  {comments.map(c => (
                    <div key={c.id} className="bg-gray-50 dark:bg-zinc-800/40 rounded-xl p-3 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <div className="size-5 rounded-full bg-gray-200 dark:bg-zinc-700 flex items-center justify-center">
                            <User className="size-2.5 text-gray-500 dark:text-zinc-400" />
                          </div>
                          <span className="text-[10px] font-semibold text-gray-500 dark:text-zinc-400">Reviewer</span>
                        </div>
                        <span className="text-[10px] text-gray-400 dark:text-zinc-500">{c.createdAt ? timeAgo(c.createdAt) : 'just now'}</span>
                      </div>
                      <p className="text-sm text-gray-700 dark:text-zinc-300 leading-relaxed pl-6.5">{c.content}</p>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
            <div className="flex gap-2">
              <Textarea
                placeholder="Add a comment..."
                value={newComment}
                onChange={e => setNewComment(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendComment() }
                }}
                className="min-h-[60px] text-sm rounded-xl resize-none"
              />
              <Button
                size="icon"
                className="shrink-0 rounded-xl"
                disabled={!newComment.trim() || sendingComment}
                onClick={handleSendComment}
              >
                {sendingComment ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
              </Button>
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}
