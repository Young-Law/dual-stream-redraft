'use client'

import React, { createContext, useContext, useState, useCallback, useEffect, useMemo, useRef } from 'react'
import type {
  Summary, Bug, SpecViolation, MissingFeature, TestGap,
  FileHeatmapEntry, TimelineMilestone, TrendsData,
  ActivityItem, ExecutiveData, TriageStatus, DashboardSettings,
} from './types'
import { SEV_ORDER } from './types'
import { useLocalStorage, useAnimatedCounter, riskScore, riskLabel } from './hooks'

interface DataContextType {
  // Data
  summary: Summary | null
  bugs: Bug[]
  specViolations: SpecViolation[]
  missingFeatures: MissingFeature[]
  testGaps: TestGap[]
  heatmap: FileHeatmapEntry[]
  timeline: TimelineMilestone[]
  trends: TrendsData | null
  activity: ActivityItem[]
  executive: ExecutiveData | null
  loading: boolean
  error: string | null
  refetch: () => Promise<void>

  // Triage
  triageState: Record<string, TriageStatus>
  setBugTriage: (bugId: string, status: TriageStatus) => void
  triageStats: { none: number; acknowledged: number; 'in-progress': number; resolved: number }
  untriagedCriticalHigh: Bug[]

  // Selection & batch
  selectedBugs: Set<string>
  setSelectedBugs: React.Dispatch<React.SetStateAction<Set<string>>>
  toggleBugSelection: (bugId: string) => void
  batchLoading: boolean
  setBatchLoading: React.Dispatch<React.SetStateAction<boolean>>
  batchTriage: (status: TriageStatus) => Promise<void>

  // Filters
  severityFilter: string
  setSeverityFilter: React.Dispatch<React.SetStateAction<string>>
  triageFilter: TriageStatus | 'all'
  setTriageFilter: React.Dispatch<React.SetStateAction<TriageStatus | 'all'>>
  search: string
  setSearch: React.Dispatch<React.SetStateAction<string>>
  sortField: 'severity' | 'category' | 'id'
  setSortField: React.Dispatch<React.SetStateAction<'severity' | 'category' | 'id'>>
  sortAsc: boolean
  setSortAsc: React.Dispatch<React.SetStateAction<boolean>>
  handleSort: (f: 'severity' | 'category' | 'id') => void
  gapFilter: string
  setGapFilter: React.Dispatch<React.SetStateAction<string>>
  fileFilter: string
  setFileFilter: React.Dispatch<React.SetStateAction<string>>
  clearFileFilter: () => void
  handleHeatmapClick: (file: string) => void

  // Computed
  criticalBugs: Bug[]
  sourceBugs: Bug[]
  testBugs: Bug[]
  gapCategories: string[]
  filteredBugs: Bug[]
  filteredViolations: SpecViolation[]
  filteredFeatures: MissingFeature[]
  filteredGaps: TestGap[]
  conformancePct: number
  pieData: { name: string; value: number; fill: string }[]
  rs: number
  rl: ReturnType<typeof import('./hooks').riskLabel>

  // Animated counters
  animCritical: number
  animHigh: number
  animTotal: number
  animMissing: number
  animRisk: number

  // UI state
  activeTab: string
  setActiveTab: React.Dispatch<React.SetStateAction<string>>
  selectedBug: Bug | null
  setSelectedBug: React.Dispatch<React.SetStateAction<Bug | null>>
  drawerOpen: boolean
  setDrawerOpen: React.Dispatch<React.SetStateAction<boolean>>
  openBug: (b: Bug) => void
  expandedCritical: Set<string>
  toggleCritical: (id: string) => void
  copied: boolean
  setCopied: React.Dispatch<React.SetStateAction<boolean>>
  showShortcuts: boolean
  setShowShortcuts: React.Dispatch<React.SetStateAction<boolean>>
  notifOpen: boolean
  setNotifOpen: React.Dispatch<React.SetStateAction<boolean>>
  fabOpen: boolean
  setFabOpen: React.Dispatch<React.SetStateAction<boolean>>
  isMobile: boolean
  showSettings: boolean
  setShowSettings: React.Dispatch<React.SetStateAction<boolean>>
  showSnapshotDialog: boolean
  setShowSnapshotDialog: React.Dispatch<React.SetStateAction<boolean>>
  settings: DashboardSettings
  setSettings: (v: DashboardSettings | ((prev: DashboardSettings) => DashboardSettings)) => void
  autoRefreshTimer: React.MutableRefObject<ReturnType<typeof setInterval> | null>
}

const DataContext = createContext<DataContextType | null>(null)

export function useDashboardData() {
  const ctx = useContext(DataContext)
  if (!ctx) throw new Error('useDashboardData must be used within DashboardProvider')
  return ctx
}

/** @deprecated Use useDashboardData instead */
export const useData = useDashboardData

export function DashboardProvider({ children }: { children: React.ReactNode }) {
  const [summary, setSummary] = useState<Summary | null>(null)
  const [bugs, setBugs] = useState<Bug[]>([])
  const [specViolations, setSpecViolations] = useState<SpecViolation[]>([])
  const [missingFeatures, setMissingFeatures] = useState<MissingFeature[]>([])
  const [testGaps, setTestGaps] = useState<TestGap[]>([])
  const [heatmap, setHeatmap] = useState<FileHeatmapEntry[]>([])
  const [timeline, setTimeline] = useState<TimelineMilestone[]>([])
  const [trends, setTrends] = useState<TrendsData | null>(null)
  const [activity, setActivity] = useState<ActivityItem[]>([])
  const [executive, setExecutive] = useState<ExecutiveData | null>(null)
  const [selectedBugs, setSelectedBugs] = useState<Set<string>>(new Set())
  const [batchLoading, setBatchLoading] = useState(false)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useLocalStorage('dsa-active-tab', 'overview')
  const [severityFilter, setSeverityFilter] = useState('all')
  const [triageFilter, setTriageFilter] = useState<TriageStatus | 'all'>('all')
  const [search, setSearch] = useState('')
  const [sortField, setSortField] = useState<'severity' | 'category' | 'id'>('severity')
  const [sortAsc, setSortAsc] = useState(false)
  const [expandedCritical, setExpandedCritical] = useState<Set<string>>(new Set())
  const [selectedBug, setSelectedBug] = useState<Bug | null>(null)
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [copied, setCopied] = useState(false)
  const [showShortcuts, setShowShortcuts] = useState(false)
  const [gapFilter, setGapFilter] = useState('all')
  const [fileFilter, setFileFilter] = useState('')
  const [notifOpen, setNotifOpen] = useState(false)
  const [fabOpen, setFabOpen] = useState(false)
  const [isMobile, setIsMobile] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [showSnapshotDialog, setShowSnapshotDialog] = useState(false)
  const [settings, setSettings] = useLocalStorage<DashboardSettings>('dsa-dashboard-settings', {
    defaultTab: 'overview',
    compactView: false,
    autoRefresh: false,
    refreshInterval: 60,
  })
  const autoRefreshTimer = useRef<ReturnType<typeof setInterval> | null>(null)
  const [triageState, setTriageState] = useLocalStorage<Record<string, TriageStatus>>('dsa-bug-triage', {})

  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 768)
    check()
    window.addEventListener('resize', check)
    return () => window.removeEventListener('resize', check)
  }, [])

  const fetchData = useCallback(async () => {
    try {
      setError(null)
      const urls = [
        '/api/review/summary',
        '/api/review/bugs',
        '/api/review/spec-violations',
        '/api/review/missing-features',
        '/api/review/test-gaps',
        '/api/review/file-heatmap',
        '/api/review/conformance-timeline',
        '/api/review/trends',
        '/api/review/activity',
        '/api/review/executive',
      ]
      const resps = await Promise.all(urls.map(u => fetch(u)))
      const [s, b, sv, mf, tg, hm, tl, tr, act, ex] = await Promise.all(resps.map(r => r.json()))
      setSummary(s)
      setBugs(b)
      setSpecViolations(sv)
      setMissingFeatures(mf)
      setTestGaps(tg)
      setHeatmap(hm)
      setTimeline(tl)
      setTrends(tr)
      setActivity(act)
      setExecutive(ex)
      // Merge API-provided triage status into local state
      if (Array.isArray(b)) {
        const apiTriage: Record<string, string> = {}
        b.forEach((bug: { id: string; status?: string }) => {
          if (bug.status && bug.status !== 'none') {
            apiTriage[bug.id] = bug.status as TriageStatus
          }
        })
        if (Object.keys(apiTriage).length > 0) {
          setTriageState(prev => ({ ...prev, ...apiTriage }))
        }
      }
    } catch (err) {
      console.error('Failed to fetch', err)
      setError(err instanceof Error ? err.message : 'Failed to fetch dashboard data')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchData() }, [fetchData])

  // Auto-refresh
  useEffect(() => {
    if (autoRefreshTimer.current) clearInterval(autoRefreshTimer.current)
    if (!settings.autoRefresh) return
    const ms = settings.refreshInterval * 1000
    autoRefreshTimer.current = setInterval(fetchData, ms)
    return () => { if (autoRefreshTimer.current) clearInterval(autoRefreshTimer.current) }
  }, [settings.autoRefresh, settings.refreshInterval, fetchData])

  const setBugTriage = (bugId: string, status: TriageStatus) => {
    setTriageState(prev => ({ ...prev, [bugId]: status }))
    fetch('/api/review/triage', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ bugId, status }),
    }).catch(() => {})
  }

  const toggleBugSelection = (bugId: string) => {
    setSelectedBugs(prev => {
      const n = new Set(prev)
      if (n.has(bugId)) n.delete(bugId); else n.add(bugId)
      return n
    })
  }

  const batchTriage = async (status: TriageStatus) => {
    if (selectedBugs.size === 0) return
    setBatchLoading(true)
    try {
      const resp = await fetch('/api/review/triage/batch', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bugIds: Array.from(selectedBugs), status }),
      })
      if (resp.ok) {
        setTriageState(prev => {
          const next = { ...prev }
          selectedBugs.forEach(id => { next[id] = status })
          return next
        })
        setSelectedBugs(new Set())
      }
    } finally {
      setBatchLoading(false)
    }
  }

  const toggleCritical = (id: string) => {
    setExpandedCritical(p => { const n = new Set(p); if (n.has(id)) n.delete(id); else n.add(id); return n })
  }

  const handleSort = (f: typeof sortField) => {
    if (sortField === f) setSortAsc(!sortAsc)
    else { setSortField(f); setSortAsc(false) }
  }

  const openBug = (b: Bug) => { setSelectedBug(b); setDrawerOpen(true) }

  const handleHeatmapClick = (file: string) => { setFileFilter(file); setActiveTab('all-bugs') }
  const clearFileFilter = () => { setFileFilter('') }

  // Computed values
  const criticalBugs = useMemo(() => bugs.filter(b => b.severity === 'critical'), [bugs])
  const sourceBugs = useMemo(() => bugs.filter(b => b.category === 'source'), [bugs])
  const testBugs = useMemo(() => bugs.filter(b => b.category === 'test'), [bugs])
  const gapCategories = useMemo(() => [...new Set(testGaps.map(g => g.category))], [testGaps])

  const untriagedCriticalHigh = useMemo(
    () => bugs.filter(b => (b.severity === 'critical' || b.severity === 'high') && (!triageState[b.id] || triageState[b.id] === 'none')),
    [bugs, triageState]
  )

  const triageStats = useMemo(() => {
    const counts = { none: 0, acknowledged: 0, 'in-progress': 0, resolved: 0 }
    bugs.forEach(b => { counts[triageState[b.id] || 'none']++ })
    return counts
  }, [bugs, triageState])

  const filteredBugs = useMemo(() => {
    let list = bugs.filter(b => severityFilter === 'all' || b.severity === severityFilter)
    if (triageFilter !== 'all') list = list.filter(b => (triageState[b.id] || 'none') === triageFilter)
    if (fileFilter) {
      const ff = fileFilter.toLowerCase()
      list = list.filter(b => b.file.toLowerCase().includes(ff))
    }
    if (search) {
      const q = search.toLowerCase()
      list = list.filter(b =>
        b.id.toLowerCase().includes(q) || b.title.toLowerCase().includes(q) ||
        b.file.toLowerCase().includes(q) || b.description.toLowerCase().includes(q)
      )
    }
    return [...list].sort((a, b) => {
      if (sortField === 'severity') return sortAsc ? SEV_ORDER[a.severity] - SEV_ORDER[b.severity] : SEV_ORDER[b.severity] - SEV_ORDER[a.severity]
      if (sortField === 'category') return sortAsc ? a.category.localeCompare(b.category) : b.category.localeCompare(a.category)
      return sortAsc ? a.id.localeCompare(b.id) : b.id.localeCompare(a.id)
    })
  }, [bugs, severityFilter, triageFilter, fileFilter, search, sortField, sortAsc, triageState])

  const filteredViolations = useMemo(() => {
    if (!search) return specViolations
    const q = search.toLowerCase()
    return specViolations.filter(v =>
      v.violation.toLowerCase().includes(q) || v.section.toLowerCase().includes(q) || v.detail.toLowerCase().includes(q)
    )
  }, [specViolations, search])

  const filteredFeatures = useMemo(() => {
    if (!search) return missingFeatures
    const q = search.toLowerCase()
    return missingFeatures.filter(f => f.name.toLowerCase().includes(q) || f.description.toLowerCase().includes(q))
  }, [missingFeatures, search])

  const filteredGaps = useMemo(() => {
    let list = gapFilter === 'all' ? testGaps : testGaps.filter(g => g.category === gapFilter)
    if (search) {
      const q = search.toLowerCase()
      list = list.filter(g => g.description.toLowerCase().includes(q) || g.category.toLowerCase().includes(q))
    }
    return list
  }, [testGaps, gapFilter, search])

  const pieData = useMemo(() => summary ? [
    { name: 'Critical', value: summary.critical, fill: '#ef4444' },
    { name: 'High', value: summary.high, fill: '#f97316' },
    { name: 'Medium', value: summary.medium, fill: '#eab308' },
    { name: 'Low', value: summary.low, fill: '#6366f1' },
  ] : [], [summary])

  const conformancePct = timeline.length > 0
    ? Math.round((timeline.filter(m => m.status === 'done').length / timeline.length) * 100) : 0

  const rs = summary ? riskScore(summary) : 0
  const rl = riskLabel(rs)

  // Animated counters
  const animCritical = useAnimatedCounter(summary?.critical ?? 0)
  const animHigh = useAnimatedCounter(summary?.high ?? 0)
  const animTotal = useAnimatedCounter(summary?.total_findings ?? 0)
  const animMissing = useAnimatedCounter(summary?.missing_features ?? 0)
  const animRisk = useAnimatedCounter(rs)

  const value = useMemo<DataContextType>(() => ({
    summary, bugs, specViolations, missingFeatures, testGaps, heatmap, timeline, trends, activity, executive,
    loading, error, refetch: fetchData,
    triageState, setBugTriage, triageStats, untriagedCriticalHigh,
    selectedBugs, setSelectedBugs, toggleBugSelection, batchLoading, setBatchLoading, batchTriage,
    severityFilter, setSeverityFilter, triageFilter, setTriageFilter, search, setSearch,
    sortField, setSortField, sortAsc, setSortAsc, handleSort,
    gapFilter, setGapFilter, fileFilter, setFileFilter, clearFileFilter, handleHeatmapClick,
    criticalBugs, sourceBugs, testBugs, gapCategories, filteredBugs, filteredViolations, filteredFeatures, filteredGaps,
    conformancePct, pieData, rs, rl,
    animCritical, animHigh, animTotal, animMissing, animRisk,
    activeTab, setActiveTab, selectedBug, setSelectedBug, drawerOpen, setDrawerOpen, openBug,
    expandedCritical, toggleCritical, copied, setCopied, showShortcuts, setShowShortcuts,
    notifOpen, setNotifOpen, fabOpen, setFabOpen, isMobile,
    showSettings, setShowSettings, showSnapshotDialog, setShowSnapshotDialog, settings, setSettings,
    autoRefreshTimer,
  }), [
    summary, bugs, specViolations, missingFeatures, testGaps, heatmap, timeline, trends, activity, executive,
    loading, error, fetchData, triageState, triageStats, untriagedCriticalHigh,
    selectedBugs, toggleBugSelection, batchLoading, batchTriage,
    severityFilter, triageFilter, search, sortField, sortAsc, handleSort,
    gapFilter, fileFilter, handleHeatmapClick,
    criticalBugs, sourceBugs, testBugs, gapCategories, filteredBugs, filteredViolations, filteredFeatures, filteredGaps,
    conformancePct, pieData, rs, rl,
    animCritical, animHigh, animTotal, animMissing, animRisk,
    activeTab, selectedBug, drawerOpen, openBug,
    expandedCritical, toggleCritical, copied, showShortcuts,
    notifOpen, fabOpen, isMobile,
    showSettings, showSnapshotDialog, settings,
  ])

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>
}

/** @deprecated Use DashboardProvider instead */
export const DataProvider = DashboardProvider
