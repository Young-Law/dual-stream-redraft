'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Shield, TrendingUp, TrendingDown, ArrowUpRight, CheckCircle, AlertTriangle, XCircle, Camera, History, ChevronRight, ShieldCheck } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { useDashboardData } from './data-context'
import { ConformanceGauge } from './conformance-gauge'
import { fadeIn, stagger } from './types'
import { timeAgo } from './hooks'

interface Snapshot {
  id: number
  sessionLabel: string
  totalFindings: number
  critical: number
  high: number
  medium: number
  low: number
  conformancePct: number
  missingFeatures: number
  riskScore: number
  resolvedCount: number
  acknowledgedCount: number
  createdAt: string
}

export function ExecutiveTab() {
  const { executive, rs, rl, summary, setShowSnapshotDialog } = useDashboardData()
  const [snapshots, setSnapshots] = useState<Snapshot[]>([])
  const [showHistory, setShowHistory] = useState(false)

  useEffect(() => {
    fetch('/api/review/snapshots')
      .then(r => r.json())
      .then(data => setSnapshots(Array.isArray(data) ? data : []))
      .catch(() => {})
  }, [])

  if (!executive || !summary) return null

  const s = summary as Record<string, unknown>
  const resolved = (s?.resolved as number) ?? 0
  const isUp = executive.risk_trend === 'increasing'
  const isDown = executive.risk_trend === 'decreasing'

  const sevBadgeClass = (sev: string) => {
    if (sev === 'resolved') return 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20'
    if (sev === 'critical') return 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/20'
    return 'bg-orange-500/10 text-orange-600 dark:text-orange-400 border-orange-500/20'
  }

  const sevIconClass = (sev: string) => {
    if (sev === 'resolved') return 'bg-emerald-500/10'
    if (sev === 'critical') return 'bg-red-500/10'
    return 'bg-orange-500/10'
  }

  return (
    <AnimatePresence mode="wait">
      <motion.div key="executive" {...fadeIn} className="space-y-6">
        {/* Section 1: Risk Banner — updated for resolved state */}
        <Card className={`rounded-2xl border-2 overflow-hidden ${rl.border} ${rl.bg}`}>
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <ConformanceGauge value={executive.conformance} size={160} />
              <div className="flex-1 space-y-3 text-center md:text-left">
                <div className="flex items-center justify-center md:justify-start gap-3 flex-wrap">
                  <Badge className={`${rl.color} ${rl.bg} border ${rl.border} text-sm px-3 py-1`} variant="outline">
                    {isUp ? <TrendingUp className="size-3.5 mr-1.5" /> : isDown ? <TrendingDown className="size-3.5 mr-1.5" /> : <ShieldCheck className="size-3.5 mr-1.5" />}
                    {executive.overall_risk} Risk
                  </Badge>
                  {isUp && <span className="text-[10px] text-red-500 font-medium animate-subtle-pulse">▲ Increasing</span>}
                  {isDown && <span className="text-[10px] text-emerald-500 font-medium">▼ Decreasing</span>}
                  {executive.fix_rate === 100 && <span className="text-[10px] text-emerald-500 font-medium">✓ 100% Fix Rate</span>}
                </div>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-gray-900 dark:text-zinc-100">
                  Risk Score: <span className={rl.color}>{rs}</span>
                </h2>
                <p className="text-sm text-gray-500 dark:text-zinc-400">
                  {summary.total_findings} total findings — {resolved} resolved, 0 open
                </p>
                <div className="flex items-center gap-4 justify-center md:justify-start text-xs">
                  <span className="flex items-center gap-1 text-gray-500">
                    <ArrowUpRight className="size-3 text-orange-500" />
                    {executive.conformance}% / {executive.conformance_target}% target
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Section 2: Key Findings */}
        <Card className="glass-card rounded-2xl">
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <Shield className="size-4 text-emerald-500" />
              Key Findings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {executive.key_findings.map((f, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.08 }}
                className="flex gap-3 items-start p-3 rounded-xl bg-gray-50/80 dark:bg-zinc-800/30 hover:bg-gray-100/80 dark:hover:bg-zinc-800/50 transition-colors cursor-default"
              >
                <div className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${sevIconClass(f.severity)} ${sevBadgeClass(f.severity).split(' ').slice(1).join(' ')}`}>
                  {f.severity === 'resolved' ? '✓' : i + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h4 className="text-sm font-semibold text-gray-900 dark:text-zinc-100">{f.title}</h4>
                    <Badge
                      className={`text-[10px] border ${sevBadgeClass(f.severity)}`}
                      variant="outline"
                    >
                      {f.severity}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-500 dark:text-zinc-400 mt-1 leading-relaxed">{f.detail}</p>
                </div>
              </motion.div>
            ))}
          </CardContent>
        </Card>

        {/* Section 3: v2.10 Pillar Status */}
        <Card className="glass-card rounded-2xl">
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <CheckCircle className="size-4 text-emerald-500" />
              v2.10 Pillar Status
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {executive.v210_pillars.map((pillar, i) => {
              const StatusIcon = pillar.status === 'on-track' || pillar.status === 'partial' ? CheckCircle : pillar.status === 'at-risk' ? AlertTriangle : XCircle
              const statusColor = pillar.status === 'on-track' ? 'text-emerald-500' : pillar.status === 'partial' ? 'text-amber-500' : pillar.status === 'at-risk' ? 'text-amber-500' : 'text-red-500'
              const barColor = pillar.status === 'on-track' ? 'bg-gradient-to-r from-emerald-400 to-emerald-500' : pillar.status === 'partial' ? 'bg-gradient-to-r from-amber-400 to-orange-500' : pillar.status === 'at-risk' ? 'bg-gradient-to-r from-amber-400 to-orange-500' : 'bg-gradient-to-r from-red-400 to-red-500'
              const statusLabel = pillar.status.replace('-', ' ')
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="rounded-xl border border-gray-200/50 dark:border-zinc-700/30 p-4 space-y-2.5 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-semibold text-gray-900 dark:text-zinc-100">{pillar.name}</h4>
                    <div className="flex items-center gap-1">
                      <StatusIcon className={`size-3.5 ${statusColor}`} />
                      <span className={`text-[10px] font-medium ${statusColor}`}>{statusLabel}</span>
                    </div>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-gray-200 dark:bg-zinc-700 overflow-hidden">
                    <motion.div
                      className={`h-full rounded-full ${barColor}`}
                      initial={{ width: 0 }}
                      animate={{ width: `${pillar.pct}%` }}
                      transition={{ delay: 0.5 + i * 0.15, duration: 0.8, ease: 'easeOut' }}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <p className="text-[11px] text-gray-500 dark:text-zinc-400">{pillar.details}</p>
                    <span className="text-[11px] font-bold tabular-nums text-gray-700 dark:text-zinc-300">{pillar.pct}%</span>
                  </div>
                </motion.div>
              )
            })}
          </CardContent>
        </Card>

        {/* Section 4: Recommended Actions */}
        <Card className="glass-card rounded-2xl">
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <ChevronRight className="size-4 text-orange-500" />
              Recommended Next Actions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2.5">
            {executive.recommended_actions.map((action, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + i * 0.06 }}
                className="flex items-start gap-3 p-3 rounded-xl hover:bg-gray-50/80 dark:hover:bg-zinc-800/30 transition-colors"
              >
                <div className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
                  action.priority <= 2 ? 'bg-red-500/10 text-red-600 dark:text-red-400' :
                  action.priority <= 4 ? 'bg-orange-500/10 text-orange-600 dark:text-orange-400' :
                  'bg-gray-500/10 text-gray-600 dark:text-zinc-400'
                }`}>
                  {action.priority}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-900 dark:text-zinc-100">{action.action}</p>
                  <div className="flex gap-2 mt-1.5 flex-wrap">
                    <Badge className="text-[9px] bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20 border" variant="outline">
                      {action.impact}
                    </Badge>
                    <Badge className="text-[9px] bg-gray-500/10 text-gray-600 dark:text-zinc-400 border-gray-500/20 dark:border-zinc-600/20 border" variant="outline">
                      {action.effort}
                    </Badge>
                  </div>
                </div>
              </motion.div>
            ))}
          </CardContent>
        </Card>

        {/* Section 5: Snapshot History */}
        <Card className="glass-card rounded-2xl">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm flex items-center gap-2">
                <History className="size-4 text-violet-500" />
                Snapshot History
              </CardTitle>
              <Button
                size="sm"
                variant="outline"
                className="h-7 text-[11px] rounded-lg gap-1.5"
                onClick={() => setShowSnapshotDialog(true)}
              >
                <Camera className="size-3" /> Save New
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {snapshots.length === 0 ? (
              <div className="text-center py-8">
                <Camera className="size-8 text-gray-300 dark:text-zinc-600 mx-auto mb-3 empty-state-icon" />
                <p className="text-sm text-gray-400 dark:text-zinc-500">No snapshots saved yet</p>
                <p className="text-xs text-gray-300 dark:text-zinc-600 mt-1">Save snapshots to track review progress over time</p>
              </div>
            ) : (
              <div className="space-y-2">
                {snapshots.slice(0, showHistory ? undefined : 5).map((snap, i) => (
                  <motion.div
                    key={snap.id}
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.04 }}
                    className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-gray-50/80 dark:hover:bg-zinc-800/30 transition-colors"
                  >
                    <div className="size-8 rounded-lg bg-violet-500/10 flex items-center justify-center flex-shrink-0">
                      <History className="size-3.5 text-violet-500" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-gray-900 dark:text-zinc-100 truncate">{snap.sessionLabel}</p>
                      <p className="text-[10px] text-gray-400 dark:text-zinc-500">{snap.createdAt ? timeAgo(snap.createdAt) : 'unknown'}</p>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <div className="text-right">
                        <p className="text-[10px] font-bold tabular-nums text-gray-700 dark:text-zinc-300">Risk: {snap.riskScore}</p>
                        <p className="text-[10px] text-gray-400 dark:text-zinc-500">{snap.totalFindings} findings</p>
                      </div>
                      <div className="w-12 h-8 rounded-lg bg-gray-100 dark:bg-zinc-800 flex items-center justify-center">
                        <span className={`text-[10px] font-bold tabular-nums ${
                          snap.conformancePct >= 70 ? 'text-emerald-500' : snap.conformancePct >= 40 ? 'text-amber-500' : 'text-red-500'
                        }`}>
                          {snap.conformancePct}%
                        </span>
                      </div>
                    </div>
                  </motion.div>
                ))}
                {snapshots.length > 5 && !showHistory && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full text-xs text-gray-400 hover:text-gray-600"
                    onClick={() => setShowHistory(true)}
                  >
                    Show all {snapshots.length} snapshots
                  </Button>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  )
}