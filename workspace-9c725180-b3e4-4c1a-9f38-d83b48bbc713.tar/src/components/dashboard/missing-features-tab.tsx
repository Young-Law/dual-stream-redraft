'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { XCircle } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useDashboardData } from './data-context'
import { fadeIn, stagger } from './types'

export function MissingFeaturesTab() {
  const { filteredFeatures, settings } = useDashboardData()

  return (
    <AnimatePresence mode="wait">
      <motion.div key="missing-features" {...fadeIn} className="space-y-4">
        <div className="flex items-center gap-2">
          <XCircle className="size-4 text-orange-500" />
          <span className="text-sm font-semibold text-gray-900 dark:text-zinc-100">{filteredFeatures.length} missing features</span>
        </div>
        <motion.div {...stagger} className="space-y-3">
          {filteredFeatures.map((f, i) => (
            <motion.div key={f.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>
              <Card className="glass-card rounded-2xl">
                <CardHeader className={settings.compactView ? 'pb-1' : 'pb-2'}>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="outline" className={`text-[10px] ${f.priority === 'critical' ? 'border-red-500/20 bg-red-500/10 text-red-600 dark:text-red-400' : f.priority === 'high' ? 'border-orange-500/20 bg-orange-500/10 text-orange-600 dark:text-orange-400' : 'border-gray-500/20 bg-gray-500/10 text-gray-600 dark:text-gray-400'}`}>
                      {f.priority}
                    </Badge>
                    <CardTitle className="text-sm">{f.name}</CardTitle>
                  </div>
                </CardHeader>
                {!settings.compactView && (
                  <CardContent className="pt-0">
                    <CardDescription className="text-xs leading-relaxed">{f.description}</CardDescription>
                  </CardContent>
                )}
              </Card>
            </motion.div>
          ))}
          {filteredFeatures.length === 0 && (
            <Card className="glass-card rounded-2xl"><CardContent className="py-12 text-center text-sm text-gray-400">No features found.</CardContent></Card>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}