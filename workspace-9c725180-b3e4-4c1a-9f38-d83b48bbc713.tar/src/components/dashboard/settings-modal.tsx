'use client'

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Settings, RotateCcw } from 'lucide-react'
import { useDashboardData } from './data-context'

const TAB_OPTIONS = [
  { value: 'overview', label: 'Overview' },
  { value: 'executive', label: 'Executive' },
  { value: 'critical-bugs', label: 'Critical' },
  { value: 'all-bugs', label: 'All Bugs' },
  { value: 'spec-violations', label: 'Spec' },
  { value: 'missing-features', label: 'Missing' },
  { value: 'test-gaps', label: 'Tests' },
  { value: 'architecture', label: 'Architecture' },
  { value: 'risk-matrix', label: 'Risk' },
  { value: 'trends', label: 'Trends' },
  { value: 'activity', label: 'Activity' },
]

const REFRESH_OPTIONS = [
  { value: 30, label: '30s' },
  { value: 60, label: '60s' },
  { value: 120, label: '2min' },
]

export function SettingsModal() {
  const { showSettings, setShowSettings, settings, setSettings, refetch } = useDashboardData()

  return (
    <Dialog open={showSettings} onOpenChange={setShowSettings}>
      <DialogContent className="sm:max-w-md glass-card rounded-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base">
            <div className="size-8 rounded-lg bg-gray-900 dark:bg-zinc-100 flex items-center justify-center">
              <Settings className="size-4 text-white dark:text-zinc-900" />
            </div>
            Dashboard Settings
          </DialogTitle>
          <DialogDescription>Configure your dashboard preferences</DialogDescription>
        </DialogHeader>
        <div className="space-y-5 mt-2">
          {/* Default Tab */}
          <div className="space-y-3">
            <Label className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest">Default Tab</Label>
            <div className="grid grid-cols-3 gap-1.5">
              {TAB_OPTIONS.slice(0, 6).map(tab => (
                <Button
                  key={tab.value}
                  size="sm"
                  variant={settings.defaultTab === tab.value ? 'default' : 'outline'}
                  className="text-[11px] h-8 rounded-xl transition-all active:scale-95"
                  onClick={() => setSettings(p => ({ ...p, defaultTab: tab.value }))}
                >
                  {tab.label}
                </Button>
              ))}
            </div>
          </div>
          <Separator />
          {/* Compact View */}
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-sm font-medium">Compact View</Label>
              <p className="text-[11px] text-gray-400 dark:text-zinc-500">Reduce padding, hide descriptions</p>
            </div>
            <Switch
              checked={settings.compactView}
              onCheckedChange={(v) => setSettings(p => ({ ...p, compactView: v }))}
            />
          </div>
          <Separator />
          {/* Auto-Refresh */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">Auto-Refresh</Label>
              <Switch
                checked={settings.autoRefresh}
                onCheckedChange={(v) => setSettings(p => ({ ...p, autoRefresh: v }))}
              />
            </div>
            {settings.autoRefresh && (
              <div className="flex gap-1.5">
                {REFRESH_OPTIONS.map(opt => (
                  <Button
                    key={opt.value}
                    size="sm"
                    variant={settings.refreshInterval === opt.value ? 'default' : 'outline'}
                    className="text-[11px] h-7 rounded-lg flex-1"
                    onClick={() => setSettings(p => ({ ...p, refreshInterval: opt.value }))}
                  >
                    {opt.label}
                  </Button>
                ))}
              </div>
            )}
          </div>
          <Separator />
          {/* Manual Refresh */}
          <Button
            variant="outline"
            className="w-full rounded-xl gap-2"
            onClick={refetch}
          >
            <RotateCcw className="size-3.5" /> Refresh Data Now
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
