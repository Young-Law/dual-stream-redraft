'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { TestTube2, Filter } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { useDashboardData } from './data-context'
import { fadeIn, stagger } from './types'

export function TestGapsTab() {
  const { filteredGaps, gapCategories, gapFilter, setGapFilter, settings } = useDashboardData()

  return (
    <AnimatePresence mode="wait">
      <motion.div key="test-gaps" {...fadeIn} className="space-y-4">
        {/* Category filter tabs */}
        <div className="flex items-center gap-2">
          <Filter className="size-4 text-gray-400" />
          <Button size="sm" variant={gapFilter === 'all' ? 'default' : 'outline'} className="h-7 text-xs rounded-lg" onClick={() => setGapFilter('all')}>
            All ({filteredGaps.length})
          </Button>
          {gapCategories.map(cat => (
            <Button key={cat} size="sm" variant={gapFilter === cat ? 'default' : 'outline'} className="h-7 text-xs rounded-lg" onClick={() => setGapFilter(cat)}>
              {cat}
            </Button>
          ))}
        </div>
        <motion.div {...stagger} className="space-y-3">
          {filteredGaps.map((g, i) => (
            <motion.div key={g.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>
              <Card className="glass-card rounded-2xl">
                <CardHeader className={settings.compactView ? 'pb-1' : 'pb-2'}>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="outline" className="text-[10px] bg-violet-500/10 text-violet-600 dark:text-violet-400 border-violet-500/20">{g.category}</Badge>
                    <CardTitle className="text-sm">{g.description}</CardTitle>
                  </div>
                </CardHeader>
                {!settings.compactView && (
                  <CardContent className="pt-0">
                    <CardDescription className="text-xs">Test gap in {g.category}</CardDescription>
                  </CardContent>
                )}
              </Card>
            </motion.div>
          ))}
          {filteredGaps.length === 0 && (
            <Card className="glass-card rounded-2xl"><CardContent className="py-12 text-center text-sm text-gray-400">No test gaps found.</CardContent></Card>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}