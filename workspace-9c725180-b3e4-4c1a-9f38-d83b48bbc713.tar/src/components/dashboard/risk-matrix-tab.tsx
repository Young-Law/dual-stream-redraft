'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { Target, FileCode2, Link2 } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useDashboardData } from './data-context'
import { fadeIn, SEV_COLORS } from './types'

const BUG_FEATURE_CORRELATION = [
  { feature: 'Binary Wire Format', bugs: 4, priority: 92, color: '#ef4444' },
  { feature: 'Streaming Architecture', bugs: 3, priority: 78, color: '#f97316' },
  { feature: 'Extension System', bugs: 2, priority: 65, color: '#eab308' },
  { feature: 'Conformance Engine', bugs: 5, priority: 88, color: '#ef4444' },
  { feature: 'Type System v3', bugs: 3, priority: 71, color: '#f97316' },
]

export function RiskMatrixTab() {
  const { bugs, heatmap, handleHeatmapClick, trends, settings } = useDashboardData()

  const sevCatMatrix = ['critical', 'high', 'medium', 'low'].map(sev => {
    const cats = { source: 0, test: 0 }
    bugs.filter(b => b.severity === sev).forEach(b => { cats[b.category]++ })
    return { severity: sev, ...cats }
  })

  return (
    <AnimatePresence mode="wait">
      <motion.div key="risk-matrix" {...fadeIn} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Severity × Category Grid */}
          <Card className="glass-card rounded-2xl border border-gray-200/50 dark:border-zinc-700/30 shadow-sm hover:shadow-md transition-all duration-300">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Target className="size-4 text-red-500" /> Severity × Category
              </CardTitle>
              <CardDescription>Bug distribution across severity levels and categories</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-1">
                <div />
                <div className="text-center text-[10px] font-bold text-gray-400 uppercase pb-1">Source</div>
                <div className="text-center text-[10px] font-bold text-gray-400 uppercase pb-1">Test</div>
                {sevCatMatrix.map(row => (
                  <>
                    <div key={`${row.severity}-label`} className="flex items-center gap-1.5 text-xs font-medium text-gray-700 dark:text-zinc-300">
                      <div className="size-2.5 rounded-full" style={{ background: SEV_COLORS[row.severity] }} />
                      {row.severity}
                    </div>
                    <div key={`${row.severity}-source`} className={`rounded-lg p-2 text-center text-sm font-bold tabular-nums ${row.source > 0 ? 'bg-red-500/10 text-red-600' : 'bg-gray-50 dark:bg-zinc-800/30 text-gray-300'}`}>
                      {row.source}
                    </div>
                    <div key={`${row.severity}-test`} className={`rounded-lg p-2 text-center text-sm font-bold tabular-nums ${row.test > 0 ? 'bg-orange-500/10 text-orange-600' : 'bg-gray-50 dark:bg-zinc-800/30 text-gray-300'}`}>
                      {row.test}
                    </div>
                  </>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* File Heatmap */}
          <Card className="glass-card rounded-2xl border border-gray-200/50 dark:border-zinc-700/30 shadow-sm hover:shadow-md transition-all duration-300">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <FileCode2 className="size-4 text-orange-500" /> File Heatmap
              </CardTitle>
              <CardDescription>Files with most bugs — click to filter</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {heatmap.slice(0, 15).map((entry, i) => {
                  const maxBugs = heatmap[0]?.bugs || 1
                  const widthPct = (entry.bugs / maxBugs) * 100
                  return (
                    <button key={entry.file} onClick={() => handleHeatmapClick(entry.file)} className="w-full text-left group">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[10px] font-mono text-gray-500 dark:text-zinc-400 group-hover:text-gray-900 dark:group-hover:text-zinc-100 transition-colors truncate flex-1">
                          {entry.file.split('/').pop() || entry.file}
                        </span>
                        <span className="text-xs font-bold tabular-nums text-gray-900 dark:text-zinc-100">{entry.bugs}</span>
                      </div>
                      <div className="h-2 rounded-full bg-gray-100 dark:bg-zinc-800 overflow-hidden">
                        <motion.div
                          className="h-full rounded-full"
                          style={{ background: entry.critical > 0 ? '#ef4444' : entry.high > 0 ? '#f97316' : '#eab308' }}
                          initial={{ width: 0 }}
                          animate={{ width: `${widthPct}%` }}
                          transition={{ delay: 0.2 + i * 0.05, duration: 0.6 }}
                        />
                      </div>
                    </button>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Bug-Feature Correlation with Priority Bars */}
        <Card className="glass-card rounded-2xl">
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <Link2 className="size-4 text-violet-500" /> Bug-Feature Correlation
            </CardTitle>
            <CardDescription>Features with highest bug density</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {BUG_FEATURE_CORRELATION.map((item, i) => (
              <motion.div
                key={item.feature}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 + i * 0.08 }}
                className="space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="size-2.5 rounded-full" style={{ background: item.color }} />
                    <span className="text-sm font-medium text-gray-900 dark:text-zinc-100">{item.feature}</span>
                  </div>
                  <Badge variant="outline" className="text-[10px] tabular-nums">{item.bugs} bugs</Badge>
                </div>
                <div className="h-2 rounded-full bg-gray-100 dark:bg-zinc-800 overflow-hidden">
                  <motion.div
                    className="h-full rounded-full"
                    style={{ background: item.color }}
                    initial={{ width: 0 }}
                    animate={{ width: `${item.priority}%` }}
                    transition={{ delay: 0.4 + i * 0.1, duration: 0.6 }}
                  />
                </div>
              </motion.div>
            ))}
          </CardContent>
        </Card>

        {/* Top Risk Files */}
        {trends?.top_risk_files && trends.top_risk_files.length > 0 && (
          <Card className="glass-card rounded-2xl">
            <CardHeader>
              <CardTitle className="text-sm">Top Risk Files</CardTitle>
              <CardDescription>Highest risk scores by file</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {trends.top_risk_files.slice(0, 6).map((f, i) => (
                  <motion.div
                    key={f.file}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="rounded-xl border p-3 space-y-1.5 cursor-pointer hover:bg-gray-50/80 dark:hover:bg-zinc-800/30 transition-colors"
                    onClick={() => handleHeatmapClick(f.file)}
                  >
                    <p className="text-xs font-mono text-gray-900 dark:text-zinc-100 truncate">{f.file.split('/').pop()}</p>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-[10px]">Risk: {f.risk}</Badge>
                      <span className="text-[10px] text-gray-400">{f.bugs} bugs</span>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </motion.div>
    </AnimatePresence>
  )
}