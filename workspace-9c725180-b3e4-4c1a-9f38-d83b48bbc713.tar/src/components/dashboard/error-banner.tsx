'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { AlertTriangle, RefreshCw, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useDashboardData } from './data-context'

export function ErrorBanner() {
  const { error, loading, refetch } = useDashboardData()
  const [retrying, setRetrying] = useState(false)
  const [dismissed, setDismissed] = useState(false)

  if (!error || dismissed) return null

  const handleRetry = async () => {
    setRetrying(true)
    try {
      await refetch()
    } finally {
      setRetrying(false)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="rounded-xl border border-red-200 dark:border-red-500/20 bg-red-50 dark:bg-red-500/8 px-4 py-3 flex items-start gap-3"
    >
      <div className="size-8 rounded-lg bg-red-100 dark:bg-red-500/15 flex items-center justify-center shrink-0 mt-0.5">
        <AlertTriangle className="size-4 text-red-500 dark:text-red-400" />
      </div>
      <div className="flex-1 min-w-0">
        <h3 className="text-sm font-semibold text-red-800 dark:text-red-300">Failed to load dashboard data</h3>
        <p className="text-xs text-red-600 dark:text-red-400/80 mt-0.5 truncate">
          {error}
        </p>
      </div>
      <div className="flex items-center gap-1.5 shrink-0">
        <Button
          variant="outline"
          size="sm"
          className="h-7 text-xs border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-300 hover:bg-red-100 dark:hover:bg-red-500/15"
          onClick={handleRetry}
          disabled={retrying || loading}
        >
          <RefreshCw className={`size-3 mr-1 ${retrying ? 'animate-spin' : ''}`} />
          Retry
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7 text-red-400 hover:text-red-600 dark:hover:text-red-300"
          onClick={() => setDismissed(true)}
        >
          <X className="size-3.5" />
        </Button>
      </div>
    </motion.div>
  )
}
