'use client'

import { useState, useEffect } from 'react'

export function ConformanceGauge({ value, size = 140 }: { value: number; size?: number }) {
  const [animated, setAnimated] = useState(0)
  const r = (size - 24) / 2
  const circ = 2 * Math.PI * r
  useEffect(() => {
    const timer = setTimeout(() => setAnimated(value), 100)
    return () => clearTimeout(timer)
  }, [value])
  const color = value >= 80 ? '#10b981' : value >= 50 ? '#f59e0b' : '#ef4444'
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="currentColor" strokeWidth={10}
          className="text-gray-100 dark:text-zinc-800" />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={10}
          strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={circ * (1 - animated / 100)}
          style={{ transition: 'stroke-dashoffset 1.2s cubic-bezier(0.4,0,0.2,1)' }} />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-3xl font-extrabold tabular-nums" style={{ color }}>{animated}%</span>
        <span className="text-[10px] font-semibold text-gray-400 dark:text-zinc-500 uppercase tracking-wider">Conformance</span>
      </div>
    </div>
  )
}