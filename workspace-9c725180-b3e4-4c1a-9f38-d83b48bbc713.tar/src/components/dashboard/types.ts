import {
  CheckCircle, XCircle, AlertTriangle, CircleDot, Eye, Zap,
  Scan, Bug, FileWarning, TestTube2, TrendingUp, Wrench, ShieldCheck,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

// ────────────────────────── Interfaces ──────────────────────────

export interface Summary {
  total_findings: number
  critical: number
  high: number
  medium: number
  low: number
  spec_conformance_pct: number
  missing_features: number
}

export interface Bug {
  id: string
  severity: 'critical' | 'high' | 'medium' | 'low'
  category: 'source' | 'test'
  title: string
  file: string
  line?: string
  description: string
  fix: string
}

export interface SpecViolation {
  id: number
  section: string
  violation: string
  detail: string
}

export interface MissingFeature {
  id: number
  name: string
  description: string
  priority: string
}

export interface TestGap {
  id: number
  description: string
  category: string
}

export interface FileHeatmapEntry {
  file: string
  bugs: number
  critical: number
  high: number
  medium: number
  low: number
  category: string
}

export interface TimelineMilestone {
  phase: string
  label: string
  status: 'done' | 'partial' | 'missing'
  spec_section: string
  description: string
}

export interface WeeklySnapshot {
  week: string
  date: string
  total: number
  critical: number
  high: number
  medium: number
  low: number
  conformance: number
  test_gaps: number
}

export interface SeverityTrend {
  severity: string
  current: number
  previous: number
  change: number
  direction: 'up' | 'flat' | 'down'
  color: string
}

export interface ConformanceTrend {
  phase: string
  target: number
  current: number
  color: string
}

export interface RiskVelocity {
  current_week: number
  previous_week: number
  velocity: number
  trend: string
  avg_weekly_increase: number
}

export interface CategoryBreakdown {
  category: string
  count: number
  critical: number
  high: number
  medium: number
  low: number
  pct: number
}

export interface TopRiskFile {
  file: string
  risk: number
  trend: string
  bugs: number
  fixed?: number
}

export interface TrendsData {
  weekly_snapshots: WeeklySnapshot[]
  severity_trend: SeverityTrend[]
  conformance_trend: ConformanceTrend[]
  risk_velocity: RiskVelocity
  category_breakdown: CategoryBreakdown[]
  top_risk_files: TopRiskFile[]
}

export interface ActivityItem {
  id: number
  type: 'bug_found' | 'bug_fixed' | 'spec_violation' | 'feature_missing' | 'test_gap' | 'conformance_update' | 'review_session'
  title: string
  description: string
  timestamp: string
  severity?: 'critical' | 'high' | 'medium' | 'low' | 'resolved' | 'info'
  icon: string
}

export interface ExecutiveData {
  overall_risk: string
  risk_score: number
  risk_trend: string
  conformance: number
  conformance_target: number
  fix_rate?: number
  key_findings: Array<{ title: string; severity: string; detail: string }>
  recommended_actions: Array<{ priority: number; action: string; impact: string; effort: string }>
  v210_pillars: Array<{ name: string; status: string; pct: number; details: string }>
}

export type TriageStatus = 'none' | 'acknowledged' | 'in-progress' | 'resolved'

export interface BugComment {
  id?: number
  bugId: string
  content: string
  createdAt?: string
}

export interface DashboardSettings {
  defaultTab: string
  compactView: boolean
  autoRefresh: boolean
  refreshInterval: number
}

// ────────────────────────── Constants ──────────────────────────

export const SEV_ORDER = { critical: 0, high: 1, medium: 2, low: 3 } as const

export const SEV_COLORS: Record<string, string> = {
  critical: '#ef4444',
  high: '#f97316',
  medium: '#eab308',
  low: '#6366f1',
}

export const SEV_BG: Record<string, string> = {
  critical: 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/20',
  high: 'bg-orange-500/10 text-orange-600 dark:text-orange-400 border-orange-500/20',
  medium: 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 border-yellow-500/20',
  low: 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-500/20',
}

export const PRIORITY_BORDER: Record<string, string> = {
  critical: 'border-l-red-500',
  high: 'border-l-orange-500',
  medium: 'border-l-amber-500',
}

export const MILESTONE_ICON: Record<string, LucideIcon> = {
  done: CheckCircle,
  partial: AlertTriangle,
  missing: XCircle,
}

export const MILESTONE_COLOR: Record<string, string> = {
  done: 'text-emerald-500',
  partial: 'text-amber-500',
  missing: 'text-red-500',
}

export const MILESTONE_BG: Record<string, string> = {
  done: 'bg-emerald-500/5 border-emerald-500/20 dark:bg-emerald-500/10',
  partial: 'bg-amber-500/5 border-amber-500/20 dark:bg-amber-500/10',
  missing: 'bg-red-500/5 border-red-500/20 dark:bg-red-500/10',
}

export const TRIAGE_CONFIG: Record<TriageStatus, { label: string; color: string; bg: string; border: string; icon: LucideIcon }> = {
  none: { label: 'Untriaged', color: 'text-gray-500 dark:text-zinc-400', bg: 'bg-gray-100 dark:bg-zinc-800', border: 'border-gray-200 dark:border-zinc-700', icon: CircleDot },
  acknowledged: { label: 'Acknowledged', color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-50 dark:bg-amber-500/10', border: 'border-amber-200 dark:border-amber-500/20', icon: Eye },
  'in-progress': { label: 'In Progress', color: 'text-orange-600 dark:text-orange-400', bg: 'bg-orange-50 dark:bg-orange-500/10', border: 'border-orange-200 dark:border-orange-500/20', icon: Zap },
  resolved: { label: 'Resolved', color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-50 dark:bg-emerald-500/10', border: 'border-emerald-200 dark:border-emerald-500/20', icon: CheckCircle },
}

export const ACTIVITY_ICON_MAP: Record<string, LucideIcon> = {
  'scan': Scan,
  'bug': Bug,
  'file-warning': FileWarning,
  'x-circle': XCircle,
  'test-tube': TestTube2,
  'check-circle': CheckCircle,
  'check-circle-2': ShieldCheck,
  'trending-up': TrendingUp,
  'wrench': Wrench,
  'shield-check': ShieldCheck,
}

export const ACTIVITY_TYPE_LABEL: Record<string, string> = {
  'bug_found': 'Bug Found',
  'bug_fixed': 'Bug Fixed',
  'spec_violation': 'Spec Violation',
  'feature_missing': 'Feature Missing',
  'test_gap': 'Test Gap',
  'conformance_update': 'Conformance Update',
  'review_session': 'Review Session',
}

export const ACTIVITY_TYPE_BG: Record<string, string> = {
  'bug_found': 'bg-red-500/10 text-red-600 dark:text-red-400',
  'bug_fixed': 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400',
  'spec_violation': 'bg-amber-500/10 text-amber-600 dark:text-amber-400',
  'feature_missing': 'bg-orange-500/10 text-orange-600 dark:text-orange-400',
  'test_gap': 'bg-violet-500/10 text-violet-600 dark:text-violet-400',
  'conformance_update': 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400',
  'review_session': 'bg-gray-500/10 text-gray-600 dark:text-gray-400',
}

export const fadeIn = {
  initial: { opacity: 0, y: 16 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -8 },
  transition: { duration: 0.25 },
}

export const stagger = {
  animate: { transition: { staggerChildren: 0.04 } },
}
