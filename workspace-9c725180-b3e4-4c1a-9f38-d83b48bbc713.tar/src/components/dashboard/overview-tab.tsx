'use client'

import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { FileCode2, CheckCircle2, FileWarning, Layers, Zap, ShieldCheck, Clock } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useDashboardData } from './data-context'
import { ConformanceGauge } from './conformance-gauge'
import { SeverityDonut } from './severity-donut'
import { MILESTONE_COLOR, MILESTONE_BG, MILESTONE_ICON, fadeIn } from './types'

export function OverviewTab() {
  const {
    summary, sourceBugs, specViolations, testGaps, gapCategories,
    rs, rl, pieData, conformancePct, timeline, settings, triageStats, bugs,
  } = useDashboardData()

  if (!summary) return null

  const s = summary as Record<string, unknown>
  const resolved = (s?.resolved as number) ?? 0
  const total = summary.total_findings
  const openCount = total - resolved

  const milestoneDone = timeline.filter(m => m.status === 'done').length
  const milestonePartial = timeline.filter(m => m.status === 'partial').length
  const milestoneMissing = timeline.filter(m => m.status === 'missing').length

  const resolvedViolations = specViolations.filter((v: { status?: string }) => v.status === 'resolved').length
  const openViolations = specViolations.length - resolvedViolations

  const quickStats = [
    { l: 'Source Bugs Fixed', v: `${resolved}/${total}`, s: resolved === total ? 'All resolved' : `${openCount} remaining`, icon: CheckCircle2, c: resolved === total ? 'text-emerald-500' : 'text-amber-500' },
    { l: 'Spec Violations', v: `${openViolations} open`, s: `${resolvedViolations} resolved`, icon: FileWarning, c: openViolations > 0 ? 'text-amber-500' : 'text-emerald-500' },
    { l: 'Test Gap Categories', v: gapCategories.length, s: `${testGaps.length} total gaps`, icon: Layers, c: 'text-violet-500' },
    { l: 'Risk Score', v: rs, s: rl.label + ' risk', icon: ShieldCheck, c: rl.color },
    { l: 'Conformance', v: `${summary.spec_conformance_pct}%`, s: 'v2.10 spec', icon: Zap, c: 'text-emerald-500' },
  ]

  return (
    <AnimatePresence mode="wait">
      <motion.div key="overview" {...fadeIn} className="space-y-6">
        {/* Resolution Banner — shown when all bugs are resolved */}
        {resolved === total && total > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-2xl border border-emerald-500/20 bg-gradient-to-r from-emerald-500/10 via-emerald-500/5 to-transparent p-4 sm:p-5"
          >
            <div className="flex items-center gap-3">
              <div className="size-10 rounded-xl bg-emerald-500/15 flex items-center justify-center flex-shrink-0">
                <ShieldCheck className="size-5 text-emerald-600 dark:text-emerald-400" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-emerald-800 dark:text-emerald-300">All {total} bugs resolved</h3>
                <p className="text-xs text-emerald-600/80 dark:text-emerald-400/80 mt-0.5">
                  3 Critical, 6 High, 10 Medium, 6 Low — patched in dual-stream-redraft. 83/83 tests passing.
                </p>
              </div>
              <Badge className="ml-auto bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/20 hover:bg-emerald-500/20">
                100% Fix Rate
              </Badge>
            </div>
          </motion.div>
        )}

        {/* Quick Stats + Donut Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Conformance Gauge with Milestone Stats */}
          <Card className="glass-card glass-card-animated rounded-2xl border border-gray-200/50 dark:border-zinc-700/30 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-300 card-depth-1">
            <CardHeader className="pb-2 text-center">
              <CardTitle className="text-sm">Conformance</CardTitle>
              <CardDescription>DSA v2.10 spec compliance</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center">
              <ConformanceGauge value={summary.spec_conformance_pct} />
              <div className="mt-3 w-full space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1.5">
                    <span className="size-2 rounded-full bg-emerald-500" />
                    Done
                  </span>
                  <span className="font-bold tabular-nums text-gray-900 dark:text-zinc-100">{milestoneDone}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1.5">
                    <span className="size-2 rounded-full bg-amber-500" />
                    Partial
                  </span>
                  <span className="font-bold tabular-nums text-gray-900 dark:text-zinc-100">{milestonePartial}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1.5">
                    <span className="size-2 rounded-full bg-red-500" />
                    Missing
                  </span>
                  <span className="font-bold tabular-nums text-gray-900 dark:text-zinc-100">{milestoneMissing}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Severity Donut */}
          <Card className="glass-card glass-card-animated rounded-2xl border border-gray-200/50 dark:border-zinc-700/30 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-300 card-depth-1">
            <CardHeader className="pb-2 text-center">
              <CardTitle className="text-sm">Severity Distribution</CardTitle>
              <CardDescription>Breakdown by severity (all resolved)</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center">
              <SeverityDonut data={pieData} total={summary.total_findings} />
              <div className="grid grid-cols-2 gap-x-6 gap-y-1.5 w-full mt-3">
                {pieData.map(d => (
                  <div key={d.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <div className="size-2.5 rounded-full" style={{ background: d.fill }} />
                      <span className="text-xs text-gray-600 dark:text-zinc-400">{d.name}</span>
                    </div>
                    <span className="text-xs font-bold tabular-nums text-gray-900 dark:text-zinc-100">{d.value}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats Grid */}
          <Card className="glass-card glass-card-animated rounded-2xl border border-gray-200/50 dark:border-zinc-700/30 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-300 card-depth-1">
            <CardHeader className="pb-2 text-center">
              <CardTitle className="text-sm">Quick Stats</CardTitle>
              <CardDescription>Key metrics at a glance</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {quickStats.map((stat, i) => (
                <motion.div
                  key={stat.l}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + i * 0.05 }}
                  className="flex items-center gap-3"
                >
                  <div className="size-8 rounded-lg bg-gray-100 dark:bg-zinc-800 flex items-center justify-center flex-shrink-0">
                    <stat.icon className={`size-4 ${stat.c}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-gray-500 dark:text-zinc-400">{stat.l}</p>
                    <p className="text-sm font-bold tabular-nums text-gray-900 dark:text-zinc-100">{stat.v}</p>
                  </div>
                  <span className="text-[10px] text-gray-400 dark:text-zinc-500">{stat.s}</span>
                </motion.div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Conformance Timeline */}
        <Card className="glass-card rounded-2xl border border-gray-200/50 dark:border-zinc-700/30 card-depth-1">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Zap className="size-4 text-orange-500" /> Conformance Roadmap
              <Badge variant="outline" className="text-[9px] font-normal">{milestoneDone}/{timeline.length} complete</Badge>
            </CardTitle>
            <CardDescription>Implementation progress across v2.10 spec phases</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {timeline.map((m, i) => (
                <motion.div
                  key={m.phase}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 + i * 0.05 }}
                  className={`rounded-xl border p-3 space-y-1.5 ${MILESTONE_BG[m.status]}`}
                >
                  <div className="flex items-center justify-between">
                    <Badge className="text-[9px]" variant="outline">{m.phase}</Badge>
                    {React.createElement(MILESTONE_ICON[m.status], { className: `size-3.5 ${MILESTONE_COLOR[m.status]}` })}
                  </div>
                  <p className="text-xs font-semibold text-gray-900 dark:text-zinc-100">{m.label}</p>
                  <p className="text-[10px] text-gray-500 dark:text-zinc-400 line-clamp-1">{m.description}</p>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  )
}