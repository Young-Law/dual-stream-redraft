'use client'

import { useMemo } from 'react'
import { FileCode2, ExternalLink, X, AlertOctagon, AlertTriangle, Info } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useDashboardData } from './data-context'
import { SEV_BG, SEV_ORDER, TRIAGE_CONFIG } from './types'

export function FileDrilldownModal() {
  const {
    bugs, selectedBug, setSelectedBug, drawerOpen, setDrawerOpen,
    openBug, triageState, setFileFilter, setActiveTab,
  } = useDashboardData()

  const drilldownFile = selectedBug?._drilldownFile as string | undefined

  const fileBugs = useMemo(() => {
    if (!drilldownFile) return []
    return bugs
      .filter(b => b.file === drilldownFile)
      .sort((a, b) => SEV_ORDER[a.severity] - SEV_ORDER[b.severity])
  }, [bugs, drilldownFile])

  const severityCounts = useMemo(() => {
    const counts: Record<string, number> = { critical: 0, high: 0, medium: 0, low: 0 }
    fileBugs.forEach(b => { counts[b.severity]++ })
    return counts
  }, [fileBugs])

  const isOpen = drawerOpen && !!drilldownFile
  const handleClose = () => { setDrawerOpen(false); setSelectedBug(null) }
  const handleViewInTable = () => {
    const file = drilldownFile
    handleClose()
    if (file) { setFileFilter(file); setActiveTab('all-bugs') }
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          {/* Backdrop */}
          <motion.div
            className="absolute inset-0 bg-black/40 dark:bg-black/60 backdrop-blur-sm"
            onClick={handleClose}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />

          {/* Modal */}
          <motion.div
            className="relative w-full max-w-2xl max-h-[85vh] glass rounded-2xl border border-white/20 dark:border-zinc-700/50 shadow-2xl overflow-hidden"
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          >
            {/* Header */}
            <div className="px-6 py-4 border-b border-gray-200/50 dark:border-zinc-700/50">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="size-10 rounded-xl bg-gradient-to-br from-red-500/10 to-orange-500/10 dark:from-red-500/20 dark:to-orange-500/20 flex items-center justify-center shrink-0">
                    <FileCode2 className="size-5 text-red-500" />
                  </div>
                  <div className="min-w-0">
                    <h2 className="text-sm font-bold text-gray-900 dark:text-zinc-100 truncate">File Analysis</h2>
                    <p className="text-xs text-gray-500 dark:text-zinc-400 font-mono truncate mt-0.5">
                      {drilldownFile}
                    </p>
                  </div>
                </div>
                <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" onClick={handleClose}>
                  <X className="size-3.5" />
                </Button>
              </div>

              {/* Stats row */}
              <div className="flex items-center gap-2 mt-3 flex-wrap">
                <Badge variant="outline" className={`text-[10px] ${SEV_BG.critical} border`}>
                  <AlertOctagon className="size-2.5 mr-1" />
                  {severityCounts.critical} Critical
                </Badge>
                <Badge variant="outline" className={`text-[10px] ${SEV_BG.high} border`}>
                  <AlertTriangle className="size-2.5 mr-1" />
                  {severityCounts.high} High
                </Badge>
                <Badge variant="outline" className={`text-[10px] ${SEV_BG.medium} border`}>
                  <Info className="size-2.5 mr-1" />
                  {severityCounts.medium} Med
                </Badge>
                <Badge variant="outline" className={`text-[10px] ${SEV_BG.low} border`}>
                  {severityCounts.low} Low
                </Badge>
                <div className="flex-1" />
                <span className="text-xs font-bold text-gray-700 dark:text-zinc-300 tabular-nums">
                  {fileBugs.length} bug{fileBugs.length !== 1 ? 's' : ''}
                </span>
              </div>
            </div>

            {/* Bug list */}
            <ScrollArea className="max-h-[55vh]">
              <div className="p-4 space-y-2">
                {fileBugs.length === 0 && (
                  <div className="text-center py-12">
                    <FileCode2 className="size-10 text-gray-300 dark:text-zinc-600 mx-auto mb-3 empty-state-icon" />
                    <p className="text-sm text-gray-500 dark:text-zinc-400">No bugs found in this file</p>
                  </div>
                )}
                {fileBugs.map((bug, idx) => {
                  const triage = triageState[bug.id] || 'none'
                  const cfg = TRIAGE_CONFIG[triage]
                  return (
                    <motion.div
                      key={bug.id}
                      initial={{ opacity: 0, x: -12 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.04 }}
                      className="glass-card rounded-xl p-3.5 cursor-pointer group hover:shadow-md"
                      onClick={() => { handleClose(); setTimeout(() => openBug(bug), 200) }}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5 mb-1.5 flex-wrap">
                            <Badge variant="outline" className={`text-[9px] shrink-0 ${SEV_BG[bug.severity]} border`}>
                              {bug.severity}
                            </Badge>
                            <Badge variant="outline" className={`text-[9px] shrink-0 ${cfg.bg} ${cfg.border} border`}>
                              <cfg.icon className="size-2 mr-0.5" />
                              {cfg.label}
                            </Badge>
                            {bug.line && (
                              <span className="text-[10px] font-mono text-gray-400 dark:text-zinc-500">
                                L{bug.line}
                              </span>
                            )}
                          </div>
                          <p className="text-xs font-medium text-gray-800 dark:text-zinc-200 leading-relaxed">
                            {bug.title}
                          </p>
                          <p className="text-[11px] text-gray-500 dark:text-zinc-400 mt-1 line-clamp-2">
                            {bug.description}
                          </p>
                        </div>
                        <ExternalLink className="size-3.5 text-gray-300 dark:text-zinc-600 group-hover:text-gray-500 dark:group-hover:text-zinc-400 transition-colors shrink-0 mt-1" />
                      </div>
                    </motion.div>
                  )
                })}
              </div>
            </ScrollArea>

            {/* Footer */}
            <div className="px-6 py-3 border-t border-gray-200/50 dark:border-zinc-700/50 flex items-center justify-between">
              <p className="text-[11px] text-gray-400 dark:text-zinc-500">
                Click any bug to view full details
              </p>
              <Button
                variant="ghost"
                size="sm"
                className="text-xs h-7"
                onClick={handleViewInTable}
              >
                View in All Bugs
                <ExternalLink className="size-3 ml-1" />
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
