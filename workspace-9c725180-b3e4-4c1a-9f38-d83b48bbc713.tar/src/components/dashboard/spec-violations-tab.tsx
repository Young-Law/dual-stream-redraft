'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { FileWarning, CheckCircle2, Clock, AlertTriangle } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useDashboardData } from './data-context'
import { fadeIn, stagger } from './types'

const STATUS_CONFIG: Record<string, { icon: typeof CheckCircle2; color: string; bg: string; border: string; label: string }> = {
  resolved: { icon: CheckCircle2, color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20', label: 'Resolved' },
  partial: { icon: Clock, color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20', label: 'Partial' },
  open: { icon: AlertTriangle, color: 'text-red-600 dark:text-red-400', bg: 'bg-red-500/10', border: 'border-red-500/20', label: 'Open' },
}

export function SpecViolationsTab() {
  const { filteredViolations, settings } = useDashboardData()

  const resolvedCount = filteredViolations.filter((v: { status?: string }) => v.status === 'resolved').length
  const openCount = filteredViolations.length - resolvedCount

  return (
    <AnimatePresence mode="wait">
      <motion.div key="spec-violations" {...fadeIn} className="space-y-4">
        <div className="flex items-center gap-2 flex-wrap">
          <FileWarning className="size-4 text-amber-500" />
          <span className="text-sm font-semibold text-gray-900 dark:text-zinc-100">{filteredViolations.length} spec violations</span>
          {resolvedCount > 0 && (
            <Badge className="bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-500/20 border text-[10px]">
              {resolvedCount} resolved
            </Badge>
          )}
          {openCount > 0 && (
            <Badge className="bg-red-500/10 text-red-700 dark:text-red-300 border-red-500/20 border text-[10px]">
              {openCount} open
            </Badge>
          )}
        </div>
        <motion.div {...stagger} className="space-y-3">
          {filteredViolations.map((v, i) => {
            const status = (v as { status?: string }).status || 'open'
            const cfg = STATUS_CONFIG[status] || STATUS_CONFIG.open
            const StatusIcon = cfg.icon
            const borderClass = status === 'resolved'
              ? 'border-l-emerald-500 opacity-75'
              : status === 'partial'
                ? 'border-l-amber-500'
                : 'border-l-red-500'
            return (
              <motion.div key={v.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>
                <Card className={`glass-card rounded-2xl border-l-4 ${borderClass}`}>
                  <CardHeader className={settings.compactView ? 'pb-1' : 'pb-2'}>
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge variant="outline" className="text-[10px]">{v.section}</Badge>
                      <CardTitle className="text-sm">{v.violation}</CardTitle>
                      <Badge variant="outline" className={`text-[10px] ${cfg.bg} ${cfg.border} border`}>
                        <StatusIcon className={`size-2.5 mr-0.5 ${cfg.color}`} />
                        {cfg.label}
                      </Badge>
                    </div>
                  </CardHeader>
                  {!settings.compactView && (
                    <CardContent className="pt-0">
                      <CardDescription className="text-xs leading-relaxed">{v.detail}</CardDescription>
                    </CardContent>
                  )}
                </Card>
              </motion.div>
            )
          })}
          {filteredViolations.length === 0 && (
            <Card className="glass-card rounded-2xl"><CardContent className="py-12 text-center text-sm text-gray-400">No violations found.</CardContent></Card>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}