'use client'

import { useMemo } from 'react'

export function SeverityDonut({ data, total }: { data: { name: string; value: number; fill: string }[]; total: number }) {
  const size = 160
  const r = 60
  const ir = 38
  const circ = 2 * Math.PI * r
  const slices = useMemo(() => {
    return data.reduce<Array<{ fill: string; dashLen: number; gap: number; startOffset: number; pct: number }>>((acc, d) => {
      const lastOffset = acc.length > 0 ? acc[acc.length - 1].startOffset + acc[acc.length - 1].dashLen : 0
      const pct = d.value / total
      const dashLen = circ * pct
      const gap = circ - dashLen
      acc.push({ fill: d.fill, dashLen, gap, startOffset: lastOffset, pct })
      return acc
    }, [])
  }, [data, total, circ])
  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size}>
        {slices.map((s, i) => (
          <circle
            key={i}
            cx={size / 2} cy={size / 2} r={r}
            fill="none" stroke={s.fill} strokeWidth={16}
            strokeDasharray={`${s.dashLen} ${s.gap}`}
            strokeDashoffset={-s.startOffset}
            strokeLinecap="butt"
            className="transition-all duration-700"
            style={{ opacity: s.pct > 0 ? 1 : 0, transformOrigin: 'center' }}
          />
        ))}
        <circle cx={size / 2} cy={size / 2} r={ir} fill="white" className="dark:fill-zinc-900" />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-2xl font-extrabold tabular-nums text-gray-900 dark:text-zinc-100">{total}</span>
        <span className="text-[10px] text-gray-400 dark:text-zinc-500 font-medium">Findings</span>
      </div>
    </div>
  )
}
