'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useDashboardData } from './data-context'
import { ACTIVITY_ICON_MAP, ACTIVITY_TYPE_LABEL, ACTIVITY_TYPE_BG, fadeIn } from './types'
import { timeAgo } from './hooks'

const SEV_BADGE: Record<string, string> = {
  critical: 'bg-red-500/10 text-red-600 border-red-500/20',
  high: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
  medium: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
  low: 'bg-indigo-500/10 text-indigo-600 border-indigo-500/20',
  resolved: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  info: 'bg-gray-500/10 text-gray-600 border-gray-500/20',
}

const DOT_COLOR: Record<string, string> = {
  bug_fixed: 'bg-emerald-500',
  bug_found: 'bg-red-500',
  conformance_update: 'bg-emerald-500',
  review_session: 'bg-gray-400',
}

export function ActivityTab() {
  const { activity } = useDashboardData()

  return (
    <AnimatePresence mode="wait">
      <motion.div key="activity" {...fadeIn} className="space-y-6">
        <Card className="glass-card rounded-2xl">
          <CardHeader>
            <CardTitle className="text-sm">Activity Timeline</CardTitle>
            <CardDescription>Recent review & fix activity</CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="max-h-[600px]">
              <div className="relative pl-6">
                <div className="absolute left-2 top-0 bottom-0 w-px bg-gray-200 dark:bg-zinc-700" />
                <div className="space-y-4">
                  {activity.map((item, i) => {
                    const Icon = ACTIVITY_ICON_MAP[item.icon] || ACTIVITY_ICON_MAP['scan']
                    const typeLabel = ACTIVITY_TYPE_LABEL[item.type] || item.type
                    const typeBg = ACTIVITY_TYPE_BG[item.type] || 'bg-gray-500/10 text-gray-600'
                    const dotColor = DOT_COLOR[item.type] || 'bg-orange-500'
                    return (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.05 }}
                        className="relative"
                      >
                        <div className="absolute -left-6 top-1 size-4 rounded-full bg-background border-2 border-gray-200 dark:border-zinc-700 flex items-center justify-center">
                          <div className={`size-1.5 rounded-full ${dotColor}`} />
                        </div>
                        <div className="ml-2 space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <Icon className="size-3.5 text-gray-400" />
                            <span className="text-sm font-medium text-gray-900 dark:text-zinc-100">{item.title}</span>
                            <Badge className={`text-[9px] border ${typeBg}`} variant="outline">{typeLabel}</Badge>
                            {item.severity && (
                              <Badge className={`text-[9px] border ${SEV_BADGE[item.severity] || SEV_BADGE.info}`} variant="outline">
                                {item.severity}
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-gray-500 dark:text-zinc-400">{item.description}</p>
                          <p className="text-[10px] text-gray-400 dark:text-zinc-500">{timeAgo(item.timestamp)}</p>
                        </div>
                      </motion.div>
                    )
                  })}
                  {activity.length === 0 && (
                    <p className="text-sm text-gray-400 text-center py-8">No activity recorded.</p>
                  )}
                </div>
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  )
}