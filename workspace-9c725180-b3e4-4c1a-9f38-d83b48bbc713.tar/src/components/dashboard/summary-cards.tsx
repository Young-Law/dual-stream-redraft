'use client'

import { motion } from 'framer-motion'
import { XCircle, AlertTriangle, Bug, Zap, FileCode2, TrendingUp, TrendingDown, Minus, CheckCircle2 } from 'lucide-react'
import { useDashboardData } from './data-context'
import { stagger } from './types'
import { riskLabel } from './hooks'

export function SummaryCards() {
  const {
    animCritical, animHigh, animTotal, animMissing, animRisk,
    summary, settings, trends,
  } = useDashboardData()

  const compact = settings.compactView
  const s = summary as Record<string, unknown> | null
  const openCritical = (s?.open_critical as number) ?? (summary?.critical ?? 0)
  const openHigh = (s?.open_high as number) ?? (summary?.high ?? 0)
  const resolved = (s?.resolved as number) ?? 0
  const total = summary?.total_findings ?? 0
  const fixRate = total > 0 ? Math.round((resolved / total) * 100) : 0

  const rl = riskLabel(summary ? 0 : 0) // computed from open bugs now

  const prevTotal = trends?.weekly_snapshots?.[trends.weekly_snapshots.length - 2]?.total
  const totalChange = prevTotal != null && summary ? summary.total_findings - prevTotal : undefined

  const ChangeIcon = totalChange == null ? Minus : totalChange > 0 ? TrendingUp : totalChange < 0 ? TrendingDown : Minus
  const changeColor = totalChange == null ? 'text-gray-400' : totalChange > 0 ? 'text-red-500' : totalChange < 0 ? 'text-emerald-500' : 'text-gray-400'

  const cards = [
    {
      label: 'Open Critical',
      value: openCritical,
      icon: XCircle,
      color: openCritical > 0 ? 'text-red-500' : 'text-emerald-500',
      bg: openCritical > 0 ? 'from-red-500/8 to-red-500/3' : 'from-emerald-500/8 to-emerald-500/3',
      border: openCritical > 0 ? 'border-red-500/15' : 'border-emerald-500/15',
      iconBg: openCritical > 0 ? 'bg-red-500/10' : 'bg-emerald-500/10',
      glow: openCritical > 0 ? 'glow-red' : '',
      subLabel: openCritical === 0 ? 'All clear' : `${openCritical} unresolved`,
      ring: openCritical > 0 ? 'ring-red-500/5' : 'ring-emerald-500/5',
    },
    {
      label: 'Open High',
      value: openHigh,
      icon: AlertTriangle,
      color: openHigh > 0 ? 'text-orange-500' : 'text-emerald-500',
      bg: openHigh > 0 ? 'from-orange-500/8 to-orange-500/3' : 'from-emerald-500/8 to-emerald-500/3',
      border: openHigh > 0 ? 'border-orange-500/15' : 'border-emerald-500/15',
      iconBg: openHigh > 0 ? 'bg-orange-500/10' : 'bg-emerald-500/10',
      glow: openHigh > 0 ? 'glow-orange' : '',
      subLabel: openHigh === 0 ? 'All resolved' : `${openHigh} remaining`,
      ring: openHigh > 0 ? 'ring-orange-500/5' : 'ring-emerald-500/5',
    },
    {
      label: 'Fix Rate',
      value: fixRate,
      icon: CheckCircle2,
      color: fixRate === 100 ? 'text-emerald-500' : 'text-amber-500',
      bg: fixRate === 100 ? 'from-emerald-500/8 to-emerald-500/3' : 'from-amber-500/8 to-amber-500/3',
      border: fixRate === 100 ? 'border-emerald-500/15' : 'border-amber-500/15',
      iconBg: fixRate === 100 ? 'bg-emerald-500/10' : 'bg-amber-500/10',
      glow: '',
      subLabel: `${resolved}/${total} bugs fixed`,
      ring: fixRate === 100 ? 'ring-emerald-500/5' : '',
    },
    {
      label: 'Risk Score',
      value: animRisk,
      icon: Zap,
      color: 'text-emerald-600 dark:text-emerald-400',
      bg: 'from-emerald-500/5 to-transparent',
      border: 'border-emerald-500/20',
      iconBg: 'bg-emerald-500/10',
      glow: '',
      subLabel: 'Low — all bugs resolved',
      ring: '',
    },
    {
      label: 'Missing v2.10',
      value: animMissing,
      icon: FileCode2,
      color: 'text-gray-700 dark:text-zinc-300',
      bg: 'from-gray-500/5 to-gray-500/2 dark:from-zinc-500/8 dark:to-zinc-500/3',
      border: 'border-gray-500/10 dark:border-zinc-500/15',
      iconBg: 'bg-gray-500/8 dark:bg-zinc-500/12',
      glow: '',
      subLabel: 'Unimplemented features',
      ring: '',
    },
  ]

  return (
    <motion.div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4" {...stagger}>
      {cards.map((card, i) => (
        <motion.div
          key={card.label}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.07, duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] }}
          className={`
            rounded-2xl border glass-card glass-card-animated ripple-effect
            ${compact ? 'p-3' : 'p-4 sm:p-5'}
            ${card.border} ${card.glow} ${card.ring} ring-1
            hover:shadow-lg hover:-translate-y-0.5
            transition-all duration-300 ease-out
            relative overflow-hidden
          `}
        >
          {/* Subtle gradient overlay */}
          <div className={`absolute inset-0 bg-gradient-to-br ${card.bg} pointer-events-none rounded-2xl`} />

          <div className={`relative z-10`}>
            <div className={`flex items-center justify-between ${compact ? 'mb-1.5' : 'mb-3'}`}>
              <span className="text-[10px] sm:text-xs font-semibold uppercase tracking-wider text-gray-400 dark:text-zinc-500">{card.label}</span>
              <div className={`size-8 rounded-xl ${card.iconBg} flex items-center justify-center transition-transform duration-300 group-hover:scale-110`}>
                <card.icon className={`size-4 ${card.color}`} />
              </div>
            </div>
            <div className={`tabular-nums text-gray-900 dark:text-zinc-100 font-extrabold tracking-tight ${compact ? 'text-2xl sm:text-3xl' : 'text-3xl sm:text-4xl'}`}>
              {card.value}{card.label === 'Fix Rate' ? '%' : ''}
            </div>
            {!compact && card.subLabel && (
              <div className="flex items-center gap-1 mt-2">
                {card.changeIcon && <card.changeIcon className={`size-3 ${card.changeColor}`} />}
                <p className={`text-[11px] ${card.changeColor || 'text-gray-400 dark:text-zinc-500'} truncate`} style={card.changeColor ? {} : {}}>
                  {card.subLabel}
                </p>
              </div>
            )}
          </div>
        </motion.div>
      ))}
    </motion.div>
  )
}