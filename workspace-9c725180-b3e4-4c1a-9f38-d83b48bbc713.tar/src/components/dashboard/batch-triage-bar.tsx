'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { CircleDot, Eye, Zap, CheckCircle, X, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useDashboardData } from './data-context'
import type { TriageStatus } from './types'

const batchActions: { status: TriageStatus; icon: typeof CircleDot; label: string; color: string }[] = [
  { status: 'acknowledged', icon: Eye, label: 'Acknowledge', color: 'text-amber-600 dark:text-amber-400' },
  { status: 'in-progress', icon: Zap, label: 'In Progress', color: 'text-orange-600 dark:text-orange-400' },
  { status: 'resolved', icon: CheckCircle, label: 'Resolve', color: 'text-emerald-600 dark:text-emerald-400' },
]

export function BatchTriageBar() {
  const { selectedBugs, setSelectedBugs, batchLoading, batchTriage } = useDashboardData()
  const count = selectedBugs.size

  return (
    <AnimatePresence>
      {count > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.95 }}
          transition={{ type: 'spring', stiffness: 400, damping: 25 }}
          className="fixed bottom-20 md:bottom-8 left-1/2 -translate-x-1/2 z-20 glass border border-gray-200/60 dark:border-zinc-700/40 rounded-2xl px-4 py-3 flex items-center gap-3 shadow-xl shadow-black/5 dark:shadow-black/20"
        >
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="h-6 px-2 text-xs font-bold tabular-nums">{count}</Badge>
            <span className="text-xs text-gray-600 dark:text-zinc-400">selected</span>
          </div>
          <div className="w-px h-6 bg-gray-200 dark:bg-zinc-700" />
          <div className="flex items-center gap-2">
            {batchActions.map((a) => (
              <Button
                key={a.status}
                size="sm"
                variant="outline"
                className="h-8 gap-1.5 text-xs rounded-xl"
                disabled={batchLoading}
                onClick={() => batchTriage(a.status)}
              >
                {batchLoading ? <Loader2 className="size-3 animate-spin" /> : <a.icon className={`size-3 ${a.color}`} />}
                <span className={a.color}>{a.label}</span>
              </Button>
            ))}
          </div>
          <div className="w-px h-6 bg-gray-200 dark:bg-zinc-700" />
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8"
            onClick={() => setSelectedBugs(new Set())}
          >
            <X className="size-3.5" />
          </Button>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
