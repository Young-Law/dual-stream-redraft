'use client'

import { useCallback, useMemo } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Filter, ArrowUpDown, FileCode2, X, Search, Eye } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Checkbox } from '@/components/ui/checkbox'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { useDashboardData } from './data-context'
import { BatchTriageBar } from './batch-triage-bar'
import { fadeIn, SEV_BG, TRIAGE_CONFIG, SEV_ORDER } from './types'
import type { TriageStatus } from './types'

const SEVERITY_OPTIONS = ['all', 'critical', 'high', 'medium', 'low']
const TRIAGE_OPTIONS: (TriageStatus | 'all')[] = ['all', 'none', 'acknowledged', 'in-progress', 'resolved']
const TRIAGE_LABELS: Record<string, string> = {
  all: 'All Triage',
  none: 'Untriaged',
  acknowledged: 'Acknowledged',
  'in-progress': 'In Progress',
  resolved: 'Resolved',
}

export function AllBugsTab() {
  const {
    filteredBugs, severityFilter, setSeverityFilter, triageFilter, setTriageFilter,
    search, setSearch, sortField, handleSort, sortAsc, fileFilter, clearFileFilter,
    toggleBugSelection, selectedBugs, setSelectedBugs, openBug, triageState, setBugTriage, isMobile,
    settings,
  } = useDashboardData()

  const allSelected = filteredBugs.length > 0 && filteredBugs.every(b => selectedBugs.has(b.id))

  const handleSelectAll = useCallback(() => {
    if (allSelected) {
      setSelectedBugs(new Set())
    } else {
      setSelectedBugs(new Set(filteredBugs.map(b => b.id)))
    }
  }, [allSelected, filteredBugs, setSelectedBugs])

  const sortLabel = useMemo(() => {
    if (sortField === 'severity') return `Severity ${sortAsc ? '↑' : '↓'}`
    if (sortField === 'category') return `Category ${sortAsc ? '↑' : '↓'}`
    return `ID ${sortAsc ? '↑' : '↓'}`
  }, [sortField, sortAsc])

  return (
    <AnimatePresence mode="wait">
      <motion.div key="all-bugs" {...fadeIn} className="space-y-4">
        {/* File filter indicator */}
        {fileFilter && (
          <div className="flex items-center gap-2 bg-orange-50 dark:bg-orange-500/10 border border-orange-200 dark:border-orange-500/20 rounded-xl px-3 py-2">
            <FileCode2 className="size-3.5 text-orange-500" />
            <span className="text-xs text-orange-700 dark:text-orange-400 font-mono">{fileFilter}</span>
            <Button size="icon" variant="ghost" className="h-5 w-5 ml-auto" onClick={clearFileFilter}>
              <X className="size-3" />
            </Button>
          </div>
        )}

        {/* Severity filter buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <Filter className="size-4 text-gray-400" />
          {SEVERITY_OPTIONS.map(s => (
            <Button key={s} size="sm" variant={severityFilter === s ? 'default' : 'outline'} className="h-7 text-xs rounded-lg capitalize" onClick={() => setSeverityFilter(s)}>
              {s}
            </Button>
          ))}
          <div className="w-px h-5 bg-gray-200 dark:bg-zinc-700" />

          {/* Triage filter dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="sm" variant="outline" className="h-7 text-xs rounded-lg">
                <Filter className="size-3 mr-1" />
                {TRIAGE_LABELS[triageFilter] || 'All Triage'}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              {TRIAGE_OPTIONS.map(t => (
                <DropdownMenuItem key={t} className="text-xs" onClick={() => setTriageFilter(t)}>
                  {TRIAGE_LABELS[t]}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <div className="w-px h-5 bg-gray-200 dark:bg-zinc-700" />

          {/* Sort controls */}
          <Button size="sm" variant="outline" className="h-7 text-xs rounded-lg" onClick={() => handleSort('severity')}>
            <ArrowUpDown className="size-3 mr-1" />
            {sortLabel}
          </Button>
          <Button size="sm" variant={sortField === 'category' ? 'default' : 'outline'} className="h-7 text-xs rounded-lg" onClick={() => handleSort('category')}>
            Category
          </Button>
          <Button size="sm" variant={sortField === 'id' ? 'default' : 'outline'} className="h-7 text-xs rounded-lg" onClick={() => handleSort('id')}>
            ID
          </Button>
        </div>

        {/* Table */}
        <Card className="glass-card rounded-2xl overflow-hidden">
          <div className="max-h-[600px] overflow-y-auto custom-scrollbar">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50/50 dark:bg-zinc-800/30 hover:bg-gray-50/50 dark:hover:bg-zinc-800/30">
                  <TableHead className="w-10">
                    <Checkbox checked={allSelected} onCheckedChange={handleSelectAll} />
                  </TableHead>
                  <TableHead className="text-xs cursor-pointer select-none" onClick={() => handleSort('severity')}>
                    <div className="flex items-center gap-1">Severity <ArrowUpDown className="size-3" /></div>
                  </TableHead>
                  <TableHead className="text-xs cursor-pointer select-none" onClick={() => handleSort('id')}>
                    <div className="flex items-center gap-1">ID <ArrowUpDown className="size-3" /></div>
                  </TableHead>
                  <TableHead className="text-xs">Title</TableHead>
                  <TableHead className="text-xs cursor-pointer select-none hidden md:table-cell" onClick={() => handleSort('category')}>
                    <div className="flex items-center gap-1">Category <ArrowUpDown className="size-3" /></div>
                  </TableHead>
                  <TableHead className="text-xs hidden lg:table-cell">File</TableHead>
                  <TableHead className="text-xs">Triage</TableHead>
                  <TableHead className="text-xs w-10" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredBugs.map(bug => {
                  const tStatus = triageState[bug.id] || 'none'
                  const tCfg = TRIAGE_CONFIG[tStatus]
                  const checked = selectedBugs.has(bug.id)
                  return (
                    <TableRow
                      key={bug.id}
                      className={`cursor-pointer hover:bg-gray-50/50 dark:hover:bg-zinc-800/20 ${checked ? 'bg-orange-50/80 dark:bg-orange-500/5' : ''}`}
                      onClick={() => openBug(bug)}
                    >
                      <TableCell onClick={e => { e.stopPropagation(); toggleBugSelection(bug.id) }}>
                        <Checkbox checked={checked} onCheckedChange={() => toggleBugSelection(bug.id)} />
                      </TableCell>
                      <TableCell>
                        <Badge className={`text-[10px] border ${SEV_BG[bug.severity]}`} variant="outline">{bug.severity}</Badge>
                      </TableCell>
                      <TableCell className="text-xs font-mono text-gray-500 dark:text-zinc-400">{bug.id}</TableCell>
                      <TableCell className="text-xs font-medium text-gray-900 dark:text-zinc-100 max-w-[200px] truncate">{bug.title}</TableCell>
                      <TableCell className="text-xs text-gray-500 dark:text-zinc-400 hidden md:table-cell">{bug.category}</TableCell>
                      <TableCell className="text-xs font-mono text-gray-500 dark:text-zinc-400 hidden lg:table-cell max-w-[150px] truncate">{bug.file}</TableCell>
                      <TableCell onClick={e => e.stopPropagation()}>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <button className={`flex items-center gap-1 text-[10px] px-2 py-1 rounded-lg border ${tCfg.bg} ${tCfg.border} ${tCfg.color} transition-colors`}>
                              <tCfg.icon className="size-3" />{tCfg.label}
                            </button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent>
                            {(Object.entries(TRIAGE_CONFIG) as [TriageStatus, typeof TRIAGE_CONFIG.none][]).map(([k, cfg]) => (
                              <DropdownMenuItem key={k} className="text-xs gap-2" onClick={() => setBugTriage(bug.id, k)}>
                                <cfg.icon className={`size-3 ${cfg.color}`} />{cfg.label}
                              </DropdownMenuItem>
                            ))}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                      <TableCell>
                        <button
                          onClick={e => { e.stopPropagation(); openBug(bug) }}
                          className="p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors"
                          aria-label="View bug details"
                        >
                          <Eye className="size-3.5 text-gray-400" />
                        </button>
                      </TableCell>
                    </TableRow>
                  )
                })}
                {filteredBugs.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-sm text-gray-400">No bugs match filters</TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </Card>

        {/* BatchTriageBar shows globally when bugs are selected */}
      </motion.div>
    </AnimatePresence>
  )
}