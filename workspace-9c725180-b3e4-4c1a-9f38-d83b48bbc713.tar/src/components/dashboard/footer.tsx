'use client'

import { motion } from 'framer-motion'
import { Clock, Shield, FileCode2, GitBranch, Activity, Layers } from 'lucide-react'
import { Separator } from '@/components/ui/separator'
import { useDashboardData } from './data-context'
import { riskLabel } from './hooks'

export function DashboardFooter() {
  const { conformancePct, bugs, specViolations, missingFeatures, testGaps, summary, rs, rl } = useDashboardData()

  const totalFiles = new Set([
    ...bugs.map(b => b.file),
    ...specViolations.map(v => v.section),
  ]).size

  const totalItems = bugs.length + specViolations.length + missingFeatures.length + testGaps.length

  return (
    <footer className="mt-auto glass border-t border-white/10 dark:border-white/5 px-4 sm:px-6 lg:px-8 py-3.5 relative z-10 card-depth-1">
      <div className="max-w-7xl mx-auto">
        {/* Top row: key stats */}
        <div className="flex items-center justify-between flex-wrap gap-y-2 gap-x-4">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-1.5">
              <GitBranch className="size-3 text-gray-400 dark:text-zinc-500" />
              <span className="text-[11px] text-gray-400 dark:text-zinc-500">
                <span className="font-mono font-semibold text-gray-500 dark:text-zinc-400">dual-stream-redraft-main</span>
              </span>
            </div>
            <Separator orientation="vertical" className="h-3" />
            <div className="flex items-center gap-1.5 text-[11px] text-gray-400 dark:text-zinc-500">
              <FileCode2 className="size-2.5" />
              <span className="tabular-nums font-medium">{totalFiles}+</span> files
            </div>
            <Separator orientation="vertical" className="h-3 hidden sm:block" />
            <div className="flex items-center gap-1.5 text-[11px] text-gray-400 dark:text-zinc-500 hidden sm:flex">
              <Layers className="size-2.5" />
              <span className="tabular-nums font-medium">{totalItems}</span> findings
            </div>
            <Separator orientation="vertical" className="h-3 hidden sm:block" />
            <div className="flex items-center gap-1.5 text-[11px] text-gray-400 dark:text-zinc-500 hidden sm:flex">
              <Activity className="size-2.5" />
              <span>Risk: <span className={`font-bold tabular-nums ${rl.color}`}>{rs}</span> ({rl.label})</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-zinc-400">
              <span className="font-medium text-gray-600 dark:text-zinc-300">Conformance</span>
              <span className="font-extrabold tabular-nums text-emerald-500 text-sm">{conformancePct}%</span>
              <div className="w-20 h-2 rounded-full bg-gray-200 dark:bg-zinc-700/80 overflow-hidden">
                <motion.div
                  className="h-full rounded-full bg-gradient-to-r from-emerald-500 via-emerald-400 to-teal-400"
                  initial={{ width: 0 }}
                  animate={{ width: `${conformancePct}%` }}
                  transition={{ delay: 1, duration: 1.2, ease: 'easeOut' }}
                />
              </div>
            </div>
            <Separator orientation="vertical" className="h-3" />
            <div className="flex items-center gap-1.5 text-[11px] text-gray-400 dark:text-zinc-500">
              <Shield className="size-2.5" />
              <span className="font-semibold">DSA v2.10</span>
            </div>
          </div>
        </div>

        {/* Bottom row: timestamp and analysis info */}
        <div className="mt-2 pt-2 border-t border-gray-100 dark:border-zinc-800/60 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-[10px] text-gray-400 dark:text-zinc-600">
            <Clock className="size-2.5" />
            <span>Analysis: Sep 15, 2025</span>
            <span className="mx-1.5">·</span>
            <span>{bugs.length} bugs · {specViolations.length} violations · {missingFeatures.length} missing · {testGaps.length} gaps</span>
          </div>
          <p className="text-[10px] text-gray-300 dark:text-zinc-700 hidden sm:block">
            Powered by automated code review
          </p>
        </div>
      </div>
    </footer>
  )
}
