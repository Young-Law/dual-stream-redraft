'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Filter, X, ChevronDown, ChevronUp, Tag, GitBranch, MessageSquare } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { useDashboardData } from './data-context'
import { SEV_BG } from './types'
import type { TriageStatus } from './types'

export function QuickFilters() {
  const {
    severityFilter, setSeverityFilter, triageFilter, setTriageFilter,
    search, setSearch, bugs, isMobile, fileFilter, clearFileFilter,
  } = useDashboardData()
  const [expanded, setExpanded] = useState(false)

  const categories = ['all', 'source', 'test']
  const severities = ['all', 'critical', 'high', 'medium', 'low']
  const triages: Array<TriageStatus | 'all'> = ['all', 'none', 'acknowledged', 'in-progress', 'resolved']
  const triageLabels: Record<string, string> = {
    all: 'All Triage', none: 'Untriaged', acknowledged: 'Acknowledged', 'in-progress': 'In Progress', resolved: 'Resolved',
  }
  const categoryLabels: Record<string, string> = {
    all: 'All Types', source: 'Source', test: 'Test',
  }

  const hasActiveFilters = severityFilter !== 'all' || triageFilter !== 'all' || fileFilter !== ''

  return (
    <div className="glass-card rounded-2xl overflow-hidden">
      {/* Toggle header */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full px-4 py-2.5 flex items-center justify-between hover:bg-white/30 dark:hover:bg-zinc-800/30 transition-colors"
      >
        <div className="flex items-center gap-2">
          <Filter className="size-3.5 text-gray-500 dark:text-zinc-400" />
          <span className="text-xs font-semibold text-gray-700 dark:text-zinc-300">Quick Filters</span>
          {hasActiveFilters && (
            <span className="size-1.5 rounded-full bg-orange-500 animate-subtle-pulse" />
          )}
        </div>
        <div className="flex items-center gap-2">
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              className="h-5 text-[10px] px-1.5 text-gray-500"
              onClick={(e) => { e.stopPropagation(); setSeverityFilter('all'); setTriageFilter('all'); clearFileFilter(); setSearch('') }}
            >
              <X className="size-2.5 mr-0.5" /> Clear all
            </Button>
          )}
          {expanded ? <ChevronUp className="size-3.5 text-gray-400" /> : <ChevronDown className="size-3.5 text-gray-400" />}
        </div>
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-3 space-y-3">
              {/* Severity filters */}
              <div>
                <p className="text-[10px] font-semibold text-gray-400 dark:text-zinc-500 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <Tag className="size-2.5" /> Severity
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {severities.map(sev => (
                    <button
                      key={sev}
                      onClick={() => setSeverityFilter(sev)}
                      className={`
                        text-[10px] font-medium px-2.5 py-1 rounded-lg border transition-all duration-150 active:scale-95
                        ${sev === 'all'
                          ? severityFilter === 'all'
                            ? 'bg-gray-900 dark:bg-zinc-100 text-white dark:text-zinc-900 border-gray-900 dark:border-zinc-100'
                            : 'bg-white dark:bg-zinc-800 text-gray-600 dark:text-zinc-400 border-gray-200 dark:border-zinc-700 hover:border-gray-300 dark:hover:border-zinc-600'
                          : severityFilter === sev
                            ? `${SEV_BG[sev]} border`
                            : `bg-white dark:bg-zinc-800 text-gray-600 dark:text-zinc-400 border-gray-200 dark:border-zinc-700 hover:border-gray-300 dark:hover:border-zinc-600`
                        }
                      `}
                    >
                      {sev === 'all' ? 'All' : sev.charAt(0).toUpperCase() + sev.slice(1)}
                    </button>
                  ))}
                </div>
              </div>

              {/* Triage filters */}
              <div>
                <p className="text-[10px] font-semibold text-gray-400 dark:text-zinc-500 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <MessageSquare className="size-2.5" /> Triage Status
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {triages.map(tr => (
                    <button
                      key={tr}
                      onClick={() => setTriageFilter(tr)}
                      className={`
                        text-[10px] font-medium px-2.5 py-1 rounded-lg border transition-all duration-150 active:scale-95
                        ${triageFilter === tr
                          ? 'bg-gray-900 dark:bg-zinc-100 text-white dark:text-zinc-900 border-gray-900 dark:border-zinc-100'
                          : 'bg-white dark:bg-zinc-800 text-gray-600 dark:text-zinc-400 border-gray-200 dark:border-zinc-700 hover:border-gray-300 dark:hover:border-zinc-600'
                        }
                      `}
                    >
                      {triageLabels[tr]}
                    </button>
                  ))}
                </div>
              </div>

              {/* File filter indicator */}
              {fileFilter && (
                <div className="flex items-center gap-2">
                  <GitBranch className="size-3 text-orange-500" />
                  <span className="text-[10px] font-mono text-gray-600 dark:text-zinc-400 truncate flex-1">{fileFilter}</span>
                  <button
                    onClick={clearFileFilter}
                    className="text-[10px] text-gray-400 hover:text-red-500 transition-colors active:scale-95"
                  >
                    <X className="size-3" />
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
