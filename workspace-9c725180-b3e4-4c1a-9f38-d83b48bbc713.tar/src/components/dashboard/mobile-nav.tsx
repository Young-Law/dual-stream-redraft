'use client'

import { motion, AnimatePresence, useSpring, useTransform } from 'framer-motion'
import { LayoutGrid, AlertOctagon, AlertTriangle, FileText, Sparkles, ChevronUp, Download, FileBarChart, Copy, FileWarning, XCircle, TestTube2, CheckCircle, Grid3x3, TrendingUp, History } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuLabel } from '@/components/ui/dropdown-menu'
import { useDashboardData } from './data-context'

export function MobileNav() {
  const { activeTab, setActiveTab, fabOpen, setFabOpen, bugs, specViolations, missingFeatures, testGaps, summary, copied, setCopied } = useDashboardData()

  const fabRotation = useSpring(0, { stiffness: 300, damping: 20 })
  const fabScale = useSpring(1, { stiffness: 400, damping: 25 })

  const handleFabToggle = () => {
    const next = !fabOpen
    setFabOpen(next)
    fabRotation.set(next ? 45 : 0)
    fabScale.set(next ? 1.05 : 1)
  }

  const primaryTabs = [
    { v: 'overview', icon: LayoutGrid, label: 'Overview' },
    { v: 'executive', icon: FileText, label: 'Executive' },
    { v: 'critical-bugs', icon: AlertOctagon, label: 'Critical' },
    { v: 'all-bugs', icon: AlertTriangle, label: 'All Bugs' },
    { v: 'spec-violations', icon: FileWarning, label: 'Spec' },
  ]

  const moreTabs = [
    { v: 'missing-features', icon: XCircle, label: 'Missing', count: missingFeatures.length },
    { v: 'test-gaps', icon: TestTube2, label: 'Tests', count: testGaps.length },
    { v: 'architecture', icon: CheckCircle, label: 'Architecture', count: null },
    { v: 'risk-matrix', icon: Grid3x3, label: 'Risk Matrix', count: null },
    { v: 'trends', icon: TrendingUp, label: 'Trends', count: null },
    { v: 'activity', icon: History, label: 'Activity', count: null },
  ]

  const handleExport = async (format: 'json' | 'csv') => {
    const resp = await fetch(`/api/review/export?format=${format}`)
    const blob = await resp.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = `dsa-v210-review.${format}`; a.click()
    URL.revokeObjectURL(url)
  }

  const handleCopyReport = async () => {
    const text = `DSA v2.10 Review Summary\nTotal: ${summary?.total_findings} | Critical: ${summary?.critical} | High: ${summary?.high} | Medium: ${summary?.medium} | Low: ${summary?.low}\nConformance: ${summary?.spec_conformance_pct}% | Missing Features: ${summary?.missing_features}`
    await navigator.clipboard.writeText(text)
    setCopied(true); setTimeout(() => setCopied(false), 2000)
  }

  return (
    <>
      {/* Bottom tab bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-30 glass border-t border-white/10 dark:border-white/5 pb-safe">
        <div className="flex items-center justify-around py-2 px-1">
          {primaryTabs.map(t => {
            const isActive = activeTab === t.v
            return (
              <button
                key={t.v}
                onClick={() => setActiveTab(t.v)}
                className={`relative flex flex-col items-center gap-0.5 px-2.5 py-1.5 rounded-xl transition-all duration-200 active:scale-90 ${
                  isActive ? 'text-orange-500' : 'text-gray-400 dark:text-zinc-500'
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="mobile-tab-indicator"
                    className="absolute inset-0 rounded-xl bg-gradient-to-t from-orange-500/15 to-orange-500/5"
                    transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                  />
                )}
                <t.icon className="size-4 relative z-10" />
                <span className="text-[10px] font-medium relative z-10">{t.label}</span>
              </button>
            )
          })}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex flex-col items-center gap-0.5 px-2.5 py-1.5 rounded-xl text-gray-400 dark:text-zinc-500 active:scale-90">
                <Sparkles className="size-4" />
                <span className="text-[10px] font-medium">More</span>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuLabel className="text-xs">More Tabs</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {moreTabs.map(t => (
                <DropdownMenuItem
                  key={t.v}
                  className="text-xs gap-2"
                  onClick={() => setActiveTab(t.v)}
                >
                  <t.icon className="size-3.5" />{t.label}
                  {t.count !== null && (
                    <Badge variant="secondary" className="ml-auto text-[9px] h-4 min-w-4 px-1">{t.count}</Badge>
                  )}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Floating Action Button */}
      <div className="md:hidden fixed bottom-20 right-4 z-30">
        <AnimatePresence>
          {fabOpen && (
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.8 }}
              transition={{ type: 'spring', stiffness: 350, damping: 22 }}
              className="absolute bottom-14 right-0 flex flex-col gap-2 items-end"
            >
              <Button
                size="sm"
                className="rounded-xl gap-1.5 text-xs shadow-lg"
                onClick={() => { handleCopyReport(); setFabOpen(false) }}
              >
                {copied ? <CheckCircle className="size-3 text-emerald-500" /> : <Copy className="size-3" />}
                Copy
              </Button>
              <Button
                size="sm"
                className="rounded-xl gap-1.5 text-xs shadow-lg"
                onClick={() => { handleExport('csv'); setFabOpen(false) }}
              >
                <FileBarChart className="size-3" /> CSV
              </Button>
              <Button
                size="sm"
                className="rounded-xl gap-1.5 text-xs shadow-lg"
                onClick={() => { handleExport('json'); setFabOpen(false) }}
              >
                <Download className="size-3" /> JSON
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
        <motion.button
          style={{ rotate: fabRotation, scale: fabScale }}
          whileTap={{ scale: 0.9 }}
          onClick={handleFabToggle}
          className="size-12 rounded-full bg-gradient-to-br from-orange-500 to-red-500 shadow-lg shadow-orange-500/30 flex items-center justify-center text-white"
        >
          <ChevronUp className="size-5" />
        </motion.button>
      </div>
    </>
  )
}
