'use client'

import { motion } from 'framer-motion'
import { Skeleton } from '@/components/ui/skeleton'

function AnimatedOrb({ className, delay }: { className: string; delay: number }) {
  return (
    <motion.div
      className={`absolute rounded-full blur-3xl opacity-30 dark:opacity-20 ${className}`}
      animate={{
        x: [0, 30, -20, 0],
        y: [0, -25, 15, 0],
        scale: [1, 1.1, 0.95, 1],
      }}
      transition={{
        duration: 20,
        delay,
        repeat: Infinity,
        ease: 'easeInOut',
      }}
    />
  )
}

export function LoadingState() {
  return (
    <div className="min-h-screen flex flex-col bg-mesh">
      {/* Animated floating orbs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <AnimatedOrb className="w-96 h-96 bg-red-400/30 -top-20 -left-20" delay={0} />
        <AnimatedOrb className="w-80 h-80 bg-orange-400/20 top-1/3 -right-20" delay={3} />
        <AnimatedOrb className="w-72 h-72 bg-amber-400/25 bottom-20 left-1/3" delay={6} />
      </div>

      {/* Skeleton header */}
      <header className="glass border-b border-white/10 dark:border-white/5 px-4 sm:px-6 lg:px-8 py-5 relative z-10 card-depth-2">
        <div className="max-w-7xl mx-auto flex items-center gap-3">
          <Skeleton className="h-10 w-10 rounded-xl" />
          <div className="space-y-2 flex-1">
            <Skeleton className="h-6 w-64 shimmer" />
            <Skeleton className="h-3 w-40 shimmer" />
          </div>
          <div className="flex gap-2">
            <Skeleton className="h-8 w-8 rounded-lg" />
            <Skeleton className="h-8 w-8 rounded-lg" />
            <Skeleton className="h-8 w-8 rounded-lg" />
          </div>
        </div>
        {/* Triage stats bar skeleton */}
        <div className="max-w-7xl mx-auto mt-3 flex gap-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-7 w-28 rounded-lg shimmer" />
          ))}
        </div>
      </header>

      {/* Skeleton content */}
      <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 space-y-5 relative z-10">
        {/* Skeleton cards */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
          {Array.from({ length: 5 }).map((_, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.07, duration: 0.4 }}
            >
              <Skeleton className="h-36 sm:h-40 rounded-2xl shimmer" />
            </motion.div>
          ))}
        </div>

        {/* Skeleton search + health row */}
        <div className="flex gap-3">
          <Skeleton className="h-11 flex-1 max-w-3xl rounded-2xl shimmer" />
          <Skeleton className="h-11 w-64 rounded-2xl shimmer hidden sm:block" />
        </div>

        {/* Skeleton quick filters */}
        <Skeleton className="h-10 w-full rounded-2xl shimmer" />

        {/* Skeleton tab bar */}
        <div className="flex gap-1.5">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-9 w-20 rounded-xl shimmer" />
          ))}
        </div>

        {/* Skeleton content area */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Skeleton className="h-64 rounded-2xl shimmer" />
          <Skeleton className="h-64 rounded-2xl shimmer" />
          <Skeleton className="h-64 rounded-2xl shimmer" />
        </div>
        <Skeleton className="h-[500px] rounded-2xl shimmer" />
      </main>

      {/* Skeleton footer */}
      <footer className="mt-auto glass border-t border-white/10 dark:border-white/5 px-4 sm:px-6 lg:px-8 py-3 relative z-10">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Skeleton className="h-4 w-48 shimmer" />
          <Skeleton className="h-4 w-32 shimmer" />
        </div>
      </footer>
    </div>
  )
}
