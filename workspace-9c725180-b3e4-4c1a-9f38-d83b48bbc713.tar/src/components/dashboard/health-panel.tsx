'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { Activity, RefreshCw, Wifi, WifiOff, Clock, X } from 'lucide-react'
import { useDashboardData } from './data-context'
import {
  Tooltip,
  TooltipTrigger,
  TooltipContent,
} from '@/components/ui/tooltip'

type EndpointLatency = {
  url: string
  label: string
  latency: number
  ok: boolean
}

const API_ENDPOINTS: { url: string; label: string }[] = [
  { url: '/api/review/summary', label: 'Summary' },
  { url: '/api/review/bugs', label: 'Bugs' },
  { url: '/api/review/spec-violations', label: 'Spec Violations' },
  { url: '/api/review/missing-features', label: 'Missing Features' },
  { url: '/api/review/test-gaps', label: 'Test Gaps' },
  { url: '/api/review/file-heatmap', label: 'File Heatmap' },
  { url: '/api/review/conformance-timeline', label: 'Conformance' },
  { url: '/api/review/trends', label: 'Trends' },
  { url: '/api/review/activity', label: 'Activity' },
  { url: '/api/review/executive', label: 'Executive' },
]

const DISMISS_KEY = 'dsa-health-panel-dismissed'
const HEALTHY_THRESHOLD = 2000

function timeAgo(date: Date): string {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000)
  if (seconds < 5) return 'just now'
  if (seconds < 60) return `${seconds}s ago`
  const minutes = Math.floor(seconds / 60)
  if (minutes < 60) return `${minutes}m ago`
  const hours = Math.floor(minutes / 60)
  return `${hours}h ago`
}

export function HealthPanel() {
  const { loading, error, refetch, settings } = useDashboardData()
  const [dismissed, setDismissed] = useState(false)
  const [latencies, setLatencies] = useState<EndpointLatency[]>([])
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null)
  const [refreshing, setRefreshing] = useState(false)
  const [, setTick] = useState(0)
  const mountedRef = useRef(false)

  // Check dismissed preference
  useEffect(() => {
    try {
      if (localStorage.getItem(DISMISS_KEY) === 'true') {
        setDismissed(true)
      }
    } catch {
      // localStorage not available
    }
  }, [])

  // Tick every 10s to update relative time
  useEffect(() => {
    const interval = setInterval(() => setTick(t => t + 1), 10000)
    return () => clearInterval(interval)
  }, [])

  const measureEndpoints = useCallback(async () => {
    const results = await Promise.all(
      API_ENDPOINTS.map(async (ep) => {
        const start = performance.now()
        try {
          const res = await fetch(ep.url)
          const latency = Math.round(performance.now() - start)
          return { url: ep.url, label: ep.label, latency, ok: res.ok } as EndpointLatency
        } catch {
          const latency = Math.round(performance.now() - start)
          return { url: ep.url, label: ep.label, latency, ok: false } as EndpointLatency
        }
      })
    )
    return results
  }, [])

  // Measure on mount
  useEffect(() => {
    if (mountedRef.current) return
    mountedRef.current = true
    measureEndpoints().then((results) => {
      setLatencies(results)
      setLastRefresh(new Date())
    })
  }, [measureEndpoints])

  // Refresh handler
  const handleRefresh = useCallback(async () => {
    setRefreshing(true)
    try {
      await refetch()
      const results = await measureEndpoints()
      setLatencies(results)
      setLastRefresh(new Date())
    } finally {
      setRefreshing(false)
    }
  }, [refetch, measureEndpoints])

  const handleDismiss = useCallback(() => {
    setDismissed(true)
    try {
      localStorage.setItem(DISMISS_KEY, 'true')
    } catch {
      // localStorage not available
    }
  }, [])

  if (dismissed) return null

  const healthyCount = latencies.filter((e) => e.ok && e.latency < HEALTHY_THRESHOLD).length
  const unhealthyCount = latencies.length - healthyCount
  const avgLatency =
    latencies.length > 0
      ? Math.round(latencies.reduce((sum, e) => sum + e.latency, 0) / latencies.length)
      : 0

  const isHealthy = !error && unhealthyCount === 0
  const isStale = lastRefresh && Date.now() - lastRefresh.getTime() > 120000
  const isFresh = lastRefresh && !isStale && !error

  return (
    <div className="glass-card rounded-xl px-4 py-2 flex items-center gap-3 text-sm animate-in fade-in-0 slide-in-from-top-1 duration-300">
      {/* Status dot */}
      <div className="flex items-center gap-1.5">
        {error ? (
          <WifiOff className="h-3.5 w-3.5 text-red-500 dark:text-red-400" />
        ) : (
          <Wifi className="h-3.5 w-3.5 text-emerald-500 dark:text-emerald-400" />
        )}
        <span className="relative flex h-2 w-2">
          <span
            className={`
              inline-flex h-2 w-2 rounded-full
              ${
                error
                  ? 'bg-red-500 dark:bg-red-400'
                  : isStale
                    ? 'bg-amber-500 dark:bg-amber-400'
                    : 'bg-emerald-500 dark:bg-emerald-400'
              }
              ${isFresh ? 'animate-pulse' : ''}
            `}
          />
          {isFresh && (
            <span
              className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 dark:bg-emerald-500 opacity-75 animate-ping"
              aria-hidden="true"
            />
          )}
        </span>
        <span className="text-xs text-gray-500 dark:text-zinc-400 font-medium">
          {error ? 'Error' : isStale ? 'Stale' : 'Healthy'}
        </span>
      </div>

      {/* Separator */}
      <div className="h-3.5 w-px bg-gray-200 dark:bg-zinc-700" />

      {/* Last refresh */}
      <div className="flex items-center gap-1 text-xs text-gray-500 dark:text-zinc-400">
        <Clock className="h-3 w-3" />
        <span>{lastRefresh ? timeAgo(lastRefresh) : '—'}</span>
      </div>

      {/* Separator */}
      <div className="h-3.5 w-px bg-gray-200 dark:bg-zinc-700" />

      {/* Average latency tooltip with per-endpoint breakdown */}
      <Tooltip>
        <TooltipTrigger asChild>
          <button className="flex items-center gap-1 text-xs text-gray-500 dark:text-zinc-400 hover:text-gray-700 dark:hover:text-zinc-200 transition-colors cursor-default">
            <Activity className="h-3 w-3" />
            <span>{avgLatency > 0 ? `Avg ${avgLatency}ms` : '—'}</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-medium">
              {healthyCount}
            </span>
            <span>/</span>
            <span className={unhealthyCount > 0 ? 'text-red-500 dark:text-red-400 font-medium' : 'text-gray-400 dark:text-zinc-500'}>
              {unhealthyCount}
            </span>
          </button>
        </TooltipTrigger>
        <TooltipContent side="bottom" sideOffset={6} className="p-2.5 min-w-[200px]">
          <div className="text-[11px] font-medium mb-1.5 text-primary-foreground/80">
            Endpoint Latencies
          </div>
          <div className="space-y-1">
            {latencies.length === 0 && (
              <div className="text-[11px] text-primary-foreground/50">Measuring…</div>
            )}
            {latencies.map((ep) => (
              <div key={ep.url} className="flex items-center justify-between gap-4 text-[11px]">
                <span className="text-primary-foreground/70 truncate max-w-[110px]">
                  {ep.label}
                </span>
                <span
                  className={`
                    tabular-nums font-medium
                    ${!ep.ok ? 'text-red-300' : ep.latency > HEALTHY_THRESHOLD ? 'text-amber-300' : 'text-emerald-300'}
                  `}
                >
                  {ep.ok ? `${ep.latency}ms` : 'FAIL'}
                </span>
              </div>
            ))}
          </div>
        </TooltipContent>
      </Tooltip>

      {/* Spacer */}
      <div className="flex-1" />

      {/* Refresh button */}
      <button
        onClick={handleRefresh}
        disabled={refreshing || loading}
        className="
          inline-flex items-center gap-1 text-xs font-medium
          text-gray-500 dark:text-zinc-400
          hover:text-gray-700 dark:hover:text-zinc-200
          disabled:opacity-50 disabled:cursor-not-allowed
          transition-colors active:scale-95
          px-2 py-1 rounded-md
          hover:bg-gray-100 dark:hover:bg-zinc-800
        "
        aria-label="Refresh dashboard data"
      >
        <RefreshCw className={`h-3 w-3 ${refreshing ? 'animate-spin' : ''}`} />
        <span className="hidden sm:inline">Refresh Now</span>
      </button>

      {/* Dismiss button */}
      <button
        onClick={handleDismiss}
        className="
          inline-flex items-center justify-center
          text-gray-400 dark:text-zinc-500
          hover:text-gray-600 dark:hover:text-zinc-300
          transition-colors active:scale-95
          p-1 rounded-md
          hover:bg-gray-100 dark:hover:bg-zinc-800
        "
        aria-label="Dismiss health panel"
      >
        <X className="h-3 w-3" />
      </button>
    </div>
  )
}
