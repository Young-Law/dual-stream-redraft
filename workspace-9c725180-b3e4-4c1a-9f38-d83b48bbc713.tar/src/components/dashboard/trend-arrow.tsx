'use client'

import { TrendingUp, TrendingDown, Minus } from 'lucide-react'

export function TrendArrow({ direction, change }: { direction: string; change?: number }) {
  const color = direction === 'up' ? 'text-red-500' : direction === 'down' ? 'text-emerald-500' : 'text-gray-400'
  const Icon = direction === 'up' ? TrendingUp : direction === 'down' ? TrendingDown : Minus
  return (
    <span className={`inline-flex items-center gap-1 ${color}`}>
      <Icon className="size-3.5" />
      {change !== undefined && (
        <span className="text-xs font-semibold tabular-nums">
          {change > 0 ? '+' : ''}{change}
        </span>
      )}
    </span>
  )
}
