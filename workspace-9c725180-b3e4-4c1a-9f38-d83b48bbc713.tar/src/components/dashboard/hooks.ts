'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import type { Summary } from './types'

export function useAnimatedCounter(target: number, duration = 800) {
  const [count, setCount] = useState(0)
  const rafRef = useRef(0)
  useEffect(() => {
    const start = performance.now()
    const step = (now: number) => {
      const progress = Math.min((now - start) / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setCount(Math.round(eased * target))
      if (progress < 1) rafRef.current = requestAnimationFrame(step)
    }
    rafRef.current = requestAnimationFrame(step)
    return () => cancelAnimationFrame(rafRef.current)
  }, [target, duration])
  return count
}

export function useLocalStorage<T>(key: string, initial: T): [T, (v: T | ((prev: T) => T)) => void] {
  const [value, setValue] = useState<T>(() => {
    if (typeof window === 'undefined') return initial
    try {
      const stored = localStorage.getItem(key)
      return stored ? (JSON.parse(stored) as T) : initial
    } catch { return initial }
  })
  const set = useCallback((v: T | ((prev: T) => T)) => {
    setValue(prev => {
      const next = v instanceof Function ? v(prev) : v
      try { localStorage.setItem(key, JSON.stringify(next)) } catch { /* ignore */ }
      return next
    })
  }, [key])
  return [value, set]
}

export function timeAgo(timestamp: string): string {
  const diff = Date.now() - new Date(timestamp).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return 'just now'
  if (mins < 60) return `${mins}m ago`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return `${hrs}h ago`
  const days = Math.floor(hrs / 24)
  return `${days}d ago`
}

// Risk score based on OPEN bugs only
export function riskScore(s: Summary) {
  const oc = (s as Record<string, unknown>).open_critical as number | undefined
  const oh = (s as Record<string, unknown>).open_high as number | undefined
  const om = (s as Record<string, unknown>).open_medium as number | undefined
  const ol = (s as Record<string, unknown>).open_low as number | undefined
  // Use open counts if available, otherwise fall back to total
  const c = oc ?? s.critical
  const h = oh ?? s.high
  const m = om ?? s.medium
  const l = ol ?? s.low
  return Math.round(c * 10 + h * 5 + m * 2 + l * 0.5)
}

export function riskLabel(score: number) {
  if (score >= 80) return { label: 'Critical', color: 'text-red-600 dark:text-red-400', bg: 'bg-red-500/10', border: 'border-red-500/20' }
  if (score >= 50) return { label: 'High', color: 'text-orange-600 dark:text-orange-400', bg: 'bg-orange-500/10', border: 'border-orange-500/20' }
  if (score >= 25) return { label: 'Moderate', color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20' }
  return { label: 'Low', color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20' }
}
