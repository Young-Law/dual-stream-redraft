'use client'

import { motion, AnimatePresence } from 'framer-motion'
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip as RTooltip, ResponsiveContainer,
  AreaChart, Area, CartesianGrid,
} from 'recharts'
import { TrendingUp, CheckCircle2 } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useDashboardData } from './data-context'
import { TrendArrow } from './trend-arrow'
import { fadeIn } from './types'

export function TrendsTab() {
  const { trends, timeline, setSelectedBug, setDrawerOpen } = useDashboardData()
  if (!trends) return null

  return (
    <AnimatePresence mode="wait">
      <motion.div key="trends" {...fadeIn} className="space-y-6">
        {/* Fix Velocity Banner */}
        {trends.fix_velocity && trends.fix_velocity.fix_rate === 100 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-2xl border border-emerald-500/20 bg-gradient-to-r from-emerald-500/10 via-emerald-500/5 to-transparent p-4"
          >
            <div className="flex items-center gap-3">
              <div className="size-10 rounded-xl bg-emerald-500/15 flex items-center justify-center flex-shrink-0">
                <CheckCircle2 className="size-5 text-emerald-600 dark:text-emerald-400" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-emerald-800 dark:text-emerald-300">100% Fix Rate Achieved</h3>
                <p className="text-xs text-emerald-600/80 dark:text-emerald-400/80 mt-0.5">
                  {trends.fix_velocity.total_fixed}/{trends.fix_velocity.total_found} bugs fixed — {trends.fix_velocity.critical_fixed} critical, {trends.fix_velocity.high_fixed} high
                </p>
              </div>
            </div>
          </motion.div>
        )}

        {/* Severity Trend Cards with TrendArrow */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {trends.severity_trend.map(s => (
            <Card key={s.severity} className="glass-card rounded-2xl">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-gray-500 dark:text-zinc-400">{s.severity}</span>
                  <TrendArrow direction={s.direction} change={s.change} />
                </div>
                <div className="mt-2 flex items-baseline gap-2">
                  <span className="text-2xl font-extrabold tabular-nums text-gray-900 dark:text-zinc-100">{s.current}</span>
                  <span className={`text-xs font-medium ${s.direction === 'down' ? 'text-emerald-500' : s.direction === 'up' ? 'text-red-500' : 'text-gray-400'}`}>
                    {s.direction === 'up' ? '+' : ''}{s.change}
                  </span>
                </div>
                <p className="text-[10px] text-gray-400 dark:text-zinc-500 mt-1">
                  {s.current === 0 ? 'All resolved' : `${s.current} remaining`}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Risk Velocity Card */}
        <Card className="glass-card rounded-2xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <TrendingUp className="size-4 text-emerald-500" /> Risk Velocity
            </CardTitle>
            <CardDescription>Risk score change — negative = improving</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div><p className="text-[10px] text-gray-400">Current Score</p><p className="text-lg font-bold tabular-nums text-emerald-600 dark:text-emerald-400">{trends.risk_velocity.current_week}</p></div>
              <div><p className="text-[10px] text-gray-400">Previous Score</p><p className="text-lg font-bold tabular-nums">{trends.risk_velocity.previous_week}</p></div>
              <div><p className="text-[10px] text-gray-400">Velocity</p><p className={`text-lg font-bold tabular-nums ${trends.risk_velocity.velocity > 0 ? 'text-red-500' : 'text-emerald-500'}`}>{trends.risk_velocity.velocity > 0 ? '+' : ''}{trends.risk_velocity.velocity}</p></div>
              <div><p className="text-[10px] text-gray-400">Avg Weekly</p><p className={`text-lg font-bold tabular-nums ${trends.risk_velocity.avg_weekly_change < 0 ? 'text-emerald-500' : 'text-red-500'}`}>{trends.risk_velocity.avg_weekly_change}</p></div>
            </div>
          </CardContent>
        </Card>

        {/* Line Chart: Weekly Findings + Resolved */}
        {trends.weekly_snapshots.length > 0 && (
          <Card className="glass-card rounded-2xl">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Weekly Findings & Resolutions</CardTitle>
              <CardDescription>Bug discovery and resolution progress per week</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={280}>
                <LineChart data={trends.weekly_snapshots}>
                  <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                  <RTooltip />
                  <XAxis dataKey="week" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 10 }} />
                  <Line type="monotone" dataKey="total" stroke="#f97316" strokeWidth={2} dot={{ r: 3, fill: '#f97316' }} name="Total Found" />
                  <Line type="monotone" dataKey="resolved" stroke="#10b981" strokeWidth={2} dot={{ r: 3, fill: '#10b981' }} name="Resolved" />
                  <Line type="monotone" dataKey="critical" stroke="#ef4444" strokeWidth={2} dot={{ r: 3, fill: '#ef4444' }} name="Critical" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Area Chart: Conformance Over Time */}
        {trends.weekly_snapshots.length > 0 && (
          <Card className="glass-card rounded-2xl">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Conformance Over Time</CardTitle>
              <CardDescription>Spec compliance percentage trend</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={240}>
                <AreaChart data={trends.weekly_snapshots}>
                  <defs>
                    <linearGradient id="gradConf" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                  <RTooltip />
                  <XAxis dataKey="week" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 10 }} domain={[0, 100]} />
                  <Area type="monotone" dataKey="conformance" stroke="#10b981" fill="url(#gradConf)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Phase Conformance Progress Bars */}
        {trends.conformance_trend.length > 0 && (
          <Card className="glass-card rounded-2xl">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Phase Conformance</CardTitle>
              <CardDescription>Conformance progress by implementation phase</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {trends.conformance_trend.map((phase, i) => (
                <div key={phase.phase} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-gray-700 dark:text-zinc-300">{phase.phase}</span>
                    <span className="tabular-nums font-bold text-gray-900 dark:text-zinc-100">{phase.current}% <span className="text-gray-400 font-normal">/ {phase.target}%</span></span>
                  </div>
                  <div className="h-2 rounded-full bg-gray-100 dark:bg-zinc-800 overflow-hidden">
                    <motion.div
                      className="h-full rounded-full"
                      style={{ background: phase.color }}
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min((phase.current / phase.target) * 100, 100)}%` }}
                      transition={{ delay: 0.3 + i * 0.1, duration: 0.6 }}
                    />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Category Breakdown Bars */}
        {trends.category_breakdown.length > 0 && (
          <Card className="glass-card rounded-2xl">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Category Breakdown</CardTitle>
              <CardDescription>Bug distribution by category (all resolved)</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={trends.category_breakdown}>
                  <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                  <RTooltip />
                  <XAxis dataKey="category" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 10 }} />
                  <Bar dataKey="critical" stackId="a" fill="#ef4444" radius={[0, 0, 0, 0]} />
                  <Bar dataKey="high" stackId="a" fill="#f97316" />
                  <Bar dataKey="medium" stackId="a" fill="#eab308" />
                  <Bar dataKey="low" stackId="a" fill="#6366f1" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Top Risk Files — now showing resolved status */}
        {trends.top_risk_files && trends.top_risk_files.length > 0 && (
          <Card className="glass-card rounded-2xl">
            <CardHeader>
              <CardTitle className="text-sm flex items-center gap-2">
                Previously Top Risk Files
                <Badge className="bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-500/20 border text-[9px]">All resolved</Badge>
              </CardTitle>
              <CardDescription>Files that had the most bugs — all now fixed</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {trends.top_risk_files.slice(0, 6).map((f, i) => {
                  const isResolved = f.trend === 'resolved' || f.risk === 0
                  return (
                    <motion.div
                      key={f.file}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="rounded-xl border border-emerald-500/15 bg-emerald-500/5 p-3.5 space-y-2.5 text-left"
                    >
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-mono text-gray-900 dark:text-zinc-100 truncate font-medium">{f.file.split('/').pop()}</p>
                        <Badge className="bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-500/20 border text-[9px] shrink-0 ml-2">
                          {isResolved ? '✓ Resolved' : f.trend}
                        </Badge>
                      </div>
                      <p className="text-[10px] font-mono text-gray-400 dark:text-zinc-500 truncate">{f.file}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] text-gray-400">{f.bugs} bug{f.bugs !== 1 ? 's' : ''}</span>
                        {f.fixed != null && <span className="text-[10px] text-emerald-600 dark:text-emerald-400">{f.fixed} fixed</span>}
                      </div>
                    </motion.div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        )}
      </motion.div>
    </AnimatePresence>
  )
}