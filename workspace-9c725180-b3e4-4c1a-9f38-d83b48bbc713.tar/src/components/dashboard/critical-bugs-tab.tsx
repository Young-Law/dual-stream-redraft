'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { AlertTriangle, ChevronDown, ChevronUp, FileCode2, Zap, ExternalLink } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible'
import { useDashboardData } from './data-context'
import { fadeIn, SEV_BG, TRIAGE_CONFIG, PRIORITY_BORDER, stagger } from './types'
import type { TriageStatus } from './types'

export function CriticalBugsTab() {
  const { criticalBugs, expandedCritical, toggleCritical, openBug, triageState, setBugTriage, settings } = useDashboardData()

  return (
    <AnimatePresence mode="wait">
      <motion.div key="critical-bugs" {...fadeIn} className="space-y-4">
        {/* Section header */}
        <div className="flex items-center gap-3">
          <div className="size-9 rounded-xl bg-red-500/10 flex items-center justify-center">
            <AlertTriangle className="size-4.5 text-red-500 animate-subtle-pulse" />
          </div>
          <div>
            <h2 className="text-base font-bold text-gray-900 dark:text-zinc-100">Critical Priority Bugs</h2>
            <p className="text-[11px] text-gray-400 dark:text-zinc-500">Requires immediate attention and resolution</p>
          </div>
          <Badge className="bg-red-500/10 text-red-600 border-red-500/20 border animate-badge-in ml-auto" variant="outline">{criticalBugs.length} critical</Badge>
        </div>

        {criticalBugs.length === 0 ? (
          <Card className="glass-card rounded-2xl">
            <CardContent className="py-16 text-center">
              <div className="size-12 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto mb-3">
                <Zap className="size-6 text-emerald-500" />
              </div>
              <p className="text-sm font-medium text-gray-600 dark:text-zinc-400">No critical bugs found</p>
              <p className="text-xs text-gray-400 dark:text-zinc-500 mt-1">All clear — no critical issues detected</p>
            </CardContent>
          </Card>
        ) : (
          <motion.div {...stagger} className="space-y-3">
            {criticalBugs.map((bug, idx) => {
              const tStatus = triageState[bug.id] || 'none'
              const tCfg = TRIAGE_CONFIG[tStatus]
              const expanded = expandedCritical.has(bug.id)
              return (
                <motion.div key={bug.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.04 }}>
                  <Collapsible open={expanded} onOpenChange={() => toggleCritical(bug.id)}>
                    <Card className={`critical-glow-hover glass-card rounded-2xl border-l-4 ${PRIORITY_BORDER[bug.severity] || ''} ${expanded ? 'ring-2 ring-red-500/20 card-depth-2' : 'card-depth-1'} transition-all duration-200`}>
                      <CollapsibleTrigger className="w-full text-left group">
                        <CardHeader className="pb-2">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-center gap-2 flex-wrap">
                              <Badge className={`text-[10px] border ${SEV_BG[bug.severity]}`} variant="outline">{bug.severity}</Badge>
                              <Badge variant="outline" className="text-[10px] font-mono">{bug.id}</Badge>
                              <Badge variant="outline" className="text-[10px]">{bug.category}</Badge>
                              <Badge variant="outline" className={`text-[10px] ${tCfg.bg} ${tCfg.border} border`}>
                                <tCfg.icon className={`size-2.5 mr-0.5 ${tCfg.color}`} />
                                {tCfg.label}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-1.5 shrink-0">
                              <button
                                onClick={(e) => { e.stopPropagation(); setBugTriage(bug.id, tStatus === 'resolved' ? 'none' as TriageStatus : 'resolved') }}
                                className="p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors active:scale-95"
                                aria-label="Toggle resolved"
                              >
                                <tCfg.icon className={`size-4 ${tCfg.color}`} />
                              </button>
                              {expanded ? <ChevronUp className="size-4 text-gray-400" /> : <ChevronDown className="size-4 text-gray-400" />}
                            </div>
                          </div>
                          <CardTitle className="text-sm leading-snug mt-1 group-hover:text-orange-600 dark:group-hover:text-orange-400 transition-colors">{bug.title}</CardTitle>
                          <p className="text-xs text-gray-500 dark:text-zinc-400 mt-1 flex items-center gap-1">
                            <FileCode2 className="size-3" />{bug.file}{bug.line ? `:${bug.line}` : ''}
                          </p>
                        </CardHeader>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <CardContent className="pt-0 space-y-3 border-t border-gray-100 dark:border-zinc-800/50 mt-0">
                          <div className="pt-3">
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Description</p>
                            <p className="text-xs text-gray-700 dark:text-zinc-300 leading-relaxed line-clamp-4">{bug.description}</p>
                          </div>
                          <div>
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Suggested Fix</p>
                            <p className="text-xs text-emerald-700 dark:text-emerald-400 leading-relaxed">{bug.fix}</p>
                          </div>
                          <button
                            onClick={() => openBug(bug)}
                            className="flex items-center gap-1 text-xs text-orange-500 hover:text-orange-600 font-medium transition-colors mt-1 group/btn"
                          >
                            Open full details <ExternalLink className="size-3 group-hover/btn:translate-x-0.5 transition-transform" />
                          </button>
                        </CardContent>
                      </CollapsibleContent>
                    </Card>
                  </Collapsible>
                </motion.div>
              )
            })}
          </motion.div>
        )}
      </motion.div>
    </AnimatePresence>
  )
}
