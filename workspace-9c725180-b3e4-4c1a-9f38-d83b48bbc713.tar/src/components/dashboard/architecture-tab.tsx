'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useDashboardData } from './data-context'
import { fadeIn } from './types'

const architectureFeatures = [
  { title: 'V3.3 Binary Wire Format', desc: 'Magic/version dispatch with little-endian encoding', color: 'from-cyan-500 to-teal-500' },
  { title: 'Streaming Architecture', desc: 'Async generator-based stream processing pipeline', color: 'from-emerald-500 to-green-500' },
  { title: 'Extension System', desc: 'Plugin-based v2.10 extension framework', color: 'from-orange-500 to-amber-500' },
  { title: 'Conformance Engine', desc: 'Spec validation with structured error reporting', color: 'from-red-500 to-rose-500' },
  { title: 'Type System v3', desc: 'Rich type hierarchy with union/intersection support', color: 'from-violet-500 to-purple-500' },
  { title: 'Error Recovery', desc: 'Graceful degradation with partial result support', color: 'from-pink-500 to-rose-500' },
  { title: 'Performance Optimization', desc: 'Runtime performance tuning and memory profiling', color: 'from-amber-500 to-yellow-500' },
  { title: 'Schema Registry', desc: 'Dynamic schema registration and versioning support', color: 'from-teal-500 to-cyan-500' },
  { title: 'Metrics Collection', desc: 'Built-in metrics and observability hooks', color: 'from-green-500 to-emerald-500' },
  { title: 'Validation Pipeline', desc: 'Multi-stage input validation with custom rules', color: 'from-orange-500 to-red-500' },
  { title: 'Configuration Management', desc: 'Dynamic config loading with environment support', color: 'from-rose-500 to-pink-500' },
]

const correlationItems = [
  { title: 'Binary Format ↔ Streaming', desc: 'V3.3 format enables efficient stream boundaries', status: 'implemented', priority: 95 },
  { title: 'Extension System ↔ Conformance', desc: 'Extensions validated against v2.10 spec', status: 'implemented', priority: 90 },
  { title: 'Type System ↔ Error Recovery', desc: 'Rich types improve error diagnostics', status: 'partial', priority: 60 },
  { title: 'Streaming Architecture ↔ Error Recovery', desc: 'Stream errors recovered gracefully', status: 'partial', priority: 55 },
  { title: 'Schema Registry ↔ Extension System', desc: 'Extensions register through schema', status: 'planned', priority: 30 },
]

export function ArchitectureTab() {
  const { settings } = useDashboardData()

  return (
    <AnimatePresence mode="wait">
      <motion.div key="architecture" {...fadeIn} className="space-y-6">
        {/* Architecture Features Grid with Gradient Dots */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {architectureFeatures.map((feat, i) => (
            <motion.div key={feat.title} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <Card className="glass-card rounded-2xl overflow-hidden h-full">
                <div className={`h-1.5 bg-gradient-to-r ${feat.color}`} />
                <CardHeader className={settings.compactView ? 'pb-1' : 'pb-2'}>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm">{feat.title}</CardTitle>
                    <div className={`size-3 rounded-full bg-gradient-to-br ${feat.color}`} />
                  </div>
                </CardHeader>
                <CardContent>
                  {!settings.compactView && <p className="text-xs text-gray-500 dark:text-zinc-400 leading-relaxed mb-3">{feat.desc}</p>}
                  <Badge className="bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20 text-[10px] font-semibold" variant="outline">
                    Implemented
                  </Badge>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Bug-Feature Correlation */}
        <Card className="glass-card rounded-2xl">
          <CardHeader>
            <CardTitle className="text-sm">Feature Correlations</CardTitle>
            <CardDescription>Dependencies between architectural components</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {correlationItems.map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + i * 0.08 }}
                className="space-y-2"
              >
                <div className="flex items-center gap-3 p-3 rounded-xl bg-gray-50/80 dark:bg-zinc-800/30">
                  <div className={`size-2.5 rounded-full ${item.status === 'implemented' ? 'bg-emerald-500' : item.status === 'partial' ? 'bg-amber-500' : 'bg-gray-400'}`} />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900 dark:text-zinc-100">{item.title}</p>
                    <p className="text-xs text-gray-500 dark:text-zinc-400">{item.desc}</p>
                  </div>
                  <Badge variant="outline" className={`text-[10px] ${item.status === 'implemented' ? 'border-emerald-500/20 text-emerald-600' : item.status === 'partial' ? 'border-amber-500/20 text-amber-600' : 'border-gray-500/20 text-gray-600'}`}>
                    {item.status}
                  </Badge>
                </div>
                <div className="px-3">
                  <div className="w-full h-1.5 rounded-full bg-gray-100 dark:bg-zinc-800 overflow-hidden">
                    <motion.div
                      className={`h-full rounded-full ${item.priority >= 80 ? 'bg-emerald-500' : item.priority >= 50 ? 'bg-amber-500' : 'bg-gray-400'}`}
                      initial={{ width: 0 }}
                      animate={{ width: `${item.priority}%` }}
                      transition={{ delay: 0.5 + i * 0.1, duration: 0.6 }}
                    />
                  </div>
                </div>
              </motion.div>
            ))}
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  )
}