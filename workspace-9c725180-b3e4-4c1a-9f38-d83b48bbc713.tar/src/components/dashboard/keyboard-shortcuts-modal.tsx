'use client'

import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog'
import {
  Keyboard, Search, Sun, LayoutGrid, AlertOctagon, AlertTriangle,
  FileWarning, XCircle, TestTube2, TrendingUp, FileText, History,
  Grid3x3, CheckCircle, Slash,
} from 'lucide-react'

const shortcuts = [
  { keys: ['?', '/'], label: 'Show keyboard shortcuts', icon: Keyboard },
  { keys: ['⌘', 'D'], label: 'Toggle dark/light mode', icon: Sun },
  { keys: ['/'], label: 'Focus search', icon: Search },
  { keys: ['1'], label: 'Overview tab', icon: LayoutGrid },
  { keys: ['2'], label: 'Executive tab', icon: FileText },
  { keys: ['3'], label: 'Critical Bugs tab', icon: AlertOctagon },
  { keys: ['4'], label: 'All Bugs tab', icon: AlertTriangle },
  { keys: ['5'], label: 'Spec Violations tab', icon: FileWarning },
  { keys: ['6'], label: 'Missing Features tab', icon: XCircle },
  { keys: ['7'], label: 'Test Gaps tab', icon: TestTube2 },
  { keys: ['8'], label: 'Architecture tab', icon: CheckCircle },
  { keys: ['9'], label: 'Risk Matrix tab', icon: Grid3x3 },
  { keys: ['0'], label: 'Trends tab', icon: TrendingUp },
]

export function KeyboardShortcutsModal({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md backdrop-blur-xl bg-white/80 dark:bg-zinc-900/80">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Keyboard className="size-5" /> Keyboard Shortcuts
          </DialogTitle>
          <DialogDescription>Quick navigation and actions for the dashboard</DialogDescription>
        </DialogHeader>
        <div className="space-y-1 mt-2 max-h-80 overflow-y-auto">
          {shortcuts.map((s) => (
            <div
              key={s.label}
              className="flex items-center justify-between py-2.5 px-3 rounded-xl hover:bg-gray-50 dark:hover:bg-zinc-800/50 transition-colors"
            >
              <div className="flex items-center gap-2.5 text-sm">
                <s.icon className="size-4 text-gray-400 dark:text-zinc-500" />
                <span className="text-gray-700 dark:text-zinc-300">{s.label}</span>
              </div>
              <div className="flex gap-1">
                {s.keys.map((k, i) => (
                  <kbd
                    key={i}
                    className="inline-flex items-center justify-center h-6 min-w-6 px-1.5 rounded-md bg-gray-100 dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 text-[11px] font-mono font-medium text-gray-600 dark:text-zinc-400"
                  >
                    {k === '/' && i === 0 ? <Slash className="size-3" /> : k}
                  </kbd>
                ))}
              </div>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  )
}
