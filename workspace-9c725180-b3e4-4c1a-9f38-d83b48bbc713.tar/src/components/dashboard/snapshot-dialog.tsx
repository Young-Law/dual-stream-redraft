'use client'

import { useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Camera, Loader2 } from 'lucide-react'
import { useDashboardData } from './data-context'

export function SnapshotDialog() {
  const { showSnapshotDialog, setShowSnapshotDialog, summary, conformancePct, rs, triageStats } = useDashboardData()
  const [label, setLabel] = useState('')
  const [saving, setSaving] = useState(false)

  const handleSave = async () => {
    if (!summary) return
    setSaving(true)
    try {
      await fetch('/api/review/snapshots', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionLabel: label || 'Manual Snapshot',
          totalFindings: summary.total_findings,
          critical: summary.critical,
          high: summary.high,
          medium: summary.medium,
          low: summary.low,
          conformancePct,
          missingFeatures: summary.missing_features,
          riskScore: rs,
          resolvedCount: triageStats.resolved,
          acknowledgedCount: triageStats.acknowledged,
        }),
      })
      setLabel('')
      setShowSnapshotDialog(false)
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={showSnapshotDialog} onOpenChange={setShowSnapshotDialog}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Camera className="size-5" /> Save Snapshot
          </DialogTitle>
          <DialogDescription>Save current dashboard metrics as a snapshot</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 mt-2">
          <div className="space-y-2">
            <Label htmlFor="snapshot-label">Label</Label>
            <Input
              id="snapshot-label"
              placeholder="e.g. Round 6, After Fix..."
              value={label}
              onChange={e => setLabel(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSave()}
            />
          </div>
          {summary && (
            <div className="text-xs text-gray-500 dark:text-zinc-400 space-y-1 bg-gray-50 dark:bg-zinc-800/50 rounded-xl p-3">
              <p>Total: {summary.total_findings} | Critical: {summary.critical} | High: {summary.high}</p>
              <p>Conformance: {conformancePct}% | Risk Score: {rs}</p>
            </div>
          )}
          <Button className="w-full" onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="size-4 animate-spin mr-2" /> : null}
            {saving ? 'Saving...' : 'Save Snapshot'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
