'use client'

import { useTheme } from 'next-themes'
import { Copy, Check, Keyboard, Bell, Search, Settings, Camera, Download, FileBarChart, Shield, Sun, Moon, AlertOctagon } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuLabel } from '@/components/ui/dropdown-menu'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useDashboardData } from './data-context'
import { TRIAGE_CONFIG, SEV_BG } from './types'
import type { TriageStatus } from './types'
import { riskScore } from './hooks'

export function DashboardHeader() {
  const { theme, setTheme } = useTheme()
  const {
    summary, triageStats, untriagedCriticalHigh, copied, setCopied,
    showShortcuts, setShowShortcuts, notifOpen, setNotifOpen,
    isMobile, search, setSearch, showSettings, setShowSettings,
    setShowSnapshotDialog, openBug, bugs,
  } = useDashboardData()

  const handleCopyReport = async () => {
    const text = `DSA v2.10 Review Summary\nTotal: ${summary?.total_findings} | Critical: ${summary?.critical} | High: ${summary?.high} | Medium: ${summary?.medium} | Low: ${summary?.low}\nConformance: ${summary?.spec_conformance_pct}% | Missing Features: ${summary?.missing_features}`
    await navigator.clipboard.writeText(text)
    setCopied(true); setTimeout(() => setCopied(false), 2000)
  }

  const handleExport = async (format: 'json' | 'csv') => {
    const resp = await fetch(`/api/review/export?format=${format}`)
    const blob = await resp.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = `dsa-v210-review.${format}`; a.click()
    URL.revokeObjectURL(url)
  }

  const rs = summary ? riskScore(summary) : 0

  return (
    <header className="glass border-b border-white/10 dark:border-white/5 sticky top-0 z-30 card-depth-2">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-xl bg-gradient-to-br from-red-500 via-orange-500 to-amber-500 flex items-center justify-center shadow-lg shadow-red-500/20 dark:shadow-red-500/10">
              <Shield className="size-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-zinc-100 tracking-tight">DSA v2.10 Code Review</h1>
              <p className="text-[11px] sm:text-xs text-gray-500 dark:text-zinc-400">Bug Report &amp; Architecture Conformance Analysis</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleCopyReport}>
                  {copied ? <Check className="size-3.5 text-emerald-500" /> : <Copy className="size-3.5 text-gray-500 dark:text-zinc-400" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent>Copy summary</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setShowShortcuts(p => !p)}>
                  <Keyboard className="size-3.5 text-gray-500 dark:text-zinc-400" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Shortcuts (?)</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setShowSnapshotDialog(true)}>
                  <Camera className="size-3.5 text-gray-500 dark:text-zinc-400" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Save Snapshot</TooltipContent>
            </Tooltip>
            <DropdownMenu open={notifOpen} onOpenChange={setNotifOpen}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 relative">
                      <Bell className="size-3.5 text-gray-500 dark:text-zinc-400" />
                      {untriagedCriticalHigh.length > 0 && (
                        <span className="absolute -top-0.5 -right-0.5 size-3.5 rounded-full bg-red-500 text-[8px] text-white font-bold flex items-center justify-center animate-badge-in">
                          {untriagedCriticalHigh.length}
                        </span>
                      )}
                    </Button>
                  </DropdownMenuTrigger>
                </TooltipTrigger>
                <TooltipContent>Notifications</TooltipContent>
              </Tooltip>
              <DropdownMenuContent align="end" className="w-80">
                <DropdownMenuLabel className="text-xs flex items-center justify-between">
                  <span>Triage Status Overview</span>
                  <Badge variant="secondary" className="text-[10px] h-5 tabular-nums font-bold">
                    {bugs.length} total
                  </Badge>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                {([['none', triageStats.none], ['acknowledged', triageStats.acknowledged], ['in-progress', triageStats['in-progress']], ['resolved', triageStats.resolved]] as [TriageStatus, number][]).map(([key, count]) => {
                  const cfg = TRIAGE_CONFIG[key]
                  return (
                    <DropdownMenuItem key={key} className="flex items-center justify-between py-2">
                      <div className="flex items-center gap-2"><cfg.icon className={`size-3.5 ${cfg.color}`} /><span className="text-xs">{cfg.label}</span></div>
                      <Badge variant="secondary" className="text-[10px] h-5 tabular-nums font-bold">{count}</Badge>
                    </DropdownMenuItem>
                  )
                })}
                {untriagedCriticalHigh.length > 0 && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuLabel className="text-xs text-red-500 font-semibold">
                      <AlertOctagon className="size-3 inline mr-1" />
                      Untriaged Critical/High ({untriagedCriticalHigh.length})
                    </DropdownMenuLabel>
                    <ScrollArea className="max-h-48">
                      {untriagedCriticalHigh.slice(0, 5).map(bug => (
                        <DropdownMenuItem
                          key={bug.id}
                          className="flex items-start gap-2 py-2 cursor-pointer"
                          onClick={() => { openBug(bug); setNotifOpen(false) }}
                        >
                          <Badge variant="outline" className={`text-[9px] mt-0.5 shrink-0 ${SEV_BG[bug.severity]} border`}>
                            {bug.severity}
                          </Badge>
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-medium truncate">{bug.title}</p>
                            <p className="text-[10px] text-gray-400 dark:text-zinc-500 font-mono truncate">{bug.file}{bug.line ? `:${bug.line}` : ''}</p>
                          </div>
                        </DropdownMenuItem>
                      ))}
                    </ScrollArea>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setShowSettings(true)}>
                  <Settings className="size-3.5 text-gray-500 dark:text-zinc-400" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Dashboard Settings</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
                  {theme === 'dark' ? <Sun className="size-3.5 text-gray-500 dark:text-zinc-400" /> : <Moon className="size-3.5 text-gray-500 dark:text-zinc-400" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent>Toggle theme (⌘D)</TooltipContent>
            </Tooltip>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Download className="size-3.5 text-gray-500 dark:text-zinc-400" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel className="text-xs">Export Report</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-xs gap-2" onClick={() => handleExport('json')}><Download className="size-3" />Export JSON</DropdownMenuItem>
                <DropdownMenuItem className="text-xs gap-2" onClick={() => handleExport('csv')}><FileBarChart className="size-3" />Export CSV</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
        {/* Triage stats bar */}
        <div className="mt-2.5 flex items-center gap-3 overflow-x-auto scrollbar-none">
          {([['none', triageStats.none], ['acknowledged', triageStats.acknowledged], ['in-progress', triageStats['in-progress']], ['resolved', triageStats.resolved]] as [TriageStatus, number][]).map(([key, count]) => {
            const cfg = TRIAGE_CONFIG[key]
            const pct = bugs.length > 0 ? Math.round((count / bugs.length) * 100) : 0
            return (
              <div key={key} className={`flex items-center gap-1.5 shrink-0 rounded-lg px-2.5 py-1 ${cfg.bg} ${cfg.border} border`}>
                <cfg.icon className={`size-3 ${cfg.color}`} />
                <span className="text-[10px] font-medium text-gray-600 dark:text-zinc-400">{cfg.label}</span>
                <span className={`text-[10px] font-bold tabular-nums ${cfg.color}`}>{count}</span>
                <span className="text-[9px] text-gray-400 dark:text-zinc-500">({pct}%)</span>
              </div>
            )
          })}
        </div>
        {/* Mobile search */}
        {isMobile && (
          <div className="mt-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-gray-400" />
              <Input
                id="global-search"
                placeholder="Search bugs, violations, features..."
                className="h-8 pl-9 text-xs rounded-xl bg-white/50 dark:bg-zinc-900/50 border-gray-200/60 dark:border-zinc-700/40"
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
